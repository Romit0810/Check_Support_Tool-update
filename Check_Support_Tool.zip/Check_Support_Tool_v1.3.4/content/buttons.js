// ============================================================
// buttons.js
// ============================================================

(function () {
// ========================================
// 외부 버튼 컨테이너와 우클릭 메뉴 변수
// ========================================
let externalContainer = null; // 외부 버튼을 담는 박스
let detachMenu = null; // 우클릭 메뉴

// ========================================
// 1. 토스트 메시지 (복사 성공/실패 전용)
// ========================================
function showToast(msg) {
const toast = document.createElement("div");
toast.textContent = msg;
toast.style.position = "fixed";
toast.style.top = "40px";
toast.style.left = "50%";
toast.style.transform = "translateX(-50%)";
toast.style.background = "rgba(20,20,20,0.85)";
toast.style.color = "#fff";
toast.style.padding = "8px 16px";
toast.style.borderRadius = "12px";
toast.style.zIndex = "2147483647";
toast.style.fontSize = "13px";
toast.style.transition = "opacity 0.3s ease";
toast.style.opacity = "1";
document.body.appendChild(toast);

setTimeout(() => { toast.style.opacity = "0"; setTimeout(() => toast.remove(), 300); }, 1500);
}

// ========================================
// 2. 버튼 스타일 공통 정의
// ========================================
function styleButton(btn) {
btn.style.height = "28px";
btn.style.background = "rgba(20,20,20,0.85)";
btn.style.border = "1px solid rgba(255,255,255,0.2)";
btn.style.borderRadius = "6px";
btn.style.color = "#fff";
btn.style.fontSize = "12px";
btn.style.cursor = "pointer";
btn.style.display = "flex";
btn.style.alignItems = "center";
btn.style.justifyContent = "center";
btn.style.transition = "all 0.2s ease";
btn.style.boxShadow = "0 2px 4px rgba(0,0,0,0.4)";
btn.style.padding = "0 10px";
btn.style.margin = "0 4px";
btn.onmouseenter = () => { btn.style.boxShadow = "0 4px 8px rgba(0,0,0,0.8)"; };
btn.onmouseleave = () => { btn.style.boxShadow = "0 2px 4px rgba(0,0,0,0.4)"; btn.style.transform = "scale(1)"; };
btn.onmousedown = () => { btn.style.transform = "scale(0.88)"; };
btn.onmouseup = () => { btn.style.transform = "scale(1.05)"; setTimeout(() => { btn.style.transform = "scale(1)"; }, 150); };
}

// ========================================
// 3. 드래그 핸들 스타일
// ========================================
function styleHandle(handle) {
handle.textContent = "🚀";
handle.style.width = "16px";
handle.style.height = "28px";
handle.style.color = "#fff";
handle.style.display = "flex";
handle.style.alignItems = "center";
handle.style.justifyContent = "center";
handle.style.cursor = "grab";
handle.style.fontSize = "14px";
handle.style.userSelect = "none";
handle.onmousedown = () => (handle.style.cursor = "grabbing");
handle.onmouseup = () => (handle.style.cursor = "grab");
}

// ========================================
// 4. 외부 버튼 생성
// ========================================
function createExternalContainer() {
if (externalContainer) return;
if (!/price\.coupang\.com/.test(location.hostname)) return;

externalContainer = document.createElement("div");
externalContainer.id = "__ext_external_buttons__";
externalContainer.style.position = "fixed";
externalContainer.style.top = "80px";
externalContainer.style.left = "50%";
externalContainer.style.transform = "translateX(-50%)";
externalContainer.style.zIndex = "2147483647";
externalContainer.style.display = "flex";
externalContainer.style.gap = "8px";
externalContainer.style.padding = "6px";

chrome.storage.local.get("__ext_buttons_position", (res) => {
if (res.__ext_buttons_position) {
externalContainer.style.top = res.__ext_buttons_position.top + "px";
externalContainer.style.left = res.__ext_buttons_position.left + "px";
externalContainer.style.transform = "";
}
});

// 판매중변경요청 버튼 (핸들 포함)
const wrapperSell = document.createElement("div");
wrapperSell.style.display = "flex";
wrapperSell.style.alignItems = "center";

const handleSell = document.createElement("span");
styleHandle(handleSell);
wrapperSell.appendChild(handleSell);

const btnSell = document.createElement("button");
btnSell.textContent = "판매중변경요청";
styleButton(btnSell);
wrapperSell.appendChild(btnSell);

btnSell.addEventListener("click", () => {
chrome.storage.local.get(["__ext_last_vendor", "__ext_last_siteitem"], (res) => {
const vendorVal = res.__ext_last_vendor || "";
const siteitemVal = res.__ext_last_siteitem || "";
if (!vendorVal || !siteitemVal) { showToast("⚠️ 복사실패!"); return; }
const text = `VIID : ${vendorVal}\nSiteitemid : ${siteitemVal}\n판매중으로 변경 부탁드립니다.`;
navigator.clipboard.writeText(text).then(() => showToast("✅ 복사완료!")).catch(() => showToast("⚠️ 복사실패!"));
});
});

// 블랙셀러제외티켓 버튼
const btnTicket = document.createElement("button");
btnTicket.textContent = "블랙셀러제외티켓";
styleButton(btnTicket);
btnTicket.addEventListener("click", () => {
navigator.clipboard.writeText("PBS-914529").then(() => showToast("✅ 복사완료!")).catch(() => showToast("⚠️ 복사실패!"));
});

externalContainer.appendChild(wrapperSell);
externalContainer.appendChild(btnTicket);
document.body.appendChild(externalContainer);

makeDraggable(externalContainer, [handleSell]);

externalContainer.addEventListener("contextmenu", (e) => { e.preventDefault(); showContextMenu(e.clientX, e.clientY, false); });
}

// ========================================
// 5. 드래그 기능
// ========================================
function makeDraggable(container, handles) {
let offsetX = 0, offsetY = 0, isDragging = false;
handles.forEach(handle => {
handle.addEventListener("mousedown", (e) => { isDragging = true; offsetX = e.clientX - container.offsetLeft; offsetY = e.clientY - container.offsetTop; e.preventDefault(); });
});
document.addEventListener("mousemove", (e) => {
if (!isDragging) return;
let newLeft = e.clientX - offsetX;
let newTop = e.clientY - offsetY;
newLeft = Math.max(0, Math.min(window.innerWidth - container.offsetWidth, newLeft));
newTop = Math.max(0, Math.min(window.innerHeight - container.offsetHeight, newTop));
container.style.left = newLeft + "px";
container.style.top = newTop + "px";
container.style.transform = "";
});
document.addEventListener("mouseup", () => {
if (isDragging) { chrome.storage.local.set({"__ext_buttons_position": {top: externalContainer.offsetTop, left: externalContainer.offsetLeft}}); }
isDragging = false;
});
}

// ========================================
// 6. 우클릭 메뉴
// ========================================
function showContextMenu(x, y, isPopup) {
if (detachMenu) detachMenu.remove();
detachMenu = document.createElement("div");
detachMenu.style.position = "fixed";
detachMenu.style.top = y + "px";
detachMenu.style.left = x + "px";
detachMenu.style.background = "rgba(20,20,20,0.9)";
detachMenu.style.color = "#fff";
detachMenu.style.padding = "6px 12px";
detachMenu.style.borderRadius = "8px";
detachMenu.style.zIndex = "2147483647";
detachMenu.style.fontSize = "13px";
detachMenu.style.cursor = "pointer";
detachMenu.style.userSelect = "none";
detachMenu.textContent = isPopup ? "빼기" : "넣기";
detachMenu.onmousedown = () => { detachMenu.style.transform = "scale(0.92)"; };
detachMenu.onmouseup = () => { detachMenu.style.transform = "scale(1)"; };
detachMenu.onclick = () => {
if (isPopup) { chrome.storage.local.set({ "__ext_buttons_detached": true }); createExternalContainer(); }
else { chrome.storage.local.set({ "__ext_buttons_detached": false }); if (externalContainer) { externalContainer.remove(); externalContainer = null; } }
detachMenu.remove();
};
document.body.appendChild(detachMenu);
const closeMenu = (e) => { if (!detachMenu.contains(e.target)) { detachMenu.remove(); document.removeEventListener("click", closeMenu); } };
setTimeout(() => document.addEventListener("click", closeMenu), 0);
}

// ========================================
// 7. 상태 동기화
// ========================================
chrome.storage.local.get("__ext_buttons_detached", (res) => { if (res.__ext_buttons_detached) createExternalContainer(); });
chrome.runtime.onMessage.addListener((msg) => { if (msg.action === "show_external_buttons") createExternalContainer(); });
})();

// ============================================================
// 8. CSV 파일 상태 표시 (팝업 페이지 전용)
// ============================================================
(function () {
function ensureCsvStatusBadge() {
if (!location.href.startsWith("chrome-extension")) return null;
const popupRoot = document.getElementById("popup");
if (!popupRoot) return null;

let badge = document.getElementById("__ext_csv_status_badge__");
if (!badge) {
badge = document.createElement("div");
badge.id = "__ext_csv_status_badge__";
badge.style.minWidth = "160px";
badge.style.padding = "6px 8px";
badge.style.borderRadius = "6px";
badge.style.background = "rgba(255,255,255,0.06)";
badge.style.color = "#fff";
badge.style.fontSize = "12px";
badge.style.margin = "6px auto";
badge.style.textAlign = "center";
badge.style.boxSizing = "border-box";

const title = document.createElement("div");
title.id = "__ext_csv_status_title__";
title.textContent = "CSV: 미로드";
title.style.fontWeight = "600";
const fname = document.createElement("div");
fname.id = "__ext_csv_status_fname__";
fname.textContent = "";
fname.style.fontSize = "11px";
fname.style.opacity = "0.85";

badge.appendChild(title);
badge.appendChild(fname);
popupRoot.appendChild(badge);
}
return badge;
}

function updateCsvBadgeFromStorage() {
chrome.storage.local.get(["__ext_uploaded_filename", "__ext_uploaded_csv"], (res) => {
const badge = ensureCsvStatusBadge();
if (!badge) return;
const title = badge.querySelector("#__ext_csv_status_title__");
const fnameEl = badge.querySelector("#__ext_csv_status_fname__");

const loaded = !!res.__ext_uploaded_csv;
const fname = res.__ext_uploaded_filename || "";

if (loaded) {
title.textContent = "CSV: 로드됨 ✅";
title.style.color = "#dff0d8";
fnameEl.textContent = fname ? `파일명: ${fname}` : "";
} else {
title.textContent = "CSV: 미로드 ⚠️";
title.style.color = "#ffddcc";
fnameEl.textContent = "";
}
});
}

const mo = new MutationObserver(() => {
if (document.getElementById("__ext_external_buttons__")) {
ensureCsvStatusBadge();
updateCsvBadgeFromStorage();
}
});
mo.observe(document.documentElement, { childList: true, subtree: true });

setTimeout(() => { if (document.getElementById("__ext_external_buttons__")) { ensureCsvStatusBadge(); updateCsvBadgeFromStorage(); } }, 0);

chrome.storage.onChanged.addListener((changes, area) => {
if (area !== "local") return;
if (!location.href.startsWith("chrome-extension")) return;
if ("__ext_uploaded_filename" in changes || "__ext_uploaded_csv" in changes) {
updateCsvBadgeFromStorage();
}
});

chrome.runtime.onMessage.addListener((msg) => {
if (msg && msg.action === "ext_update_csv_status") updateCsvBadgeFromStorage();
});
})();

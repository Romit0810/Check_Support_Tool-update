// ============================================================
// popup.js
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
// ========================================
// 1. Admin 페이지 정보 가져오기
// ========================================
try {
updateFromAdmin(); // 📝 Admin 정보를 가져와 popup 업데이트
} catch (e) {
console.error(e);
showStatus("⚠️ 오류");
setAllWarnings();
}

// ========================================
// 2. 블랙셀러 티켓 복사 버튼
// ========================================
const copyBtn = document.getElementById("copy-ticket");
if (copyBtn) {
copyBtn.addEventListener("click", () => {
navigator.clipboard.writeText("PBS-914529")
.then(() => showToast("✅ 복사완료!"))
.catch(err => { console.error("⚠️ 복사 실패:", err); showToast("⚠️ 복사실패!"); });
});
}

// ========================================
// 3. 판매중변경요청 버튼 복사 기능
// ========================================
const copySellBtn = document.getElementById("copy-sell-change");
if (copySellBtn) {
copySellBtn.addEventListener("click", () => {
const vendorVal = document.getElementById("vendor-box")?.textContent.trim();
const siteitemVal = document.getElementById("siteitem-box")?.textContent.trim();

if (!vendorVal || vendorVal === "⚠️" || !siteitemVal || siteitemVal === "⚠️") {
showToast("⚠️ 복사실패!");
return;
}

const text = `VIID : ${vendorVal}\nSiteitemid : ${siteitemVal}\n판매중으로 변경 부탁드립니다.`;
navigator.clipboard.writeText(text)
.then(() => showToast("✅ 복사완료!"))
.catch(err => { console.error("복사 실패:", err); showToast("⚠️ 복사실패!"); });
});
}

// ========================================
// 4. 유통기한 토글 상태 불러오기/저장
// ========================================
const expiryToggle = document.getElementById("expiry-toggle");
chrome.storage.local.get("__ext_expiry_enabled", (res) => { expiryToggle.checked = res.__ext_expiry_enabled !== false; });
expiryToggle.addEventListener("change", () => {
chrome.storage.local.set({ "__ext_expiry_enabled": expiryToggle.checked });
chrome.tabs.query({}, (tabs) => {
tabs.forEach(tab => {
try { chrome.tabs.sendMessage(tab.id, { action: "expiry_refresh" }); } catch (e) {}
});
});
});

// ========================================
// 5. 팝업 우클릭 → 빼기 메뉴
// ========================================
function openDetachMenuInPopup(ev) {
ev.preventDefault(); ev.stopPropagation();

const old = document.getElementById("__ext_popup_ctx__");
if (old) old.remove();

const menu = document.createElement("div");
menu.id = "__ext_popup_ctx__";
menu.textContent = "빼기";
menu.style.position = "fixed";
menu.style.top = ev.clientY + "px";
menu.style.left = ev.clientX + "px";
menu.style.background = "rgba(20,20,20,0.9)";
menu.style.color = "#fff";
menu.style.padding = "8px 14px";
menu.style.borderRadius = "10px";
menu.style.zIndex = "2147483647";
menu.style.fontSize = "13px";
menu.style.cursor = "pointer";
menu.style.userSelect = "none";
menu.style.transition = "transform 0.08s ease";

menu.addEventListener("mousedown", (e) => { e.stopPropagation(); menu.style.transform = "scale(0.92)"; });
menu.addEventListener("mouseup", (e) => { e.stopPropagation(); menu.style.transform = "scale(1)"; });
menu.addEventListener("click", (e) => { e.stopPropagation(); handleDetachFromPopup(menu); });

document.body.appendChild(menu);

const closeOnOutside = (e) => { if (!menu.contains(e.target)) { menu.remove(); document.removeEventListener("mousedown", closeOnOutside, true); } };
setTimeout(() => { document.addEventListener("mousedown", closeOnOutside, true); }, 0);
}

function handleDetachFromPopup(menuEl) {
try {
chrome.storage.local.set({ "__ext_buttons_detached": true });
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
const tab = tabs && tabs[0];
if (tab && tab.id && tab.url && /^https?:\/\//i.test(tab.url)) {
try { chrome.tabs.sendMessage(tab.id, { action: "show_external_buttons" }); } catch (e) {}
}
});
} finally {
if (menuEl && menuEl.parentNode) menuEl.parentNode.removeChild(menuEl);
}
}

if (copyBtn) copyBtn.addEventListener("contextmenu", openDetachMenuInPopup);
if (copySellBtn) copySellBtn.addEventListener("contextmenu", openDetachMenuInPopup);
});

// ========================================
// 6. 상태 표시 / 값 초기화 함수
// ========================================
function statusEl() { return document.getElementById('status'); }
function showStatus(text) { const el = statusEl(); if (el) { el.textContent = text; el.classList.remove("status-normal", "status-error"); if (text.startsWith("✅")) el.classList.add("status-normal"); else if (text.startsWith("⚠️")) el.classList.add("status-error"); } }
function setAllWarnings() { document.querySelectorAll('.row-inline .small-box').forEach(box => box.textContent = '⚠️'); }
function setBoxValue(id, value) { const el = document.getElementById(id); if (el) el.textContent = value; }

// ========================================
// 7. Admin 정보 업데이트
// ========================================
function updateFromAdmin() {
chrome.tabs.query({ url: ["*://price.coupang.com/*"] }, (tabs) => {
if (!tabs || tabs.length === 0) { showStatus("⚠️ 어드민이 없어요"); setAllWarnings(); return; }
if (tabs.length !== 1) { showStatus("⚠️ 어드민이 두개 이상 켜져있어요"); setAllWarnings(); return; }
const tab = tabs[0];
const url = tab.url || "";
if (/^https?:\/\/price\.coupang\.com\/#\/?$/.test(url)) { showStatus("⚠️ VIID 입력필요"); setAllWarnings(); return; }
chrome.tabs.sendMessage(tab.id, { action: 'extract_and_highlight' }, (res) => {
if (chrome.runtime.lastError || !res) { showStatus("⚠️ 오류"); setAllWarnings(); return; }
const kanVal = res.kan ? res.kan.trim() : "";
const unitVal = res.unit ? res.unit.trim() : "";
const vendorVal = res.vendor ? res.vendor.trim() : "";
const siteitemVal = res.siteitem ? res.siteitem.trim() : "";

const kanOK = /^[0-9]{3,4}$/.test(kanVal);
const unitOK = /^[A-Za-z0-9&, ]+$/.test(unitVal);
const vendorOK = /^[0-9]{9,12}$/.test(vendorVal);
const siteitemOK = /^[0-9]{1,14}$/.test(siteitemVal);

setBoxValue("kan-box", kanOK ? kanVal : "⚠️");
setBoxValue("unit-box", unitOK ? unitVal : "⚠️");
setBoxValue("vendor-box", vendorOK ? vendorVal : "⚠️");
setBoxValue("siteitem-box", siteitemOK ? siteitemVal : "⚠️");

if (kanOK && unitOK && vendorOK) showStatus("✅ 정상"); else showStatus("⚠️ 오류");
});
});
}

// ========================================
// 8. 팝업 토스트 메시지 위치 조정
// ========================================
function showToast(msg) {
const toast = document.createElement("div");
toast.textContent = msg;
toast.style.position = "absolute";
const sellBtn = document.getElementById("copy-sell-change");
const ticketBtn = document.getElementById("copy-ticket");
if (sellBtn && ticketBtn) {
const rectSell = sellBtn.getBoundingClientRect();
const rectTicket = ticketBtn.getBoundingClientRect();
const centerX = (rectSell.left + rectTicket.right) / 2;
const topY = Math.min(rectSell.top, rectTicket.top) - 30;
toast.style.left = centerX + "px";
toast.style.top = topY + "px";
toast.style.transform = "translateX(-50%)";
} else { toast.style.top = "20px"; toast.style.left = "50%"; toast.style.transform = "translateX(-50%)"; }
toast.style.background = "rgba(20,20,20,0.85)";
toast.style.color = "#fff";
toast.style.padding = "6px 12px";
toast.style.borderRadius = "8px";
toast.style.zIndex = "2147483647";
toast.style.fontSize = "13px";
toast.style.whiteSpace = "nowrap";
toast.style.transition = "opacity 0.3s ease";
toast.style.opacity = "1";
document.body.appendChild(toast);
setTimeout(() => { toast.style.opacity = "0"; setTimeout(() => toast.remove(), 300); }, 1500);
}

// ========================================
// 9. CSV 업로드 (popup → background)
// ========================================
(() => {
const input = document.getElementById("csv-upload");
const btn = document.getElementById("csv-select-btn");
const label = document.getElementById("csv-file-label");
if (!input || !btn || !label) return;

const setFileName = (name) => { label.textContent = name || ""; };
btn.addEventListener("click", () => input.click());

input.addEventListener("change", async (e) => {
const f = e.target.files && e.target.files[0];
if (!f) return;
try {
const text = await f.text();
chrome.runtime.sendMessage({ action: "upload_blacklist_file", filename: f.name, csvText: text }, (resp) => {
if (resp && resp.ok) { showToast("✅ 업로드 완료"); setFileName(f.name); chrome.storage.local.set({ "__ext_uploaded_filename": f.name }); }
else { showToast("⚠️ 업로드 실패"); setFileName(""); }
});
} catch (err) { console.error("파일 읽기 실패:", err); showToast("⚠️ 업로드 실패"); setFileName(""); }
});

chrome.storage.local.get(["__ext_uploaded_filename"], (res) => { if (res && res.__ext_uploaded_filename) { setFileName(res.__ext_uploaded_filename); console.log("[POPUP] 복원:", res.__ext_uploaded_filename); } });

try { chrome.runtime.sendMessage({ action: "get_uploaded_file_info" }, (res) => { console.log("[POPUP] 업로드 상태:", res); }); } catch (e) {}
})();

// ========================================
// 10. KeepAlive (service worker 슬립 방지)
// ========================================
(() => { try { const port = chrome.runtime.connect({ name: "keepAlive" }); window.addEventListener("unload", () => { try { port.disconnect(); } catch (e){} }); } catch (e){} })();
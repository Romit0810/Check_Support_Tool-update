// 날짜 포맷 함수 (YY.MM.DD 형식)
function formatDate(date) {
const yy = String(date.getFullYear()).slice(2);
const mm = String(date.getMonth() + 1).padStart(2, '0');
const dd = String(date.getDate()).padStart(2, '0');
return `${yy}.${mm}.${dd}`;
}

// 기준일: 오늘 00시
function getTodayMidnight() {
const now = new Date();
return new Date(now.getFullYear(), now.getMonth(), now.getDate());
}

// 특정 일수 뒤 날짜 구하기
function addDays(baseDate, days) {
const result = new Date(baseDate);
result.setDate(result.getDate() + days);
return result;
}

// DOM 업데이트
function updateDates() {
const today = getTodayMidnight();

// TODAY 날짜
document.getElementById("today-date").textContent = formatDate(today);

// 라벨별 날짜
document.getElementById("date-common").textContent = formatDate(addDays(today, 180));
document.getElementById("date-beauty").textContent = formatDate(addDays(today, 365));
document.getElementById("date-milk").textContent = formatDate(addDays(today, 40));
document.getElementById("date-soy").textContent = formatDate(addDays(today, 60));
}

// 실행
updateDates();

// 유통기한 기능 토글 상태 출력
const expiryToggle = document.getElementById("expiry-toggle");
if (expiryToggle) {
expiryToggle.addEventListener("change", function () {
if (this.checked) {
console.log("유통기한 기능: 켜짐");
// 여기에 켜졌을 때 기능 추가 가능
} else {
console.log("유통기한 기능: 꺼짐");
// 여기에 꺼졌을 때 기능 추가 가능
}
});
}

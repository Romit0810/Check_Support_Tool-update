// ============================================================
// background.js
// ============================================================

// ============================================================
// 1. 서비스워커 로드 및 기본 이벤트
// ============================================================
// background.js 파일이 로드될 때 바로 확인용 로그 출력
console.log("[BG] background.js 로드됨");

// 크롬 확장 프로그램 설치 시 호출되는 이벤트
chrome.runtime.onInstalled.addListener(() => {
console.log("[BG] onInstalled");
});

// 브라우저가 시작될 때 호출되는 이벤트 (있으면)
chrome.runtime.onStartup?.addListener(() => {
console.log("[BG] onStartup");
});

// ============================================================
// 2. Ping 확인 (popup/content -> 서비스워커 살아있는지 확인)
// ============================================================
// popup이나 content script에서 'ping' 메시지를 보내면
// background.js가 살아있는지 확인 후 'pong'으로 응답
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (msg === "ping") {
console.log("[BG] ping 받음");
sendResponse("pong");
}
});

// ============================================================
// 3. Admin 상태 관리 함수 & 이벤트
// ============================================================
// Coupang Admin 페이지 상태를 확인하고 오류 여부를 관리하는 함수
function refreshAdminState() {
// price.coupang.com 탭 모두 가져오기
chrome.tabs.query({ url: ["*://price.coupang.com/*"] }, (tabs) => {
const count = (tabs || []).length; // 📝 현재 열린 탭 수 계산

// 탭들 중에서 #/matching/숫자 패턴이 있는지 확인 (결과 페이지 존재 여부)
let viidOk = false;
for (const t of tabs || []) {
const url = t.url || "";
if (/#\/matching\/\d+/.test(url)) {
viidOk = true; // 📝 결과 페이지가 하나라도 있으면 true
break;
}
}

// 현재 탭 상태를 local storage에 저장
chrome.storage.local.set({
__ext_admin_tabs: count, // 📝 열린 admin 탭 수
__ext_admin_viid_ok: viidOk // 📝 결과 페이지 여부
}, () => {
// 오류 체크: admin이 아예 없거나, 2개 이상, 또는 유효 결과 페이지 없음
let isError = false;
if (count === 0 || count > 1 || !viidOk) isError = true;

// 기존 오류 값과 다르면 갱신하여 아이콘 배지 변경
chrome.storage.local.get("__ext_admin_error", (res) => {
if (res.__ext_admin_error !== isError) {
chrome.storage.local.set({ __ext_admin_error: isError }, () => {
console.log("[BG] __ext_admin_error 강제 갱신:", res.__ext_admin_error, "→", isError);
});
}
});
});

// admin이 아예 없거나 유효 결과 페이지 없으면 마지막 unit 이름 삭제 → 배너 자동 OFF
if (count === 0 || !viidOk) {
chrome.storage.local.remove(["__ext_last_unit"]);
}
});
}

// 설치/업데이트 시 상태 갱신
chrome.runtime.onInstalled.addListener(() => refreshAdminState());
// 탭 생성/삭제/갱신/활성화 이벤트에서 상태 갱신
chrome.tabs.onCreated.addListener(() => refreshAdminState());
chrome.tabs.onRemoved.addListener(() => refreshAdminState());
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
// URL이 변경되거나 해시만 바뀌어도 상태 갱신
if ((changeInfo.url && /price\.coupang\.com/.test(changeInfo.url)) ||
(tab && tab.url && /price\.coupang\.com/.test(tab.url))) {
refreshAdminState();
}
});
chrome.tabs.onActivated.addListener(() => refreshAdminState());

// 오류 여부가 변경되면 아이콘 배지로 표시
chrome.storage.onChanged.addListener((changes, area) => {
if (area !== "local") return;
if ("__ext_admin_error" in changes) {
const { newValue } = changes.__ext_admin_error;
console.log("[BG] __ext_admin_error 변경:", newValue ? "오류 발생" : "정상");

// 오류 상태 → 분홍색 X, 정상 → 노란색 O
if (newValue) {
chrome.action.setBadgeText({ text: "X" });
chrome.action.setBadgeBackgroundColor({ color: "#FF4081" });
chrome.action.setBadgeTextColor?.({ color: "#000000" });
} else {
chrome.action.setBadgeText({ text: "O" });
chrome.action.setBadgeBackgroundColor({ color: "#FFEB3B" });
chrome.action.setBadgeTextColor?.({ color: "#000000" });
}
}
});

// ============================================================
// 4. CSV 업로드 처리 (팝업에서 보낸 파일 저장 및 검증)
// ============================================================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (!msg || msg.action !== "upload_blacklist_file") return;
console.log("[BG] CSV 업로드 요청 수신:", msg.filename);

try {
// 파일 내용과 이름, 업로드 시간 저장
chrome.storage.local.set({
__ext_uploaded_csv: msg.csvText,
__ext_uploaded_filename: msg.filename,
__ext_uploaded_timestamp: Date.now(),
}, () => {
console.log("[BG] CSV 저장 완료:", msg.filename);

// 저장 직후 즉시 검증
chrome.storage.local.get(["__ext_uploaded_filename"], (chk) => {
console.log("[BG] 저장 검증:", chk);
});

// 팝업 리셋 방지 응답
setTimeout(() => sendResponse({ ok: true }), 150);
});
} catch (e) {
console.error("[BG] CSV 업로드 오류:", e);
sendResponse({ ok: false });
}
return true; // 비동기 응답 유지
});

// ============================================================
// 5. 업로드된 CSV 정보 요청 처리
// ============================================================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (msg && msg.action === "get_uploaded_file_info") {
chrome.storage.local.get(["__ext_uploaded_filename", "__ext_uploaded_csv"], (res) => {
sendResponse(res || {}); // 업로드된 파일 정보 반환
});
return true; // 비동기 응답 유지
}
});

// ============================================================
// 6. 서비스워커 suspend / resume 관리
// ============================================================
// 서비스워커가 suspend에서 복귀했을 때 캐시 확인
chrome.runtime.onSuspendCanceled?.addListener(() => {
console.log("[BG] Service worker resumed, verifying cached storage…");
chrome.storage.local.get(["__ext_uploaded_filename", "__ext_uploaded_csv"], (res) => {
if (res.__ext_uploaded_filename) {
console.log("[BG] Cached file still present:", res.__ext_uploaded_filename);
} else {
console.warn("[BG] Cached file missing after resume → will restore soon if popup reopens");
}
});
});

// 서비스워커 suspend 시 저장 상태 확인
chrome.runtime.onSuspend?.addListener(() => {
console.log("[BG] onSuspend → 강제 flush");
chrome.storage.local.get(null, (res) => {
console.log("[BG] Suspend 직전 저장된 키 수:", Object.keys(res).length);
});
});

// KeepAlive 연결 유지 (서비스워커 슬립 방지)
let keepAlivePort = null;
chrome.runtime.onConnect.addListener((port) => {
if (port.name === "keepAlive") {
console.log("[BG] KeepAlive 연결됨");
keepAlivePort = port;
port.onDisconnect.addListener(() => {
console.log("[BG] KeepAlive 해제됨");
keepAlivePort = null;
});
}
});

// ============================================================
// 7. 자동 업데이트
// ============================================================

// Chrome 자동 업데이트 확인
function checkChromeAutoUpdate() {
  const currentVersion = chrome.runtime.getManifest().version;

  chrome.runtime.requestUpdateCheck((status, details) => {
    if (status === "update_available") {
      console.log(
        `✅ 업데이트 발견! 현재: ${currentVersion} → 최신: ${details.version}`
      );

      showUpdateNotification(details.version);
    }

    if (status === "no_update") {
      console.log(
        ` 현재 최신 버전입니다 (현재  ${currentVersion})`
      );
    }

    if (status === "throttled") {
      console.log("⏳ 업데이트 제한됨");
    }
  });
}

//  업데이트 발견 알림
function showUpdateNotification(newVersion) {
  const notificationId = `update_${Date.now()}`;

  chrome.notifications.create(notificationId, {
    type: "basic",
    iconUrl: "icons/icon128.png",
    title: "확장프로그램 업데이트",
    message: `새로운 버전 ${newVersion} 이 확인되었습니다.`,
    buttons: [
      { title: "지금 업데이트" },
      { title: "잠시 후 다시 알림" }
    ],
    requireInteraction: true,
    priority: 2
  });
}

// 알림 버튼 클릭 처리
chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
  if (!notificationId.startsWith("update_")) return;

  // 지금 업데이트
  if (buttonIndex === 0) {
    chrome.runtime.requestUpdateCheck(() => {
      chrome.runtime.reload();
    });
  }

  // 잠시후 다시 알림 → 아무것도 안 함 (다음 체크 때 다시 뜸)
  if (buttonIndex === 1) {
    console.log("[AUTO UPDATE] 업데이트 알림 연기");
  }

  chrome.notifications.clear(notificationId);
});

// ✅ 업데이트 완료 알림
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "update") {
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: "업데이트 완료",
      message: `Check_Support_Tool ${chrome.runtime.getManifest().version} 업데이트가 완료되었습니다.`,
      priority: 2
    });
  }
});

// ⏱ 최초 1회 + 1시간마다 자동 체크
checkChromeAutoUpdate();
setInterval(checkChromeAutoUpdate, 60 * 60 * 1000);
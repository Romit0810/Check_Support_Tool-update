// ============================================================
// admin.js
// 어드민의 Vendoritem ID, Siteitemid, KAN ID, Unitname1 저장 기능
// admin.js+blackseller-csv.js였던걸 분리함
// ============================================================

console.log("[CONTENT] admin.js 로드됨:", location.href);

(function () {

// ============================================================
// 0. 공통 상수 / 유틸 함수
// ============================================================

// KAN ID / UNITNAME 형식 체크용 정규식
const KAN_REGEX = /^[0-9]{3,4}$/;
const UNIT_REGEX = /^[A-Za-z0-9&, ]+$/;

// 문자열 정리 (공백 통일)
const tnorm = (s) => (s || "").replace(/\s+/g, " ").trim();

// 대소문자 무시 비교
const ciEq = (a, b) => tnorm(a).toLowerCase() === tnorm(b).toLowerCase();


// ============================================================
// 1. Admin 페이지 감지 함수
// ============================================================

function isAdminPage() {
return /price\.coupang\.com/.test(location.host);
}

function isAdminMatchingPage() {
const h = location.hash || "";
return /#\/matching\/\d+/.test(h);
}

// ============================================================
// 2. Admin 값 찾기
// ============================================================

function findLabelExactCI(text) {
const all = document.querySelectorAll("body *");
for (const el of all) {
const txt = tnorm(el.textContent);
if (!txt) continue;
if (ciEq(txt, text)) return el;
}
return null;
}

function findValueUnder(labelEl) {
if (!labelEl) return null;

const parent = labelEl.parentElement;
if (parent) {
const kids = Array.from(parent.children);
const idx = kids.indexOf(labelEl);
for (let i = idx + 1; i < kids.length; i++) {
const s = kids[i];
const val = tnorm(s.textContent);
if (val) return s;
}
}

const all = Array.from(document.querySelectorAll("body *"));
const pos = all.indexOf(labelEl);

for (let i = pos + 1; i < Math.min(all.length, pos + 150); i++) {
const e = all[i];
const val = tnorm(e.textContent);
if (val) return e;
}

return null;
}


// ============================================================
// 3. Admin 요소 보임 여부 체크
// ============================================================

function isVisible(el) {
if (!el) return false;
if (el.offsetParent !== null) return true;
return el.getClientRects && el.getClientRects().length > 0;
}

function findVisibleLabelExactCI(text) {
const all = document.querySelectorAll("th, td, div, span, a, button");

for (const el of all) {
const txt = tnorm(el.textContent || "");
if (!txt) continue;
if (ciEq(txt, text) && isVisible(el)) return el;
}

return null;
}


// ============================================================
// 4. Admin 데이터 추출
// ============================================================

function extractAdminAndHighlight() {

if (!isAdminMatchingPage())
return { kan: null, unit: null, vendor: null, siteitem: null };

let kan = null;
let unit = null;
let vendor = null;
let siteitem = null;

// ① KAN
const kanLabel = findLabelExactCI("KAN ID");
if (kanLabel) {
const valEl = findValueUnder(kanLabel);
if (valEl) {
const v = tnorm(valEl.textContent);
if (KAN_REGEX.test(v)) kan = v;
}
}

// ② UNITNAME1
const unitLabel = findLabelExactCI("UNITNAME1");
if (unitLabel) {
const valEl = findValueUnder(unitLabel);
if (valEl) {
const v = tnorm(valEl.textContent);
if (UNIT_REGEX.test(v)) unit = v;
}
}

// ③ Vendoritem
const vendorLabel = findLabelExactCI("Vendoritem ID");
if (vendorLabel) {
const valEl = findValueUnder(vendorLabel);
if (valEl) {
const v = (valEl.textContent || "").trim();
if (/^[0-9]{9,12}$/.test(v)) vendor = v;
}
}

// ④ Siteitem
let shouldRemoveCachedSiteitem = true;

{
const siteItemLabelVisible = findVisibleLabelExactCI("사이트 아이템 ID");

if (siteItemLabelVisible) {

const th = siteItemLabelVisible.closest("th") ||
siteItemLabelVisible.closest("td") ||
siteItemLabelVisible;

if (th && isVisible(th)) {

const table = th.closest("table");
if (table && isVisible(table)) {

const headerRow = th.parentElement;
const headers = Array.from(headerRow.children);
const idx = headers.indexOf(th);

if (idx >= 0) {

const bodyRows = table.querySelectorAll("tbody tr");
const rows = (bodyRows.length ? Array.from(bodyRows)
: Array.from(table.querySelectorAll("tr")))
.filter(tr => isVisible(tr)
&& tr.querySelector("td")
&& tr.textContent.trim() !== "");

if (rows.length === 1) {

const cells = rows[0].querySelectorAll("td");

if (cells[idx]) {

const divs = cells[idx].querySelectorAll("div, span, p");
for (const d of divs) {
const txt = (d.textContent || "").trim();
if (/^[0-9]{1,14}$/.test(txt)) {
siteitem = txt;
break;
}
}

if (!siteitem) {
const raw = (cells[idx].textContent || "").trim();
const m = raw.match(/\b\d{1,14}\b/);
if (m) siteitem = m[0];
}
}
}
}
}
}
}

if (siteitem) shouldRemoveCachedSiteitem = false;
}

// 저장
const toStore = {};

if (kan && KAN_REGEX.test(kan)) toStore.__ext_last_kan = kan;
if (unit && UNIT_REGEX.test(unit)) toStore.__ext_last_unit = unit;
if (vendor) toStore.__ext_last_vendor = vendor;
if (siteitem) toStore.__ext_last_siteitem = siteitem;

if (Object.keys(toStore).length) {

chrome.storage.local.set(toStore);

if (shouldRemoveCachedSiteitem) {
chrome.storage.local.remove(["__ext_last_siteitem"]);
}

} else {

chrome.storage.local.remove([
"__ext_last_kan",
"__ext_last_unit",
"__ext_last_vendor",
"__ext_last_siteitem"
]);
}

const isKanOK = !!kan && KAN_REGEX.test(kan);
const isUnitOK = !!unit && UNIT_REGEX.test(unit);
const isVendorOK = !!vendor && /^[0-9]{9,12}$/.test(vendor);

chrome.storage.local.get(
["__ext_admin_tabs", "__ext_admin_viid_ok", "__ext_admin_error"],
(res) => {

const tabCount = res.__ext_admin_tabs || 0;
const hasValidResult = res.__ext_admin_viid_ok;
const prevError = res.__ext_admin_error;

let isError = !(isKanOK && isUnitOK && isVendorOK);

if (tabCount === 0 || tabCount > 1 || !hasValidResult) {
isError = true;
}

if (prevError !== isError) {
chrome.storage.local.set(
{ __ext_admin_error: isError },
() => console.log("[CONTENT] __ext_admin_error 갱신:", prevError, "→", isError)
);
}
}
);

return { kan, unit, vendor, siteitem };
}


// ============================================================
// 5. Admin 라우트 변경 감지
// ============================================================

function onAdminRouteChange() {
if (isAdminMatchingPage())
extractAdminAndHighlight();
else
clearAdminHighlights();
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (msg && msg.action === "extract_and_highlight") {
const data = extractAdminAndHighlight();
sendResponse(data);
return true;
}
});

/* ============================================================
6. Admin 전체 메인 실행
============================================================ */

function main() {

if (isAdminPage()) {

// ★ 페이지 처음 열릴 때 Admin 정보 불러오기
onAdminRouteChange();

// ★ Admin은 hash(#/matching/1234) 기반 네비게이션이라
// 상품 클릭할 때마다 이 이벤트가 꼭 필요함
window.addEventListener("hashchange", onAdminRouteChange);

// ★ Admin 화면은 AJAX 갱신이 많기 때문에
// DOM 변화를 계속 감시해야 버튼/값이 유지됨
let raf;
const mo = new MutationObserver(() => {
if (raf) cancelAnimationFrame(raf);
raf = requestAnimationFrame(onAdminRouteChange);
});

mo.observe(document.body, {
childList: true,
subtree: true,
attributes: true,
});
}
}

/* ============================================================
7. DOM 로딩 이후 main 실행
============================================================ */

if (document.readyState === "loading") {
document.addEventListener("DOMContentLoaded", main);
} else {
main();
}

})();
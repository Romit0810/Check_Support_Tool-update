// ============================================================
// blackseller-naver.js
// 확장에 CSV 파일 업로드 후 사용
// 네이버 문제 풀이후 검색없이 블랙셀러 확인
// ============================================================

console.log("[NAVER] content-naver.js 로드됨:", location.href);

(function () {

// ============================================================
// 0. 기본 색상/변수
// ============================================================

const HIGHLIGHT_COLOR = "#ffff00"; // 하이라이트 색 (노란색)

// 중복 실행을 막기 위한 간단한 잠금 변수들
let __ext_safeStartLock = false; // safeStart 중복방지
let __ext_lastBannerText = ""; // 이전 배너 텍스트 기억
let __ext_prevKan = ""; // 이전 KAN 값 기억
let __ext_prevSellerHash = ""; // 이전 판매자정보 해시 기억


// ============================================================
// 1. 특정 문구(라벨) 목록
// ============================================================

const FIELDS = {
phones: ["고객센터", "A/S 책임자와 전화번호", "재화등의 A/S 관련 전화번호"],
biznum: ["사업자등록번호"],
address: ["사업장 소재지"],
email: ["e-mail"],
};


// ============================================================
// 2. 기본적인 문자열 처리 함수
// ============================================================

// 문자열을 깔끔하게 정리 (여러 칸 공백 → 한 칸)
const t = (s) => String(s || "").replace(/\s+/g, " ").trim();

// 어떤 라벨이 FIELDS 안의 항목과 일치하는지 체크
const includesAny = (label, arr) =>
arr.some((k) => t(label).includes(k));

// 판매자 정보를 비교하기 위해 작은 문자열로 묶어서 해시처럼 사용
function makeSellerHash(sellerData) {
return JSON.stringify(sellerData || {}).replace(/\s+/g, "");
}


// ============================================================
// 3. 판매자 정보 추출 (네이버 팝업 구조 전용)
// ============================================================

function extractSellerInfo() {

const info = { tel: [], biznum: "", address: "", email: "" };
const rows = document.querySelectorAll("dt");

rows.forEach((dt) => {

const key = t(dt.textContent);
const dd = dt.nextElementSibling;
if (!key || !dd) return;

// 불필요한 버튼 제거 (원본 기능 유지)
dd.querySelectorAll("button,a").forEach(b => b.remove());

// 판매자 정보 텍스트 가져오기
let val = (dd.textContent || "")
.replace(/\(.*?잘\s*못\s*된[\s\S]*?번호\s*신고.*?\)/gi, "")
.replace(/[\u200B-\u200D\uFEFF]/g, "") // 보이지 않는 문자 제거
.replace(/\s+/g, " ")
.replace(/인증\s*$/g, "") // "인증" 문구 제거
.trim();

// 전화번호 3종류 분리 저장
if (key.includes("고객센터")) info.telCustomer = val || "";
else if (key.includes("A/S 책임자")) info.telAS = val || "";
else if (key.includes("재화등의 A/S")) info.telEtc = val || "";

// 사업자번호 / 주소 / 이메일 처리
if (includesAny(key, FIELDS.biznum)) {
info.biznum = val; return;
}
if (includesAny(key, FIELDS.address)) {
info.address = val; return;
}
if (includesAny(key.toLowerCase(), FIELDS.email.map((s) => s.toLowerCase()))) {
info.email = val; return;
}
});

return info;
}


// ============================================================
// 4. 상단 KAN 배너 표시
// ============================================================

function showTopKanBanner(text, filename, isError = false) {

const id = "__ext_naver_top_kan__";
let el = document.getElementById(id);

if (!el) {
el = document.createElement("div");
el.id = id;

Object.assign(el.style, {
position: "fixed",
top: "10px",
left: "50%",
transform: "translateX(-50%)",
zIndex: "2147483647",
pointerEvents: "none",
background: isError ? "#ff2a2a" : "rgba(20,20,20,0.88)",
color: "#fff",
fontSize: isError ? "18px" : "13px",
fontWeight: isError ? "800" : "normal",
padding: "8px 14px",
borderRadius: "10px",
boxShadow: "0 3px 8px rgba(0,0,0,0.3)",
whiteSpace: "pre-line",
lineHeight: "1.4",
textAlign: "center"
});

document.body.appendChild(el);
}

// 파일명이 있으면 파일명 먼저 표시
if (filename) {
el.textContent = `📁 ${filename}\n${text}`;
} else {
el.textContent = text;
}

// 같은 내용이면 다시 렌더링 안 함
if (__ext_lastBannerText === el.textContent) return;
__ext_lastBannerText = el.textContent;
}


// ============================================================
// 5. 하단 정보 패널 (토글 기능 포함)
// ============================================================

function showBottomInfoPanel(sellerData, verificationText = "") {

const id = "__ext_naver_bottom_info__";
let el = document.getElementById(id);

// 존재 여부만 체크 (스타일은 아래에서 항상 다시 적용)
if (!el) {
el = document.createElement("div");
el.id = id;
document.body.appendChild(el);
}

// 하단 배너 폭 변경시 여기서 변경 1
Object.assign(el.style, {
position: "fixed",
left: "12px",
bottom: "12px",
zIndex: "2147483647",
pointerEvents: "auto",
background: "rgba(20,20,20,0.88)",
color: "#fff",
fontSize: "13px",

// 하단 배너 폭 변경시 여기서 변경 2
display: "inline-block",
maxWidth: "260px",
whiteSpace: "normal",
wordBreak: "break-word",
padding: "10px 12px",

borderRadius: "10px",
boxShadow: "0 4px 12px rgba(0,0,0,0.35)",
lineHeight: "1.4"
});

// 내부 HTML은 한 번만 생성
if (!el.innerHTML) {

el.innerHTML = `
<div id="verificationHeader" style="cursor:pointer; user-select:none;">
검증결과: ${verificationText || ""} <span id="toggleArrow" style="font-size:12px;">▼</span>
</div>
<div id="sellerDetails" style="display:none; margin-top:8px; white-space:normal;">
고객센터: ${sellerData?.telCustomer || ""}<br>
A/S 책임자와 전화번호: ${sellerData?.telAS || ""}<br>
재화등의 A/S 관련 전화번호: ${sellerData?.telEtc || ""}<br>
사업자등록번호: ${sellerData?.biznum || ""}<br>
사업장 소재지: ${sellerData?.address || ""}<br>
e-mail: ${sellerData?.email || ""}
</div>
`;

const header = el.querySelector("#verificationHeader");
const detailsDiv = el.querySelector("#sellerDetails");
const arrow = el.querySelector("#toggleArrow");

header.addEventListener("click", () => {

const isHidden = detailsDiv.style.display === "none";
detailsDiv.style.display = isHidden ? "block" : "none";
arrow.textContent = isHidden ? "▲" : "▼";

chrome.storage.local.get(["__ext_uploaded_csv", "__ext_last_kan"], (res) => {
const csvText = res.__ext_uploaded_csv || "";
const kan = res.__ext_last_kan || "";
const result = compareWithBlacklist(kan, sellerData, csvText);
highlightMatchedValues(result?.highlightVals || []);
});
});
}
}

// ============================================================
// 6. 기존 하이라이트 제거
// ============================================================

function clearHighlights() {
// 기존에 <mark>로 감싸둔 부분들 전부 원래 글자로 되돌림
document.querySelectorAll("mark").forEach(m => {
const parent = m.parentNode;
if (!parent) return;

// mark 태그 안에 있는 실제 글자들을 mark 바깥으로 빼줌
parent.replaceChild(document.createTextNode(m.textContent), m);
parent.normalize(); // 텍스트 노드 깨끗하게 합쳐줌
});
}

// ============================================================
// 7. 하이라이트 처리
// ============================================================

function highlightMatchedValues(values) {
if (!values || !values.length) return;

values.forEach(val => {
if (!val) return;

// 정규식으로 "완전 동일한 단어"만 찾도록 설정
const escaped = val.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const regex = new RegExp(`(?<![0-9A-Za-z])${escaped}(?![0-9A-Za-z])`, "gi");

const walker = document.createTreeWalker(
document.body,
NodeFilter.SHOW_TEXT,
null,
false
);

while (walker.nextNode()) {
const node = walker.currentNode;

// 값이 없거나 일치하는 부분이 없으면 넘어감
if (!regex.test(node.nodeValue)) continue;

const range = document.createRange();
const idx = node.nodeValue.search(regex);
if (idx === -1) continue;

const mark = document.createElement("mark");
mark.style.background = HIGHLIGHT_COLOR;
mark.textContent = val;

range.setStart(node, idx);
range.setEnd(node, idx + val.length);
range.surroundContents(mark);
}
});
}


// ============================================================
// 8. CSV와 비교해서 블랙셀러 여부 확인
// ============================================================

function compareWithBlacklist(kan, sellerData, csvText) {

try {
const lines = csvText
.split(/\r?\n/)
.map(l => l.trim())
.filter(Boolean);

if (lines.length < 2) return { matchType: null, highlightVals: [] };

// CSV 헤더 위치 찾기
const headers = lines[0].split(",");

const idxKAN = headers.indexOf("KANID");
const idxBiz = headers.indexOf("사업자번호");
const idxAddr = headers.indexOf("주소지");
const idxEmail = headers.indexOf("e-mail");
const idxPhone = headers.indexOf("전화번호");
const idxBlack = headers.indexOf("블랙셀러 여부");
const idxResult = headers.indexOf("검증결과"); // 배너용

if (idxKAN < 0 || idxBiz < 0 || idxAddr < 0 || idxEmail < 0 || idxPhone < 0 || idxBlack < 0) {
return { matchType: null, highlightVals: [] };
}

// 문자열 통일 (공백·특수문자 제거)
const norm = s => String(s || "")
.replace(/\r|\n/g, "")
.replace(/[\u00A0\u200B-\u200D\uFEFF]/g, "")
.replace(/[‐-‒–—―−]/g, "-")
.replace(/\s+/g, " ")
.trim();

// 전화번호는 숫자만 남김 (+82 → 0 변환)
const normPhone = s => String(s || "")
.replace(/[^\d]/g, "")
.replace(/^82/, "0")
.trim();

let matchType = null;
let highlightVals = [];
let verificationValue = "";

// CSV 실제 데이터 부분 반복
for (let i = 1; i < lines.length; i++) {

const cols = lines[i].split(",");

// KANID는 한 칸에 여러 개가 들어갈 수 있음 (예: "123/ALL")
const csvKanField = cols[idxKAN] || "";
const kanList = csvKanField
.split("/")
.map(k => k.trim().toUpperCase());

const curKAN = String(kan).toUpperCase();

if (!kanList.includes(curKAN) && !kanList.includes("ALL")) continue;

// 항목별 완전 일치 비교
const sameBiz = sellerData.biznum && norm(cols[idxBiz]) === norm(sellerData.biznum);
const sameAddr = sellerData.address && norm(cols[idxAddr]) === norm(sellerData.address);
const sameEmail = sellerData.email && norm(cols[idxEmail]) === norm(sellerData.email);

const csvPhone = normPhone(cols[idxPhone]);
const phoneMatches = Object.values(sellerData)
.filter(v => typeof v === "string" && v.match(/\d{2,}/))
.filter(p => normPhone(p) === csvPhone);

const samePhone = phoneMatches.length > 0;
const black = norm(cols[idxBlack]);

// 검증결과 값 (배너용)
if (sameBiz || sameAddr || sameEmail || samePhone) {
verificationValue = cols[idxResult] || "";
}

// 블랙셀러 ON 조건
if (black === "Blackseller On" && (sameBiz || sameAddr || sameEmail || samePhone)) {

matchType = kanList.includes("ALL") ? "ALL" : "ON";

if (sameBiz) highlightVals.push(sellerData.biznum);
if (sameAddr) highlightVals.push(sellerData.address);
if (sameEmail) highlightVals.push(sellerData.email);
if (samePhone) highlightVals.push(...phoneMatches);
}
}

return {
matchType,
highlightVals,
verification: verificationValue,
};

} catch (e) {
// 에러를 콘솔에만 간단하게 남김
console.warn("[NAVER] compare 실패:", e);
return null;
}
}


// ============================================================
// 9. 메인 실행 (start)
// ============================================================

function start() {

const sellerData = extractSellerInfo();

// dt/dd가 아직 로딩 안 되어 있으면 잠시 후 다시 시도
if (!sellerData || !document.querySelector("dt") || !document.querySelector("dd")) {
setTimeout(start, 500);
return;
}

chrome.storage.local.get(
["__ext_last_kan", "__ext_admin_error", "__ext_uploaded_csv", "__ext_uploaded_filename"],
(res) => {

const kan = res.__ext_last_kan;
const adminErr = res.__ext_admin_error;
const csvText = res.__ext_uploaded_csv;
const filename = res.__ext_uploaded_filename;

// KAN ID 오류
if (adminErr === true) {
showTopKanBanner("KAN ID 오류", null, true);
clearHighlights();
return;
}

// KAN 아직 없음 → 오류 아님, 대기
if (!kan) {
return;
}

// CSV 파일 미업로드 → 사용 불가 상태
if (!csvText) {
showTopKanBanner("CSV 파일 미업로드", null, true);
clearHighlights();
return;
}


// CSV 비교
const result = compareWithBlacklist(kan, sellerData, csvText);

if (!result) {
showTopKanBanner(`KAN ID : ${kan} / 파일 오류`, filename);
showBottomInfoPanel(sellerData);
return;
}

// 배너 내용 조립
let banner = `KAN ID : ${kan}`;
if (result.matchType === "ON") banner += " / 블랙셀러 ON";
if (result.matchType === "ALL") banner += " / 블랙셀러 ALL";

showTopKanBanner(banner, filename);
showBottomInfoPanel(sellerData, result.verification || "");

// 하이라이트 적용
highlightMatchedValues(result.highlightVals);
}
);
}

// ============================================================
// 10. safeStart (중복 실행 잠금 강화 → CPU 절약 핵심)
// ============================================================

function safeStart() {

// 이미 실행 중이면 또 실행하지 않음 → 무한 반복 호출 차단
if (__ext_safeStartLock) return;
__ext_safeStartLock = true;

try {
const sellerData = extractSellerInfo();

// 판매자정보가 아직 안 떴으면 잠시 후 다시 시도
if (!sellerData) {
setTimeout(() => {
__ext_safeStartLock = false;
safeStart();
}, 500);
return;
}

// KAN/판매자정보 변화 감지 → 변화 없으면 다시 실행하지 않음
chrome.storage.local.get("__ext_last_kan", (res) => {

const curKan = res.__ext_last_kan || "";
const curSellerHash = makeSellerHash(sellerData);

// 이전과 완전히 동일하면 아무 것도 하지 않음 (CPU 절약)
if (curKan === __ext_prevKan && curSellerHash === __ext_prevSellerHash) {
__ext_safeStartLock = false;
return;
}

// 변화가 있을 때만 start() 처리
__ext_prevKan = curKan;
__ext_prevSellerHash = curSellerHash;

clearHighlights(); // 기존 표시 제거
start(); // 실제 실행
});

} catch (e) {
console.warn("[NAVER] safeStart 오류:", e);

} finally {
// 0.8초 뒤에 잠금 해제 => 무한 반복 방지 + 과도한 호출 제한
setTimeout(() => { __ext_safeStartLock = false; }, 800);
}
}


// ============================================================
// 11. 초기 진입 시 safeStart를 일정 시간 후 실행
// ============================================================

// DOM이 완전히 뜬 뒤에 실행하도록 약간의 여유 시간 줌
setTimeout(() => safeStart(), 800);

window.addEventListener("DOMContentLoaded", () =>
setTimeout(safeStart, 500)
);


// ============================================================
// 12. 페이지 변화 감지 (MutationObserver)
// ============================================================

let moTimer;
const mo = new MutationObserver(() => {

// 작은 변화들이 연속적으로 발생하면 여러 번 실행되는 걸 방지
clearTimeout(moTimer);

// requestAnimationFrame을 이용해서 화면이 안정된 뒤 실행
if (window.__naver_rAF) cancelAnimationFrame(window.__naver_rAF);
window.__naver_rAF = requestAnimationFrame(() => safeStart());
});

// 메뉴 열림/닫힘, 버튼 클릭 등 대부분의 DOM 변화를 감지
mo.observe(document.body, { childList: true, subtree: true });


// ============================================================
// 13. “인증” 버튼 자동 삭제용 MutationObserver
// ============================================================

const moBtns = new MutationObserver(() => {

// 새로 생긴 인증 버튼들만 제거
const btns = document.querySelectorAll("button");
btns.forEach(b => {
if (b.textContent.includes("인증")) b.remove();
});
});

moBtns.observe(document.body, { childList: true, subtree: true });


// ============================================================
// 14. KAN 변경 감지 이벤트
// ============================================================

chrome.storage.onChanged.addListener((changes, area) => {

if (area !== "local") return;

if (changes.__ext_last_kan) {
// KAN 바뀌면 즉시 비교 로직 다시 실행
clearTimeout(window.__ext_kanChangeTimer);
window.__ext_kanChangeTimer = setTimeout(() => safeStart(), 300);
}
});


// ============================================================
// 15. 검증결과 배너
// ============================================================

function showVerificationBanner(resultText) {

const id = "__ext_naver_verification_banner__";
let el = document.getElementById(id);

if (!el) {
el = document.createElement("div");
el.id = id;

Object.assign(el.style, {
position: "fixed",
left: "12px",
bottom: "12px",
zIndex: "2147483647",
pointerEvents: "auto",
background: "rgba(20,20,20,0.88)",
color: "#fff",
fontSize: "13px",
display: "inline-block",
maxWidth: "280px",
whiteSpace: "normal",
wordBreak: "break-word",
padding: "10px 12px",
borderRadius: "10px",
boxShadow: "0 4px 12px rgba(0,0,0,0.35)",
lineHeight: "1.5"
});

document.body.appendChild(el);
}

el.textContent = `검증결과: ${resultText || ""}`;
}

})();
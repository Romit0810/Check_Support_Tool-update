// ============================================================
// blackseller-csv.js
// 블랙셀러 페이지에서 직접 검색하는 방식
// admin.js+blackseller-csv.js였던걸 분리함
// ============================================================

console.log("[CONTENT] blackseller-csv.js 로드됨:", location.href);

(function () {

// ============================================================
// 0. 공통 상수 / 유틸 함수
// ============================================================

const HIGHLIGHT_COLOR = "#ffff00"; // ON 또는 ALL인경우 (노란색)
const HIGHLIGHT_GRAY = "#d9d9d9"; // OFF인경우 (연회색)

// KAN ID / UNITNAME 형식 체크용 정규식
const KAN_REGEX = /^[0-9]{3,4}$/;
const UNIT_REGEX = /^[A-Za-z0-9&, ]+$/;

// 문자열 정리 (공백 통일)
const tnorm = (s) => (s || "").replace(/\s+/g, " ").trim();

// 대소문자 무시 비교
const ciEq = (a, b) => tnorm(a).toLowerCase() === tnorm(b).toLowerCase();

// ============================================================
// 2. 블랙셀러 페이지 감지
// ============================================================

function isBlackSeller() {
return location.protocol === "file:";
}

function findKanidHeader() {
const all = document.querySelectorAll("th, td, div, span");
for (const el of all) {
const txt = tnorm(el.textContent || "");
if (ciEq(txt, "KANID")) {
return el.closest("th") || el;
}
}
return null;
}

function findBSHeader() {
const all = document.querySelectorAll("th, td, div, span");
for (const el of all) {
const txt = tnorm(el.textContent || "");
if (ciEq(txt, "블랙셀러 여부")) {
return el.closest("th") || el;
}
}
return null;
}

function getKanidColumnInfo() {
const headerEl = findKanidHeader();
const bsHeader = findBSHeader();

if (!headerEl || !bsHeader) return null;

const table = headerEl.closest("table");
if (!table) return null;

const headerRow = headerEl.parentElement;
const cells = Array.from(headerRow.children);
const colIndex = cells.indexOf(headerEl);

const bsRow = bsHeader.parentElement;
const bsCells = Array.from(bsRow.children);
const bsIndex = bsCells.indexOf(bsHeader);

return { table, colIndex, bsIndex };
}


// ============================================================
// 3. 검색 여부 확인
// ============================================================

function isSearchBlank() {
const inp = document.querySelector("#searchInput");
return !inp || !inp.value || inp.value.trim() === "";
}

function hasBSResults(retry = 0) {
const tbl = document.querySelector("#dataTable");
if (!tbl) return false;

const rows = tbl.querySelectorAll("tbody tr, tr");
const valid = Array.from(rows).some(
tr => tr.querySelector("td") && tr.textContent.trim() !== ""
);

if (!valid && retry < 3) {
console.warn(`[CONTENT] 데이터테이블 비어있음 → 재시도 ${retry + 1}`);
setTimeout(() => hasBSResults(retry + 1), 400);
return false;
}

return valid;
}


// ============================================================
// 4. 배너 렌더링
// ============================================================

function ensureBannerAboveTable(text, tableEl, highlight) {
const id = "__ext_bs_banner__";
let banner = document.getElementById(id);

if (!banner) {
banner = document.createElement("div");
banner.id = id;
banner.style.fontSize = "14px";
banner.style.fontWeight = "700";
banner.style.padding = "6px 8px";
banner.style.display = "block";
banner.style.margin = "0 0 8px 0";
}

banner.style.background = highlight ? "#000000" : "transparent";
banner.style.color = highlight ? "#ffffff" : "#000000";

if (banner.textContent !== text)
banner.textContent = text;

if (!(banner.parentNode === tableEl.parentNode && banner.nextSibling === tableEl)) {
tableEl.parentNode.insertBefore(banner, tableEl);
}
}


// ============================================================
// 5. 테이블 하이라이트
// ============================================================

function highlightWithinKanidColumn(kan) {
const info = getKanidColumnInfo();
if (!info) return { hasKAN: false, hasALL: false, table: null };

const { table, colIndex, bsIndex } = info;

if (isSearchBlank() || !hasBSResults()) {
return { hasKAN: false, hasALL: false, table };
}

let hasKAN = false;
let hasALL = false;

const rows = table.tBodies && table.tBodies.length
? Array.from(table.tBodies).flatMap(tb => Array.from(tb.rows))
: Array.from(table.rows);

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({
"&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;"
}[c]));

const ALL_WORD_RE = /\ball\b/i;

for (const row of rows) {

const cell = row.cells && row.cells[colIndex];
const bsCell = row.cells && row.cells[bsIndex];

if (!cell || !bsCell) continue;

const rawTxt = cell.textContent || "";
const txt = tnorm(rawTxt);
const bsTxt = tnorm(bsCell.textContent || "");

if (!txt) continue;

if (txt.includes(String(kan)) && ciEq(bsTxt, "Blackseller On")) {
const idx = txt.indexOf(String(kan));
const before = esc(txt.slice(0, idx));
const match = esc(txt.slice(idx, idx + String(kan).length));
const after = esc(txt.slice(idx + String(kan).length));
cell.innerHTML = `${before}<mark data-ext-highlight-bs="1">${match}</mark>${after}`;
hasKAN = true;
continue;
}

const allMatch = txt.match(ALL_WORD_RE);
if (allMatch && ciEq(bsTxt, "Blackseller On")) {
const idx = txt.toLowerCase().indexOf(allMatch[0].toLowerCase());
const before = esc(txt.slice(0, idx));
const match = esc(txt.slice(idx, idx + 3));
const after = esc(txt.slice(idx + 3));
cell.innerHTML = `${before}<mark data-ext-highlight-bs="1">${match}</mark>${after}`;
hasALL = true;
continue;
}

if (txt.includes(String(kan))) {
cell.innerHTML = `<mark data-ext-highlight-bs="gray">${esc(txt)}</mark>`;
continue;
}

if (allMatch) {
cell.innerHTML = `<mark data-ext-highlight-bs="gray">${esc(txt)}</mark>`;
continue;
}
}

return { hasKAN, hasALL, table };
}


// ============================================================
// 6. 블랙셀러 메인
// ============================================================

function runBlackSeller() {

chrome.storage.local.get(["__ext_last_kan"], (res) => {

const kan = res.__ext_last_kan;

if (!kan) {
const old = document.getElementById("__ext_bs_banner__");
if (old) old.remove();
return;
}

const { hasKAN, hasALL, table } =
highlightWithinKanidColumn(String(kan));

if (!table) {
const old = document.getElementById("__ext_bs_banner__");
if (old) old.remove();
return;
}

let banner = `KAN ID : ${kan}`;
let highlight = false;

if (hasKAN) { banner += " / 블랙셀러 ON"; highlight = true; }
if (hasALL) { banner += " / 블랙셀러 ALL"; highlight = true; }

ensureBannerAboveTable(banner, table, highlight);
});
}


// ============================================================
// 7. 전체 실행
// ============================================================

function main() {

if (isBlackSeller()) {

function safeRunBlackSeller() {
chrome.storage.local.get("__ext_admin_error", (res) => {

// 먼저 현재 table 존재 여부 확인
const info = getKanidColumnInfo();
const table = info && info.table;

// 표 자체가 없으면 (CSV 미검색 상태와 동일)
if (!table) {
const old = document.getElementById("__ext_bs_banner__");
if (old) old.remove();
return;
}

// KAN 오류일 때
if (res.__ext_admin_error) {

// 기존 배너 위치 그대로, 오류 문구로 교체
ensureBannerAboveTable("오류", table, true);

// 하이라이트 제거
document
.querySelectorAll("[data-ext-highlight-bs]")
.forEach(el => {
el.style.background = "";
el.removeAttribute("data-ext-highlight-bs");
});

return;
}

// 정상일 때만 기존 로직 실행
runBlackSeller();
});
}

safeRunBlackSeller();

let raf;
const mo = new MutationObserver(() => {
if (raf) cancelAnimationFrame(raf);
raf = requestAnimationFrame(safeRunBlackSeller);
});

mo.observe(document.body, { childList: true, subtree: true });

chrome.storage.onChanged.addListener((changes, area) => {
if (area !== "local") return;

if ("__ext_last_kan" in changes) {
console.log("[CONTENT] __ext_last_kan 변경:", changes.__ext_last_kan.newValue);
safeRunBlackSeller();
}

if ("__ext_admin_error" in changes) {
console.log("[CONTENT] __ext_admin_error 변경:", changes.__ext_admin_error.newValue);
safeRunBlackSeller();
}
});

const search = document.querySelector("#searchInput");
if (search) {
["input", "change", "keyup", "search"].forEach(ev =>
search.addEventListener(ev, () => safeRunBlackSeller())
);
}
}

}


// ============================================================
// 8. DOM 로딩 후 실행
// ============================================================

if (document.readyState === "loading") {
document.addEventListener("DOMContentLoaded", main);
} else {
main();
}


// ============================================================
// 9. 스타일 삽입
// ============================================================

const style = document.createElement("style");
style.textContent = `
[data-ext-highlight-bs="1"] { background: ${HIGHLIGHT_COLOR} !important; }
[data-ext-highlight-bs="gray"] { background: ${HIGHLIGHT_GRAY} !important; }
`;
document.documentElement.appendChild(style);

})();

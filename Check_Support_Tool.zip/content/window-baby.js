// =============================================================
// window-baby.js
// baby 칸아이디 + 네이버윈도우 + 1+1 행사중일때 실행됨
// =============================================================

(function () {

// -------------------------------------------------------------
// 1. 네이버 window 페이지인지 확인
// -------------------------------------------------------------
function isNaverWindowPage() {
return /^https?:\/\/shopping\.naver\.com\/window/i.test(location.href);
}
if (!isNaverWindowPage()) return;


// -------------------------------------------------------------
// 2. KAN ID 목록
// -------------------------------------------------------------
const ELIGIBLE_KANS = new Set([
"318", "319", "320", "321", "324", "5116", "5117", "8584", "8585", "5409", "323",
"8578", "8856", "1096", "8577", "8579", "1095", "8153", "8606", "5892", "6138",
"1094", "1093", "8580", "8862", "8605", "6711", "327", "6120", "1097", "1417",
"8152", "8877", "9515", "9516", "9600", "9601", "9606", "9608", "9609", "9610",
"9611", "9632", "9633", "9712"
]);


// -------------------------------------------------------------
// 3. 파란 정보 박스 찾기
// -------------------------------------------------------------
function getBlueBlock() {
return document.querySelector("div.RUSA6W3qmn");
}

function hasOnePlusOneText(block) {
if (!block) return false;
try {
return /1\s*\+\s*1/.test(block.innerText);
} catch {
return false;
}
}


// -------------------------------------------------------------
// 4. 기존 mark 제거 (중복 방지)
// -------------------------------------------------------------
function clearMarks(block) {
if (!block) return;

block.querySelectorAll('mark[data-ext-naver11="1"]').forEach(mark => {
const parent = mark.parentNode;
while (mark.firstChild) parent.insertBefore(mark.firstChild, mark);
parent.removeChild(mark);
});
}


// -------------------------------------------------------------
// 5. "1+1" 글자를 mark로 감싸서 강조
// - Range 사용 : DOM 깨짐 방지
// -------------------------------------------------------------
function highlightOnePlusOne(block) {
if (!block) return;
clearMarks(block);

const walker = document.createTreeWalker(block, NodeFilter.SHOW_TEXT);
const nodes = [];
while (walker.nextNode()) nodes.push(walker.currentNode);

const fullText = nodes.map(n => n.nodeValue || "").join("");
const regex = /1\s*\+\s*1/g;

let match;
const matches = [];
while ((match = regex.exec(fullText))) {
matches.push({
start: match.index,
end: match.index + match[0].length
});
}
if (!matches.length) return;

let offset = 0;
for (const node of nodes) {
const text = node.nodeValue || "";
const startPos = offset;
const endPos = offset + text.length;

matches.forEach(({ start, end }) => {
if (end <= startPos || start >= endPos) return;

const markStart = Math.max(0, start - startPos);
const markEnd = Math.min(text.length, end - startPos);

try {
const range = document.createRange();
range.setStart(node, markStart);
range.setEnd(node, markEnd);

const el = document.createElement("mark");
el.setAttribute("data-ext-naver11", "1");
el.style.background = "#ffff00";

range.surroundContents(el);
} catch {
// fallback 처리 (DOM이 특이한 경우)
const before = text.slice(0, markStart);
const mid = text.slice(markStart, markEnd);
const after = text.slice(markEnd);

const wrapper = document.createElement("span");
wrapper.innerHTML =
(before || "") +
`<mark data-ext-naver11="1" style="background:#ffff00;">${mid}</mark>` +
(after || "");

node.replaceWith(wrapper);
}
});

offset += text.length;
}
}


// -------------------------------------------------------------
// 6. mark 색이 네이버 CSS에 덮이지 않도록 고정
// -------------------------------------------------------------
function ensureMarkStyle() {
if (document.getElementById("__ext_naver11_style__")) return;

const st = document.createElement("style");
st.id = "__ext_naver11_style__";
st.textContent =
`mark[data-ext-naver11="1"]{background:#ffff00 !important;}`;
document.head.appendChild(st);
}


// -------------------------------------------------------------
// 7. 파란 박스가 새로 갱신될 때 다시 적용
// -------------------------------------------------------------
function observeBlueBlock() {
const parent = document.querySelector("fieldset.zFcPceRwDS") || document.body;
if (!parent) return;

let rafId = null;

function recheck() {
if (rafId) cancelAnimationFrame(rafId);

rafId = requestAnimationFrame(() => {
const block = getBlueBlock();
if (!block) return;

if (hasOnePlusOneText(block)) {
ensureMarkStyle();
highlightOnePlusOne(block);
observeInside(block);
}
});
}

new MutationObserver(recheck)
.observe(parent, { childList: true, subtree: true });

recheck();
}


// -------------------------------------------------------------
// 8. 박스 내부 변동 감지 → 자동 재강조
// -------------------------------------------------------------
function observeInside(block) {
if (block.__ext_naver11_observed) return;
block.__ext_naver11_observed = true;

let rafId = null;

new MutationObserver(() => {
if (rafId) cancelAnimationFrame(rafId);
rafId = requestAnimationFrame(() => {
if (hasOnePlusOneText(block)) highlightOnePlusOne(block);
});
}).observe(block, {
childList: true,
subtree: true,
characterData: true
});
}


// -------------------------------------------------------------
// 9. Baby 팝업 띄우기
// -------------------------------------------------------------
function showNaverPromoModal() {
if (window.__ext_naver_promo_shown) return;
window.__ext_naver_promo_shown = true;

const backdrop = document.createElement("div");
backdrop.id = "__ext_naver_promo_backdrop__";
backdrop.style.position = "fixed";
backdrop.style.inset = "0";
backdrop.style.background = "rgba(255, 255, 255, 0.45)";
backdrop.style.zIndex = "2147483646";

// Card (진한 회색 반투명 + 흰 텍스트)
const card = document.createElement("div");
card.id = "__ext_naver_promo_card__";
card.style.position = "fixed";
card.style.top = "50%";
card.style.left = "50%";
card.style.transform = "translate(-50%,-50%)";
card.style.background = "rgba(26, 26, 26, 0.91)";
card.style.borderRadius = "14px";
card.style.boxShadow = "0 10px 30px rgba(255, 255, 255, 0.35)";
card.style.padding = "18px 20px 14px";
card.style.minWidth = "280px";
card.style.maxWidth = "90vw";
card.style.zIndex = "2147483647";
card.style.fontFamily = "system-ui, -apple-system, Segoe UI, Roboto, sans-serif";
card.style.textAlign = "center";
card.style.color = "#ffffff";

const line1 = document.createElement("div");
line1.textContent = "[ Check Support Tool ]";
line1.style.fontSize = "13px";
line1.style.fontWeight = "600";
line1.style.marginBottom = "8px";
const line2 = document.createElement("div");
line2.textContent = "⚠️ Baby 1+1 행사 ⚠️";
line2.style.fontSize = "13px";
line2.style.fontWeight = "600";
line2.style.marginBottom = "8px";

const line3 = document.createElement("div");
line3.innerHTML = '<strong style="color:##ffffff;">행사 수량이 아닌 기본 수량으로 대응</strong>';
line3.style.fontSize = "13px";
line3.style.marginBottom = "13px";

// 확인 버튼 (content-buttons.js 스타일)
const ok = document.createElement("button");
ok.textContent = "확인";
ok.style.height = "28px";
ok.style.background = "rgba(30, 30, 30, 0.85)";
ok.style.border = "1px solid rgba(255,255,255,0.2)";
ok.style.borderRadius = "6px";
ok.style.color = "#fff";
ok.style.fontSize = "13px";
ok.style.cursor = "pointer";
ok.style.display = "inline-flex";
ok.style.alignItems = "center";
ok.style.justifyContent = "center";
ok.style.transition = "all 0.2s ease";
ok.style.boxShadow = "0 2px 4px rgba(55, 55, 55, 0.4)";
ok.style.padding = "0 14px";
ok.style.userSelect = "none";

ok.onmouseenter = () => { ok.style.boxShadow = "0 4px 8px rgba(0,0,0,0.8)"; };
ok.onmouseleave = () => { ok.style.boxShadow = "0 2px 4px rgba(0,0,0,0.4)"; ok.style.transform = "scale(1)"; };
ok.onmousedown = () => { ok.style.transform = "scale(0.88)"; };
ok.onmouseup = () => { ok.style.transform = "scale(1.05)"; setTimeout(() => ok.style.transform = "scale(1)", 150); };

ok.addEventListener("click", () => {
try { backdrop.remove(); } catch { }
try { card.remove(); } catch { }
});

card.appendChild(line1);
card.appendChild(line2);
card.appendChild(line3);
card.appendChild(ok);
document.body.appendChild(backdrop);
document.body.appendChild(card);
}

// -------------------------------------------------------------
// 10. KAN 조건 + 1+1 감지 + 팝업 실행
// -------------------------------------------------------------
function tryRun() {
chrome.storage.local.get("__ext_last_kan", (res) => {
const kan = String(res?.__ext_last_kan || "");

// KAN이 지정된 목록에 없으면 종료
if (!ELIGIBLE_KANS.has(kan)) return;

observeBlueBlock();

// 즉시 체크
const block = getBlueBlock();
if (block && hasOnePlusOneText(block)) {
ensureMarkStyle();
highlightOnePlusOne(block);
observeInside(block);
showNaverPromoModal();
return;
}

// 늦게 로딩되는 경우 대비 (최대 4초)
const start = Date.now();
const temp = new MutationObserver(() => {
const b = getBlueBlock();
if (b && hasOnePlusOneText(b)) {
temp.disconnect();
ensureMarkStyle();
highlightOnePlusOne(b);
observeInside(b);
showNaverPromoModal();
} else if (Date.now() - start > 4000) {
temp.disconnect();
}
});
temp.observe(document.body, { childList: true, subtree: true, characterData: true });
setTimeout(() => temp.disconnect(), 4500);
});
}


// -------------------------------------------------------------
// 11. 실행 시작
// -------------------------------------------------------------
if (document.readyState === "loading") {
document.addEventListener("DOMContentLoaded", () => setTimeout(tryRun, 150));
} else {
setTimeout(tryRun, 0);
}

})();

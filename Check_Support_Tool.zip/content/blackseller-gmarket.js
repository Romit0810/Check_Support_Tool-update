// ============================================================
// blackseller-gmarket.js
// ============================================================

console.log("[GMARKET] 실행됨:", location.href);

(function () {

// 강조 표시용 색깔 (상품명 옆 라벨 텍스트 색상)
const HIGHLIGHT_COLOR = "#ffff00";

// 여러 번 겹쳐 실행되는 걸 막기 위한 잠금장치
let __ext_safeStartLock = false;

// 전에 본 값을 저장해두는 변수들
let __ext_prevKan = "";
let __ext_prevSellerHash = "";

// 판매자 정보를 못 불러왔을 때, 몇 번까지 다시 시도할지
let __ext_retryCount = 0;


// ============================================================
// 1. 판매자 정보 가져오기
// ============================================================
function extractSellerInfo() {
const info = { tel: "", biznum: "", address: "", email: "" };

const list = document.querySelectorAll(".list__exchange-data li");
if (!list.length) return info;

list.forEach((li) => {
const key = (li.textContent || "").replace(/\s+/g, " ").trim();
const valEl = li.querySelector(".text__deco");
const val = valEl ? valEl.textContent.trim() : "";
if (!key || !val) return;

if (key.includes("연락처")) info.tel = val;
else if (key.includes("사업자 등록번호")) info.biznum = val;
else if (key.includes("사업장소재지")) info.address = val;
else if (key.toLowerCase().includes("e-mail")) info.email = val;
});

return info;
}


// ============================================================
// 2. CSV (블랙셀러 파일)와 비교하기
// ============================================================
function compareWithBlacklist(kan, sellerData, csvText) {
try {
const lines = csvText.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
if (lines.length < 2) return { matchType: null, highlightVals: [] };

const headers = lines[0].split(",");
const idxKAN = headers.indexOf("KANID");
const idxBiz = headers.indexOf("사업자번호");
const idxAddr = headers.indexOf("주소지");
const idxEmail = headers.indexOf("e-mail");
const idxPhone = headers.indexOf("전화번호");
const idxBlack = headers.indexOf("블랙셀러 여부");

if (idxKAN < 0 || idxBiz < 0 || idxAddr < 0 || idxEmail < 0 || idxPhone < 0 || idxBlack < 0) {
return { matchType: null, highlightVals: [] };
}

// 문자열을 깔끔하게 정리하는 작은 함수들
const norm = s => String(s || "")
.replace(/\r|\n/g, "")
.replace(/[‐-‒–—―−]/g, "-")
.replace(/\s+/g, " ")
.trim();

// 전화번호와 사업자번호는 양쪽 모두 하이픈 제거후 숫자만 비교
const normPhone = s => String(s || "").replace(/[^\d]/g, "").trim();
const normBiz = s => String(s || "").replace(/[^\d]/g, "").trim();

let matchType = null;
let highlightVals = [];

for (let i = 1; i < lines.length; i++) {
const cols = lines[i].split(",");

const csvKanField = cols[idxKAN] || "";
const kanList = csvKanField.split("/").map(k => k.trim().toUpperCase());
const curKAN = String(kan || "").toUpperCase();

// KAN이 맞는 줄이 아니면 건너뛰기
if (!kanList.includes(curKAN) && !kanList.includes("ALL")) continue;

// CSV 한 줄의 정보 정리
const csvBiz = normBiz(cols[idxBiz]);
const csvPhone = normPhone(cols[idxPhone]);
const csvAddr = norm(cols[idxAddr]);
const csvEmail = norm(cols[idxEmail]);

const pageBiz = normBiz(sellerData.biznum);
const pagePhone = normPhone(sellerData.tel);
const pageAddr = norm(sellerData.address);
const pageEmail = norm(sellerData.email);

const sameBiz = csvBiz && pageBiz && csvBiz === pageBiz;
const sameAddr = csvAddr && pageAddr && csvAddr === pageAddr;
const sameEmail = csvEmail && pageEmail && csvEmail === pageEmail;
const samePhone = csvPhone && pagePhone && csvPhone === pagePhone;
const black = norm(cols[idxBlack]);

// 블랙셀러면 바로 종료
if (black === "Blackseller On" && (sameBiz || sameAddr || sameEmail || samePhone)) {
matchType = kanList.includes("ALL") ? "ALL" : "ON";
break;
}
}

return { matchType, highlightVals };

} catch (e) {
return null;
}
}


// ============================================================
// 3. 상품명 옆에 라벨 붙이기
// ============================================================
function insertBlackLabel(matchType, isError = false) {
const titleEl = document.querySelector("h1.itemtit");
if (!titleEl) return;

const existing = document.getElementById("__ext_black_label");
if (existing) existing.remove();

const label = document.createElement("span");
label.id = "__ext_black_label";
label.textContent = isError ? "오류" : `블랙셀러 ${matchType}`;
Object.assign(label.style, {
display: "inline-block",
verticalAlign: "middle",
background: isError ? "#000000" : "#ff0000ff",
color: isError ? "#ffffff" : "#ffff00ff",
fontWeight: "Normal",
fontSize: "18px",
borderRadius: "8px",
padding: "2px 8px",
marginRight: "8px",
lineHeight: "1.2",
});

titleEl.insertBefore(label, titleEl.firstChild);
}

// ============================================================
// 4. 전체 실행 흐름
// ============================================================
function start() {
const sellerData = extractSellerInfo();

// 판매자 정보가 아직 안 보이면 조금 뒤에 다시 시도
if (!sellerData.tel && !sellerData.biznum && !sellerData.email && !sellerData.address) {
if (__ext_retryCount < 10) {
__ext_retryCount++;
setTimeout(start, 500);
}
return;
}

__ext_retryCount = 0;

chrome.storage.local.get(
["__ext_last_kan", "__ext_uploaded_csv", "__ext_admin_error"],
(res) => {

const kan = res.__ext_last_kan;
const csvText = res.__ext_uploaded_csv;
const adminErr = res.__ext_admin_error;

// KAN ID 오류
if (adminErr === true) {
insertBlackLabel(null, true);
return;
}

// CSV 미업로드
if (!csvText) {
insertBlackLabel(null, true);
return;
}

const result = compareWithBlacklist(kan, sellerData, csvText);
if (!result) return;

// 최종 결과 1줄만 출력
if (result.matchType === "ON") {
console.log("블랙셀러 ON");
insertBlackLabel("ON");
} else if (result.matchType === "ALL") {
console.log("블랙셀러 ALL");
insertBlackLabel("ALL");
} else {
console.log("블랙셀러 아님");
}
});
}

// ============================================================
// ✅ 5. 중복 실행 막고, 필요할 때만 다시 실행
// ============================================================
function safeStart() {
if (__ext_safeStartLock) return;
__ext_safeStartLock = true;

try {
start();
} finally {
setTimeout(() => (__ext_safeStartLock = false), 1000);
}
}

// 페이지 처음 열릴 때 바로 실행
safeStart();

// 페이지 요소가 다 준비되면 한 번 더 실행
window.addEventListener("DOMContentLoaded", () => safeStart());

// 화면 안에서 내용이 바뀌면 0.3초 뒤에 딱 한 번만 다시 실행
let moTimer;
const mo = new MutationObserver(() => {
clearTimeout(moTimer);
moTimer = setTimeout(() => safeStart(), 300);
});
mo.observe(document.body, { childList: true, subtree: true });

// 판매자 정보 영역이 생기면 즉시 실행 후 종료
const moSeller = new MutationObserver(() => {
if (document.querySelector(".list__exchange-data li")) {
safeStart();
moSeller.disconnect();
}
});
moSeller.observe(document.body, { childList: true, subtree: true });

})();

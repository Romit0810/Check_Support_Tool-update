// ===============================================================
// expiry-date.js
// 유통기한 배너/컬러링 기능
// ===============================================================

(function () {

// ===============================================================
// 0. 색상 (미래 = 노랑 / 과거 = 연회색)
// ===============================================================
const COLOR_FUTURE = "#ffff00";
const COLOR_PAST = "#efefef";

// ===============================================================
// 1. 화이트리스트 사이트
// ===============================================================
const WHITELIST_SITES = [
"https://item.gmarket.co.kr/", //지마켓
"https://itempage3.auction.co.kr/", //옥션
"https://smartstore.naver.com/", //스마트스토어
"https://www.lotteon.com/", //롯데온
"https://www.11st.co.kr/", //11번가
"https://www.hmall.com/", //현대홈쇼핑
"https://lottemartzetta.com/", //롯데마트 제타
"https://www.ssg.com/", //SSG
"https://www.kurly.com/", //컬리
"https://store.kakao.com/", //카카오 톡딜
"https://www.oliveyoung.co.kr/", //올리브영
"https://shinsegaemall.ssg.com/", //신세계몰
"https://store.ohou.se/", //오늘의집
"https://search.shopping.naver.com/", //네이버 가격비교탭
"https://www.coupang.com/", //쿠팡
"https://www.gsshop.com/", //GS샵 1
"https://with.gsshop.com/", //GS샵 2
"https://brand.naver.com/", //네이버 브랜드
"https://zigzag.kr/", //지그재그
"https://display.cjonstyle.com/", //CJ On Style
"https://www.lotteimall.com/", //롯데홈쇼핑
"https://mfront.homeplus.co.kr/", //홈플러스
"https://www.musinsa.com/", //무신사
"https://harimmall.com/", //하림몰
"https://m.nsmall.com/", //NS몰
"https://gift.kakao.com/", //카카오 선물하기
"https://www.dongwonmall.com/", //동원몰
"https://shopping.naver.com/" //네이버윈도우


];

function isWhitelistSite() {
return WHITELIST_SITES.some(url => location.href.startsWith(url));
}

// ===============================================================
// 2. 블랙리스트 사이트
// 컬러링 및 배너 제외
// ===============================================================
const BLACKLIST_SITES = [
"https://shopping.naver.com/popup/seller-info"
// 추가위치
];

function isBlacklistSite() {
return BLACKLIST_SITES.some(url => location.href.startsWith(url));
}


// ===============================================================
// 3. 블랙리스트 영역
// 배너 O , 영역 컬러링만 X
// ===============================================================
const BLACKLIST_ZONES = [
"div[class*='GBT']" // 네이버 쿠폰 영역
// 추가위치
];

function isInsideBlockedZone(node) {
if (!node || !node.parentElement) return false;
return BLACKLIST_ZONES.some(sel => node.parentElement.closest(sel));
}


// ===============================================================
// 4. 블랙리스트 사이트면 기능 즉시 종료
// ===============================================================
if (isBlacklistSite()) {
console.log("[GLOBAL] 블랙리스트 사이트 → 기능 중단");
return;
}


// ===============================================================
// 5. 문자 공백 정리
// ===============================================================
const tnorm = (s) => (s || "").replace(/\s+/g, " ").trim();

// ===============================================================
// 6. 오늘 날짜(00시 기준)
// ===============================================================
function todayMidnight() {
const n = new Date();
return new Date(n.getFullYear(), n.getMonth(), n.getDate());
}

const PUNCT = "[\\s,.:/\\-·]*"; // 날짜 중간에 들어갈 수 있는 문자들
const TRAIL = "(?=$|[^0-9])"; // 숫자 뒤에 문장부호 있어도 인식


// ===============================================================
// 7.컬러링 제외 키워드 (근처 40글자 안에 있으면 제외)
// ===============================================================
const EXCLUDE_NEAR = [
"쿠팡상품번호", "상품번호", "출시년월", "모델명"
];

const EXCLUDE_RE = new RegExp(
EXCLUDE_NEAR
.map(w => w.replace(/[\s]/g, "")
.split(/(?=[가-힣A-Za-z])/)
.join(PUNCT))
.join("|"),
"i"
);

const EX_RANGE = 40; // 주변 40글자 검사


// ===============================================================
// 8. 컬러링 되는 키워드
// ===============================================================
const KEYWORDS = [
"소비기한", "유통기한", "품질 유지기한", "유효일",
"소기비한", "유통기간", "소비기간", "유효기간",
"사용기한", "보관기한", "만료일", "유통일자",
"임박", "개봉 후 사용기간", "사용기간"
];

const keywordRe = new RegExp(
`(${KEYWORDS.map(k => k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|")})`,
"gi"
);

// ===============================================================
// 9. 컬러링 되는 날짜 형식
// ===============================================================
const dateRes = [
// ① YYYY년 MM월 (최우선으로)
new RegExp(`\\b((?:19|20)?\\d{2}${PUNCT}년${PUNCT}\\d{1,2}${PUNCT}월)`, "g"),

// ② YYYY년 MM월 DD일
new RegExp(`\\b((?:19|20)?\\d{2}${PUNCT}년${PUNCT}\\d{1,2}${PUNCT}월${PUNCT}\\d{1,2}${PUNCT}일)`, "g"),

// ③ YYYY-MM-DD / YYYY.MM.DD / YYYY/MM/DD
new RegExp(`\\b((?:19|20)?\\d{2}${PUNCT}\\d{1,2}${PUNCT}\\d{1,2})${TRAIL}`, "g"),

// ④ 25.09.27 (두자리년도)
new RegExp(`\\b(\\d{2}\\.\\d{2}\\.\\d{2})${TRAIL}`, "g"),

// ⑤ 250927 / 20250927
new RegExp(`(?<!\\d)(\\d{6}|\\d{8})${TRAIL}`, "g"),

// ⑥ YYYY.MM 또는 YY.MM
new RegExp(`\\b((?:19|20)?\\d{2}\\.\\d{1,2})(?!\\.\\d)`, "g"),
new RegExp(`\\b(\\d{2}\\.\\d{1,2})(?!\\.\\d)`, "g"),

// ⑦ YYYY-MM
new RegExp(`\\b((?:19|20)?\\d{2}[-/]\\d{1,2})(?![-/]\\d)`, "g")
];


// ===============================================================
// 10. 텍스트에서 날짜를 '실제 날짜'로 바꾸는 함수
// ===============================================================
function parseYMD(s) {
let m;

// YYYY년 MM월 DD일
m = s.match(/^(?:\s*)((?:19|20)?\d{2})\s*년\s*(\d{1,2})\s*월\s*(\d{1,2})\s*일/);
if (m && validYMD(normalYear(m[1]), +m[2], +m[3]))
return { y: normalYear(m[1]), m: +m[2], d: +m[3] };

// YYYY년 MM월
m = s.match(/^(?:\s*)((?:19|20)?\d{2})\s*년\s*(\d{1,2})\s*월/);
if (m && validYM(normalYear(m[1]), +m[2]))
return { y: normalYear(m[1]), m: +m[2], d: 1 };

// YYYY-MM-DD / YYYY.MM.DD / YYYY/MM/DD
const clean = s.replace(/\s|년|월|일/g, "").replace(/·/g, ".");
m = clean.match(/^((?:19|20)?\d{2})[.\-\/](\d{1,2})[.\-\/](\d{1,2})$/);
if (m && validYMD(normalYear(m[1]), +m[2], +m[3]))
return { y: normalYear(m[1]), m: +m[2], d: +m[3] };

// 250927 / 20250927
m = clean.match(/^(\d{8}|\d{6})$/);
if (m) {
const t = m[1];
let y, mo, da;
if (t.length === 8) {
y = +t.slice(0, 4);
mo = +t.slice(4, 6);
da = +t.slice(6, 8);
} else {
y = normalYear(t.slice(0, 2));
mo = +t.slice(2, 4);
da = +t.slice(4, 6);
}
if (validYMD(y, mo, da))
return { y, m: mo, d: da };
}

// YYYY-MM or YYYY.MM
m = clean.match(/^((?:19|20)?\d{2})[.\-\/](\d{1,2})$/);
if (m && validYM(normalYear(m[1]), +m[2]))
return { y: normalYear(m[1]), m: +m[2], d: 1 };

return null;
}

function normalYear(y) {
return String(y).length === 2 ? 2000 + (+y) : +y;
}

function validYM(y, m) {
return y >= 1900 && y <= 2099 && m >= 1 && m <= 12;
}

function validYMD(y, m, d) {
if (!validYM(y, m)) return false;
const dt = new Date(y, m - 1, d);
return dt.getFullYear() === y &&
dt.getMonth() + 1 === m &&
dt.getDate() === d;
}

function toDate(obj) {
return new Date(obj.y, obj.m - 1, obj.d || 1);
}


// ===============================================================
// 11. 특정 텍스트 주변에 “컬러링 하면 안 되는 단어”가 있는지 검사
// ===============================================================
function hasExcludedAround(text, start, end, node) {

const left = Math.max(0, start - EX_RANGE);
const right = Math.min(text.length, end + EX_RANGE);
const slice = text.slice(left, right);

// 근처에 제외 단어가 있으면 컬러링 금지
if (EXCLUDE_RE.test(slice)) return true;

// 부모·이전·다음 텍스트까지 확인(더 정확하게)
const p = node?.parentElement?.textContent || "";
const prev = node?.previousSibling?.textContent || "";
const next = node?.nextSibling?.textContent || "";
const around = prev + p + next;

if (EXCLUDE_RE.test(around)) return true;

return false;
}


// ===============================================================
// 12. "대화형(인터랙티브) 영역"인지 확인
// 버튼/입력창/접었다펼치는 영역 등은 건드리면 깨짐
// → DOM 수정 금지 / CSS 하이라이트만 사용함
// ===============================================================
function isInteractive(node) {
if (!node?.parentElement) return false;
const p = node.parentElement;

// a[href] = 상품명 링크 → 허용
if (p.closest("a[href]")) return false;

// 버튼/입력창/폼 등은 DOM 변경 금지
if (
p.closest("button, input, select, option, textarea, label, summary, details, form") ||
p.closest("[contenteditable=''], [contenteditable='true']") ||
p.closest("[role='button'], [role='tab'], [role='listbox'], [role='option']")
) return true;

return false;
}

// ===============================================================
// 14. CSS 하이라이트 스타일(한 번만 추가)
// ===============================================================
function ensureCSSHighlight() {
if (document.getElementById("__ext_css_highlight__")) return;

const st = document.createElement("style");
st.id = "__ext_css_highlight__";
st.textContent =
"::highlight(__ext_future){background:#ffff00 !important;}" +
"::highlight(__ext_past){background:#efefef !important;}";

document.documentElement.appendChild(st);
}

// ===============================================================
// 15. CSS 하이라이트 적용
// ===============================================================
function addCSSRange(node, start, end, isPast) {
if (!window.CSS?.highlights) return false;
try {
const range = document.createRange();
range.setStart(node, start);
range.setEnd(node, end);

const key = isPast ? "__ext_past" : "__ext_future";
let set = CSS.highlights.get(key);

if (!set) {
set = new Highlight();
CSS.highlights.set(key, set);
}

set.add(range);
return true;
} catch {
return false;
}
}

// ===============================================================
// 16. 한 텍스트 노드에서 여러 개 컬러링 처리
// ===============================================================
function addCSSRanges(node, list) {
if (!window.CSS?.highlights) return false;
let ok = false;

for (const r of list) {
if (addCSSRange(node, r.s, r.e, r.past)) ok = true;
}
return ok;
}


// ===============================================================
// 17. 인터랙티브 영역 전용 컬러링 방식
// ===============================================================
function highlightInteractive(node) {

const text = node.nodeValue;
if (!text) return;

const matches = [];
const today = todayMidnight();

// 키워드 컬러링
keywordRe.lastIndex = 0;
let km;
while ((km = keywordRe.exec(text))) {
matches.push({ s: km.index, e: km.index + km[0].length, past: false });
}

// 날짜 컬러링
for (const re of dateRes) {
re.lastIndex = 0;
let m;
while ((m = re.exec(text))) {
const full = m[0];
const core = m[1];

const start = m.index + full.indexOf(core);
const end = start + core.length;

if (hasExcludedAround(text, start, end, node)) continue;

const parsed = parseYMD(core);
if (!parsed) continue;

const d = toDate(parsed);
const past = d < today;
const within = (d - today) <= (1825 * 86400000);
const usePast = past || !within;

matches.push({ s: start, e: end, past: usePast });
}
}

// 실제 CSS 컬러링 적용
if (matches.length) {
ensureCSSHighlight();
addCSSRanges(node, matches);
}
}

// ===============================================================
// [18] 문서 안에 있는 "인터랙티브 영역"만 따로 스캔
// ===============================================================
function scanInteractive(root) {
const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
const nodes = [];
let count = 0;

while (walker.nextNode()) {
nodes.push(walker.currentNode);
if (++count > 3000) break; // 너무 많이 돌지 않게 제한
}

for (const n of nodes) {
if (isInteractive(n)) {
highlightInteractive(n);
}
}
}


// ===============================================================
// PART 3 끝 (PART 4에서 일반 텍스트 색칠 + 스킵 규칙 시작)
// ===============================================================

// ===============================================================
// HTML 문자 깨지지 않게 변환 (기존 코드에서 빠져있어서 오류남)
// ===============================================================
function escapeHtml(str) {
if (!str) return "";
return str
.replace(/&/g, "&amp;")
.replace(/</g, "&lt;")
.replace(/>/g, "&gt;");
}


// ===============================================================
// 19. 어떤 노드는 아예 건드리면 안 됨 (스킵 규칙)
// ===============================================================
function shouldSkip(node) {

if (!node || node.nodeType !== Node.TEXT_NODE) return true;
const p = node.parentElement;
if (!p) return true;

const tag = p.tagName;

// SCRIPT / STYLE / CODE 등은 절대 손대면 안 됨
if (["SCRIPT", "STYLE", "NOSCRIPT", "CODE"].includes(tag)) return true;

// 매핑툴 매핑 버튼 / 기존매핑, 매핑하기버튼 스킵 (충돌방지)
if (p.closest(".existingMappingTag button, .existingMappingTag a, .existingMappingTag [role='button']")) {
return true;
}

// 이미 색칠된 mark 안쪽은 다시 컬러링 금지 (네이버 쿠폰영역 제외)
if (p.closest("mark[data-ext-expiry]") && !isInsideBlockedZone(node)) {
return true;
}

// 배너 안쪽은 건드리면 안 됨
if (p.closest("#__ext_global_banner__")) return true;

// 네이버 쿠폰영역(GTB)은 컬러링 금지
if (isInsideBlockedZone(node)) return true;

// 인터랙티브 영역은 DOM 수정 금지 → CSS 방식으로만 컬러링
if (isInteractive(node)) {
const parent = node.parentElement;

// 상품명 링크는 다시 허용 (네이버, 스마트스토어 등 필요)
if (
parent.closest("a.adProduct_link__hNwpz") ||
parent.closest("a.basicList_link__") ||
parent.closest("a.basicList_title__")
) {
// 허용
} else {
return true;
}
}

return false;
}

// ===============================================================
// 20. 일반 텍스트 노드 컬러링 (mark)
// ===============================================================
function highlightTextNode(node) {

if (shouldSkip(node)) return;

const text = node.nodeValue;
if (!text) return;

let html = null;
const today = todayMidnight();

// =============================================
// br / &lt;br&gt; 때문에 텍스트가 쪼개져 날짜 못 찾는 문제
// 같은 부모 안에서 "이어진 날짜 조각"을 하나로 합쳐서 검사
// =============================================
if (
node.nextSibling &&
node.nextSibling.nodeType === Node.TEXT_NODE &&
/[0-9년월일.\-]/.test(node.nodeValue.slice(-3)) &&
/^[0-9년월일.\-]/.test(node.nextSibling.nodeValue.slice(0, 3))
) {
node.nodeValue = node.nodeValue + " " + node.nextSibling.nodeValue;
node.nextSibling.remove();
}

const dateRes = [

// ① YYYY년 MM월 (이걸 최우선으로)
new RegExp(`\\b((?:19|20)?\\d{2}${PUNCT}년${PUNCT}\\d{1,2}${PUNCT}월)`, "g"),

// ② YYYY년 MM월 DD일
new RegExp(`\\b((?:19|20)?\\d{2}${PUNCT}년${PUNCT}\\d{1,2}${PUNCT}월${PUNCT}\\d{1,2}${PUNCT}일)`, "g"),

// ③ YYYY-MM-DD / YYYY.MM.DD / YYYY/MM/DD
new RegExp(`\\b((?:19|20)?\\d{2}${PUNCT}\\d{1,2}${PUNCT}\\d{1,2})${TRAIL}`, "g"),

// ④ 25.09.27 (두자리년도)
new RegExp(`\\b(\\d{2}\\.\\d{2}\\.\\d{2})${TRAIL}`, "g"),

// ⑤ 250927 / 20250927
new RegExp(`(?<!\\d)(\\d{6}|\\d{8})${TRAIL}`, "g"),

// ⑥ YYYY.MM 또는 YY.MM
new RegExp(`\\b((?:19|20)?\\d{2}\\.\\d{1,2})(?!\\.\\d)`, "g"),
new RegExp(`\\b(\\d{2}\\.\\d{1,2})(?!\\.\\d)`, "g"),

// ⑦ YYYY-MM
new RegExp(`\\b((?:19|20)?\\d{2}[-/]\\d{1,2})(?![-/]\\d)`, "g")
];


// -----------------------------------------------------------
// ① 유통기한 관련 키워드(소비기한, 유통기한 등)
// -----------------------------------------------------------
keywordRe.lastIndex = 0;
if (keywordRe.test(text)) {
html = (html ?? escapeHtml(text)).replace(keywordRe, (_, g1) =>
`<mark data-ext-expiry="1" style="background:${COLOR_FUTURE};">${escapeHtml(g1)}</mark>`
);
}

// -----------------------------------------------------------
// ② 날짜 컬러링
// -----------------------------------------------------------
for (const re of dateRes) {
re.lastIndex = 0;

if (re.test(text)) {

const src = html ?? escapeHtml(text);

html = src.replace(re, (full, core, offset) => {
const start = offset + full.indexOf(core);
const end = start + core.length;

// ❌ 제외 단어 근접하면 색칠 금지
if (hasExcludedAround(text, start, end, node)) {
return escapeHtml(full);
}

const parsed = parseYMD(core);
if (!parsed) return escapeHtml(full);

const d = toDate(parsed);
const past = d < today;
const within = (d - today) <= (1825 * 86400000);
const color =
(!past && within)
? COLOR_FUTURE // 미래/오늘 + 1825일 이내 → 노랑
: COLOR_PAST; // 1825일 이후 → 회색

const before = escapeHtml(full.slice(0, full.indexOf(core)));
const after = escapeHtml(full.slice(full.indexOf(core) + core.length));

return `${before}<mark data-ext-expiry="1" style="background:${color};">${escapeHtml(core)}</mark>${after}`;
});

break;
}
}

// -----------------------------------------------------------
// ③ 실제 DOM 반영
// -----------------------------------------------------------
if (html !== null) {
const span = document.createElement("span");
span.innerHTML = html;
node.replaceWith(...span.childNodes);
}
}

// ===============================================================
// 21. 전체 문서 스캔(일반 텍스트 전용)
// ===============================================================
function scanText(root) {
const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
const nodes = [];
let count = 0;

while (walker.nextNode()) {
nodes.push(walker.currentNode);
if (++count > 3000) break; // 브라우저 보호
}

for (const n of nodes) {
highlightTextNode(n);
}
}

// ===============================
// 22. 배너 드래그 + 위치 저장 기능
// ===============================
function makeBannerDraggable(el) {

let dragging = false;
let offsetX = 0;
let offsetY = 0;

// 저장된 위치 불러오기 (있는 경우)
chrome.storage.local.get(["__ext_banner_pos"], (res) => {
if (res.__ext_banner_pos) {
el.style.top = res.__ext_banner_pos.top + "px";
el.style.left = res.__ext_banner_pos.left + "px";
el.style.transform = "";
}
});

el.addEventListener("mousedown", (e) => {
dragging = true;
offsetX = e.clientX - el.offsetLeft;
offsetY = e.clientY - el.offsetTop;
el.style.transform = "";
e.preventDefault();
});

document.addEventListener("mousemove", (e) => {
if (!dragging) return;

// ⭐ 브라우저 밖으로 못 나가게 제한
let newLeft = e.clientX - offsetX;
let newTop = e.clientY - offsetY;

newLeft = Math.max(0, Math.min(window.innerWidth - el.offsetWidth, newLeft));
newTop = Math.max(0, Math.min(window.innerHeight - el.offsetHeight, newTop));

el.style.left = newLeft + "px";
el.style.top = newTop + "px";
});

document.addEventListener("mouseup", () => {
if (!dragging) return;
dragging = false;

chrome.storage.local.set({
"__ext_banner_pos": {
top: el.offsetTop,
left: el.offsetLeft
}
});
});
}

// ===============================================================
// 23. 배너 만들기
// ===============================================================
function makeBanner(text) {

// 텍스트 없으면 배너 지움
if (!text) {
removeBanner();
return;
}

let el = document.getElementById("__ext_global_banner__");

// 아직 배너 없으면 새로 만들기
if (!el) {
el = document.createElement("div");
el.id = "__ext_global_banner__";

// ⭐ 디자인 — 기존과 100% 동일하게 유지
el.style.background = "rgba(20, 20, 20, 0.75)";
el.style.backdropFilter = "blur(6px)";
el.style.color = "#ffffff";
el.style.fontSize = "14px";
el.style.fontWeight = "normal";
el.style.padding = "10px 14px";
el.style.textAlign = "left";
el.style.lineHeight = "1.2";
el.style.position = "fixed";
el.style.top = "0";
el.style.left = "50%";
el.style.transform = "translateX(-50%)";
el.style.zIndex = "2147483647";
el.style.whiteSpace = "pre-line";
el.style.borderRadius = "15px";
el.style.boxShadow = "0 4px 12px rgba(0,0,0,0.3)";

document.body.appendChild(el);

// 배너 드래그 이동
makeBannerDraggable(el);
}

// 내용이 변경되면 업데이트
if (el.textContent !== text) el.textContent = text;
}


// ===============================================================
// 24. 배너 제거
// ===============================================================
function removeBanner() {
const el = document.getElementById("__ext_global_banner__");
if (el) el.remove();
}


// ===============================================================
// 25. 날짜 계산 (배너에서 쓰는 날짜들)
// ===============================================================
function addDays(days) {
const d = new Date();
d.setDate(d.getDate() + days);

const yy = String(d.getFullYear()).slice(2);
const mm = String(d.getMonth() + 1).padStart(2, "0");
const dd = String(d.getDate()).padStart(2, "0");

return `${yy}.${mm}.${dd}`;
}


// ===============================================================
// 26. 유통기한 기능 작동하는 UNITNAME
// ===============================================================
function isValidUnit(unit) {

const u = (unit || "").toLowerCase();

return [
"beauty",
"pet",
"beverages",
"snacks, coffee & tea",
"meal & healthy",
"fresh food",
"household",
"personal care",
"car accessories",
"baby core",
"baby necessaries"
].includes(u);
}

// ===============================================================
// 26. UNITNAME에 따라 다른 내용의 배너 띄우기
// ===============================================================
function updateBannerByUnit(unit) {

const u = (unit || "").toLowerCase();

if (!isValidUnit(unit)) {
removeBanner();
return false;
}

// Beauty
if (u === "beauty") {
makeBanner(
`[ B e a u t y : 뷰티 소품 제외 ]

유통기한 확인가능 : ${addDays(365)} ( Today + 365 )
제조일만 확인가능 : 제조일로부터 3년`
);
return true;
}

// pet
if (u === "pet") {
makeBanner(
`[ P E T : 입으로 들어가는 사료 & 간식 & 영양제 ]

쿠팡보다 길거나 동일 유통기한`
);
return true;
}

// FOOD
if (
[
"beverages",
"snacks, coffee & tea",
"meal & healthy",
"fresh food"
].includes(u)
) {
makeBanner(
`[ F O O D ]

멸균우유 / 두유 외 : 쿠팡보다 길거나 동일 유통기한
멸균우유 : ${addDays(40)} ( Today + 40 )
두유 : ${addDays(60)} ( Today + 60 )
쌀 & 잡곡류 : 동일 생산년도`
);
return true;
}

// 공통
if (
[
"household",
"personal care",
"car accessories"
].includes(u)
) {
makeBanner(
`[ 공통 ]

${addDays(180)} ( Today + 180 )`
);
return true;
}

// Baby Core
if (u === "baby core") {
makeBanner(
`[ B a b y C o r e ]

분유 외 : ${addDays(180)} ( Today + 180 )

캔 분유 : ${addDays(180)} ( Today + 180 )
ㄴ베비언스 캔 분유 : ${addDays(240)} ( Today + 240 )
ㄴ산양 캔 분유 : ${addDays(365)} ( Today + 365 )

스틱 분유 : ${addDays(120)} ( Today + 120 )
액상 분유 : ${addDays(60)} ( Today + 60 )`
);
return true;
}

// Baby Necessaries
if (u === "baby necessaries") {
makeBanner(
`[ F O O D ]

멸균우유 / 두유 외 : 쿠팡보다 길거나 동일 유통기한
멸균우유 : ${addDays(40)} ( Today + 40 )
두유 : ${addDays(60)} ( Today + 60 )

[ F O O D 외 ]

공통 : ${addDays(180)} ( Today + 180 )`
);
return true;
}

removeBanner();
return false;
}

// ===============================================================
// [26] 기존 색칠 모두 제거 (토글 OFF 또는 사이트 벗어났을 때)
// ===============================================================
function clearHighlights() {

// mark 지우기
document.querySelectorAll('mark[data-ext-expiry="1"]').forEach(m => {
const p = m.parentNode;
while (m.firstChild) p.insertBefore(m.firstChild, m);
p.removeChild(m);
});

// CSS highlights 지우기
try {
const keys = ["__ext_future", "__ext_past"];
keys.forEach(k => {
const s = CSS.highlights.get(k);
if (s) s.clear();
});
} catch (e) { }
}


// ===============================================================
// 27. runOnce — 핵심 실행
// ===============================================================
let __ext_blocked__ = false; // 토글 ON/OFF 시 잠시 막는 용도

function runOnce() {

if (__ext_blocked__) return;

// ❌ 화이트리스트 밖이면 기능 끔
if (!isWhitelistSite()) {
makeBanner(""); // 배너 제거
clearHighlights();
return;
}

chrome.storage.local.get(
["__ext_last_unit", "__ext_expiry_enabled"],
(res) => {

const enabled = res.__ext_expiry_enabled !== false;
const unit = res.__ext_last_unit || "";

// 토글 꺼짐 → 배너/컬러링 전부 종료
if (!enabled || !isValidUnit(unit)) {
__ext_blocked__ = true;
setTimeout(() => (__ext_blocked__ = false), 600);
makeBanner("");
clearHighlights();
return;
}

// 배너 업데이트
updateBannerByUnit(unit);

// 본문 스캔
scanText(document.body);

// 인터랙티브 영역은 CSS highlight 전용
scanInteractive(document.body);

// iframe도 처리
document.querySelectorAll("iframe").forEach(f => {
try {
const b = f.contentDocument?.body;
if (b) {
scanText(b);
scanInteractive(b);
}
} catch (e) { }
});
}
);
}

// ===============================
// 28. 사이트별 추가 로직
// ===============================

// ===============================
// GS SHOP
// ===============================

if (location.href.includes("gsshop.com")) {

// 탭 클릭 시 패널 재스캔
document.addEventListener("click", (e) => {
const t = e.target;
if (!t || !t.classList) return;

if (t.classList.contains("tab")) {
const href = t.getAttribute("href") || "";

setTimeout(() => {
if (href.startsWith("#")) {
let pane = document.querySelector(href);

// GS SHOP: ProTabN04 → ProTab04 보정
if (!pane && href.includes("ProTabN")) {
const fixedId = href.replace("ProTabN", "ProTab");
pane = document.querySelector(fixedId);
}

if (pane) {
scanText(pane);
scanInteractive(pane);
return;
}
}

// 패널 못 찾으면 전체 스캔
scanText(document.body);
scanInteractive(document.body);

}, 300);
}
}, true);

// hashchange로 전환되는 경우
window.addEventListener("hashchange", () => {
setTimeout(() => {
let pane = document.querySelector(location.hash);

if (!pane && location.hash.includes("ProTabN")) {
const fixedId = location.hash.replace("ProTabN", "ProTab");
pane = document.querySelector(fixedId);
}

if (pane) {
scanText(pane);
scanInteractive(pane);
} else {
scanText(document.body);
scanInteractive(document.body);
}
}, 350);
});
}

// ===============================
// 11번가
// ===============================
if (location.href.includes("11st.co.kr")) {

// 11번가 추천상품 캐러셀: 스캔 금지
function skip11stCarousel(node) {
return node?.parentElement?.closest(".carousel") ||
node?.parentElement?.closest("[data-log-actionlabel='product']");
}

// 상품정보 제공고시 테이블만 스캔
function scan11stProductInfo() {
document.querySelectorAll("table").forEach(tbl => {
if (tbl.textContent.includes("소비기한") ||
tbl.textContent.includes("제조연월일") ||
tbl.textContent.includes("사용기한") ||
tbl.textContent.includes("사용기간") ||
tbl.textContent.includes("품질유지기한")) {

scanText(tbl);
scanInteractive(tbl);
}
});
}

// shouldSkip 보완: 캐러셀 영역은 무조건 스킵
const __orig_shouldSkip = shouldSkip;
shouldSkip = function(node) {
if (skip11stCarousel(node)) return true;
return __orig_shouldSkip(node);
};

// 로딩 후 적용
setTimeout(scan11stProductInfo, 1200);

// 페이지 내 이동 / 탭 전환 시 다시 스캔
document.addEventListener("click", () => {
setTimeout(scan11stProductInfo, 800);
});
}

// ===============================================================
// 29. 토글 ON/OFF 시 즉시 적용
// ===============================================================
chrome.runtime.onMessage.addListener((msg) => {
if (msg?.action === "expiry_refresh") {
runOnce();
}
});


// ===============================================================
// 30. MAIN — MutationObserver로 자동 감시
// ===============================================================
function main() {

runOnce();

let raf = null;

const ob = new MutationObserver(() => {
if (raf) cancelAnimationFrame(raf);
raf = requestAnimationFrame(runOnce);
});

ob.observe(document.body, {
childList: true,
subtree: true,
characterData: true,
attributes: true
});

// URL hash 변경 시 다시 적용
window.addEventListener("hashchange", () => {
setTimeout(runOnce, 350);
});
}


// ===============================================================
// 31. MAIN 실행 시점
// ===============================================================
if (document.readyState === "loading") {
document.addEventListener("DOMContentLoaded", () => {
setTimeout(main, 1200);
});
} else {
setTimeout(main, 1200);
}


})();
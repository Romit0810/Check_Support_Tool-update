// =============================================================
// window-baby.js
// baby 칸아이디 + 네이버윈도우 + 1+1 행사중일때 실행됨
// =============================================================

(function () {
// 탑 프레임에서만 동작(중복/iframe 주입 방지)
if (window.self !== window.top) return;

// === 공통: 배너 호스트(스택 컨테이너) ===
const HOST_ID = "__ext_banner_host__";
function ensureBannerHost() {
let host = document.getElementById(HOST_ID);
if (!host) {
host = document.createElement("div");
host.id = HOST_ID;
host.setAttribute("data-ext-banner-host", "1");
Object.assign(host.style, {
all: "initial",
position: "fixed",
top: "20px",
left: "50vw",
transform: "translateX(-50%)",
zIndex: "2147483647",
display: "flex",
flexDirection: "column",
alignItems: "center",
gap: "8px", // 배너 간격
pointerEvents: "none",
contain: "layout style paint",
willChange: "transform",
});
(document.documentElement || document.body).appendChild(host);
}
return host;
}
function cleanupEmptyHost() {
const host = document.getElementById(HOST_ID);
if (host && host.children.length === 0) host.remove();
}

// -------------------------------------------------------------
// 1) 네이버 window 페이지만 동작
// -------------------------------------------------------------
function isNaverWindowPage() {
return /^https?:\/\/shopping\.naver\.com\/window/i.test(location.href);
}
if (!isNaverWindowPage()) return;

// -------------------------------------------------------------
// 2) 대상 KAN 목록
// -------------------------------------------------------------
const ELIGIBLE_KANS = new Set([
"318","319","320","321","324","5116","5117","8584","8585","5409","323",
"8578","8856","1096","8577","8579","1095","8153","8606","5892","6138",
"1094","1093","8580","8862","8605","6711","327","6120","1097","1417",
"8152","8877","9515","9516","9600","9601","9606","9608","9609","9610",
"9611","9632","9633","9712"
]);
const isEligibleKanValue = (v) => ELIGIBLE_KANS.has((v ?? "").toString().trim());

// -------------------------------------------------------------
// 3) 상태/배너 UI
// -------------------------------------------------------------
let bannerEl = null;
let blinkTimer = null;
let blueBlockObserver = null;
let eligibleKan = false;
let safetyTimer = null;

function showWarningBanner(text) {
if (bannerEl) return;
bannerEl = document.createElement("div");
bannerEl.setAttribute("data-ext-banner", "baby");
bannerEl.textContent = text;
Object.assign(bannerEl.style, {
color: "#ffffffff",
fontSize: "20px",
fontWeight: "700",
background: "rgba(233, 34, 34, 0.91)",
padding: "12px 22px",
borderRadius: "16px",
opacity: "1",
transition: "opacity 0.2s ease",
boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
pointerEvents: "none",
});
ensureBannerHost().appendChild(bannerEl);
startBlink(); // 🔙 깜빡임 복구
}

function removeWarningBanner() {
if (bannerEl) {
try { clearInterval(blinkTimer); } catch {}
try { bannerEl.remove(); } catch {}
bannerEl = null;
}
cleanupEmptyHost();
}

// 🔙 원래 깜빡임(5회) 복구
function startBlink() {
let blinkCount = 0;
clearInterval(blinkTimer);
blinkTimer = setInterval(() => {
if (!bannerEl) { clearInterval(blinkTimer); return; }
bannerEl.style.opacity = (bannerEl.style.opacity === "1" ? "0" : "1");
blinkCount++;
if (blinkCount >= 10) {
clearInterval(blinkTimer);
bannerEl.style.opacity = "1";
}
}, 300);
}

// -------------------------------------------------------------
// 4) 블루박스/문구
// -------------------------------------------------------------
function getBlueBlock() {
return document.querySelector("div.RUSA6W3qmn");
}
function hasOnePlusOneText(block) {
if (!block) return false;
try { return /1\s*\+\s*1/.test(block.innerText); } catch { return false; }
}

// 하이라이트 원복
function resetOnePlusOne(root) {
const block = root || getBlueBlock();
if (!block) return;
block.querySelectorAll('span[data-ext-baby="1"]').forEach(span => {
const parent = span.parentNode;
while (span.firstChild) parent.insertBefore(span.firstChild, span);
parent.removeChild(span);
});
}

// "1+1"만 정확히 감싸기 (중복/에러 유발 버전 제거됨)
function highlightOnePlusOne(block) {
if (!block) return;
resetOnePlusOne(block);

const walker = document.createTreeWalker(block, NodeFilter.SHOW_TEXT, null);
const nodes = [];
while (walker.nextNode()) nodes.push(walker.currentNode);

const regex = /1\s*\+\s*1/g;

for (const node of nodes) {
const text = node.nodeValue;
if (!regex.test(text)) continue;

const ranges = [];
regex.lastIndex = 0;
let match;
while ((match = regex.exec(text))) {
const r = document.createRange();
r.setStart(node, match.index);
r.setEnd(node, match.index + match[0].length);
ranges.push(r);
}

for (let i = ranges.length - 1; i >= 0; i--) {
const r = ranges[i];
const span = document.createElement("span");
span.setAttribute("data-ext-baby", "1");
Object.assign(span.style, {
display: "inline-block",
padding: "4px 8px",
border: "3px solid #ff0000ff",
backgroundColor: "#fff5f5",
borderRadius: "4px",
fontWeight: "700",
});
try {
r.surroundContents(span);
} catch {
const before = text.slice(0, r.startOffset);
const mid = text.slice(r.startOffset, r.endOffset);
const after = text.slice(r.endOffset);
const wrapper = document.createElement("span");
wrapper.innerHTML =
(before || "") +
'<span data-ext-baby="1" style="display:inline-block;padding:4px 8px;border:3px solid #d32f2f;background:#fff5f5;border-radius:4px;font-weight:700;">' +
mid +
'</span>' +
(after || "");
node.replaceWith(wrapper);
break;
}
}
}
}

// -------------------------------------------------------------
// 5) 옵저버 (SPA 재평가)
// -------------------------------------------------------------
function observeBlueBlock() {
const parent = document.querySelector("fieldset.zFcPceRwDS") || document.body;
if (!parent) return;

let rafId = null;
function recheck() {
if (rafId) cancelAnimationFrame(rafId);
rafId = requestAnimationFrame(() => {
if (!eligibleKan) {
resetOnePlusOne();
removeWarningBanner();
return;
}
const block = getBlueBlock();
if (!block) {
removeWarningBanner();
return;
}
if (hasOnePlusOneText(block)) {
highlightOnePlusOne(block);
showWarningBanner("Baby 1+1 ㅣ 행사 수량이 아닌 기본 수량으로 대응");
} else {
resetOnePlusOne(block);
removeWarningBanner();
}
});
}

if (!blueBlockObserver) {
blueBlockObserver = new MutationObserver(recheck);
blueBlockObserver.observe(parent, { childList: true, subtree: true });
}
recheck();
}

// -------------------------------------------------------------
// 6) 전체 정리 (배너/하이라이트/옵저버 + 중복 배너까지 강제 제거)
// -------------------------------------------------------------
function hardKillBabyBanners() {
const host = document.getElementById(HOST_ID);
if (!host) return;
host.querySelectorAll('[data-ext-banner="baby"]').forEach(el => {
try { el.remove(); } catch {}
});
cleanupEmptyHost();
}
function stopAll() {
removeWarningBanner();
resetOnePlusOne();
if (blueBlockObserver) { try { blueBlockObserver.disconnect(); } catch {} blueBlockObserver = null; }
hardKillBabyBanners();
}

// -------------------------------------------------------------
// 7) 첫 실행 (현재 KAN 평가)
// -------------------------------------------------------------
function tryRun() {
chrome.storage.local.get("__ext_last_kan", (res) => {
const raw = res && res.__ext_last_kan;
const kan = (raw === undefined || raw === null) ? "" : String(raw).trim();
eligibleKan = isEligibleKanValue(kan);

if (!eligibleKan) { stopAll(); return; }

observeBlueBlock();

const block = getBlueBlock();
if (block && hasOnePlusOneText(block)) {
highlightOnePlusOne(block);
showWarningBanner("Baby 1+1 ㅣ 행사 수량이 아닌 기본 수량으로 대응");
} else {
removeWarningBanner();
}
});
}

// -------------------------------------------------------------
// 8) KAN 변경 즉시 반응 + 폴백 폴링(안정화)
// -------------------------------------------------------------
chrome.storage.onChanged.addListener((changes, area) => {
if (area !== "local") return;
if (!changes.__ext_last_kan) return;

const raw = changes.__ext_last_kan.newValue;
const kan = (raw === undefined || raw === null) ? "" : String(raw).trim();
eligibleKan = isEligibleKanValue(kan);

if (!eligibleKan) { stopAll(); return; }

observeBlueBlock();
const block = getBlueBlock();
if (block && hasOnePlusOneText(block)) {
highlightOnePlusOne(block);
showWarningBanner("Baby 1+1 ㅣ 행사 수량이 아닌 기본 수량으로 대응");
} else {
removeWarningBanner();
}
});

// 폴백: 0.8초마다 저장 KAN 재확인 (onChanged 미발화/지연 대비)
if (!safetyTimer) {
safetyTimer = setInterval(() => {
chrome.storage.local.get("__ext_last_kan", (res) => {
const raw = res && res.__ext_last_kan;
const kan = (raw === undefined || raw === null) ? "" : String(raw).trim();
const nowEligible = isEligibleKanValue(kan);

if (nowEligible !== eligibleKan) {
eligibleKan = nowEligible;
if (!eligibleKan) { stopAll(); return; }
observeBlueBlock();
}

if (!eligibleKan) {
// 대상이 아닌 상태에서 혹시 남아있으면 강제 정리
stopAll();
}
});
}, 800);
}

// -------------------------------------------------------------
// 9) 부트
// -------------------------------------------------------------
if (document.readyState === "loading") {
document.addEventListener("DOMContentLoaded", () => setTimeout(tryRun, 150));
} else {
setTimeout(tryRun, 0);
}

})();
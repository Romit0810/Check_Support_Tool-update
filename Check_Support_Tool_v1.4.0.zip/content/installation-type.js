// ============================================================
// installation-type.js
// 쿠팡 방문설치 상품 → 경쟁사 방문설치 여부 확인 배너
// ============================================================

(function () {

// === 공통: 배너 호스트(스택 컨테이너) ===
const HOST_ID = "__ext_banner_host__";
function ensureBannerHost() {
let host = document.getElementById(HOST_ID);
if (!host) {
host = document.createElement("div");
host.id = HOST_ID;
host.setAttribute("data-ext-banner-host", "1");
Object.assign(host.style, {
all: "initial",
position: "fixed",
top: "20px",
left: "50vw",
transform: "translateX(-50%)",
zIndex: "2147483647",
display: "flex",
flexDirection: "column",
alignItems: "center",
gap: "8px", // 배너 간격
pointerEvents: "none", // 클릭 방해 금지
contain: "layout style paint",
willChange: "transform",
});
(document.documentElement || document.body).appendChild(host);
}
return host;
}
// 호스트가 비면 삭제
function cleanupEmptyHost() {
const host = document.getElementById(HOST_ID);
if (host && host.children.length === 0) host.remove();
}



// ============================================================
// 0. 공통 상태 / 공통 UI
// ============================================================

let bannerEl = null;
let blinkTimer = null;
let blinkCount = 0;

function showWarningBanner(text) {
if (bannerEl) return;

bannerEl = document.createElement("div");
bannerEl.textContent = text;
bannerEl.setAttribute("data-ext-banner", "visit");

Object.assign(bannerEl.style, {
color: "#ffffffff",
fontSize: "20px",
fontWeight: "700",
background: "rgba(233, 34, 34, 0.91)",
padding: "12px 22px",
borderRadius: "16px",
opacity: "1",
transition: "opacity 0.2s ease",
boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
pointerEvents: "none",
});

ensureBannerHost().appendChild(bannerEl);
startBlink();
}

function removeWarningBanner() {
if (!bannerEl) return;
clearInterval(blinkTimer);
bannerEl.remove();
bannerEl = null;
cleanupEmptyHost(); // ← 추가
}

function startBlink() {
blinkCount = 0;
clearInterval(blinkTimer);

blinkTimer = setInterval(() => {
if (!bannerEl) return;

bannerEl.style.opacity =
bannerEl.style.opacity === "1" ? "0" : "1";

blinkCount++;

if (blinkCount >= 10) { // 5회
clearInterval(blinkTimer);
bannerEl.style.opacity = "1";
}
}, 300);
}

// ============================================================
// 1. expiry-date.js 와 동일한 블랙리스트 + 쿠팡
// ============================================================
const BLACKLIST_SITES = [
"https://shopping.naver.com/popup/seller-info", // 네이버 판매자정보 팝업
"http://price.coupang.com", // 어드민
"https://price.coupang.com", // 어드민
"file://", // 파일
"https://docs.google.com/", // 구글 독스
"https://coupang.service-now.com/", // 서비스 나우
"https://coupangnam-my.sharepoint.com/", // sharepoint 1
"https://catalog-tools.coupang.net/quality/vendoritem/", // GO 통합상세
"https://wiki.coupang.net/", // 위키
"https://news.coupang.com/", // 쿠팡 뉴스룸
"https://coupang.okta.com/", // 옥타
"https://m365.cloud.microsoft/", // MS
"https://rcc.coupang.net/", // RCC
"https://wd3.myworkday.com/", // 워크데이
"https://copilot.cloud.microsoft/", // MS
"https://promotion.coupang.net/", // 뽐뿌
"https://www.google.com/", // 구글
"https://coupang.sharepoint.com/", // sharepoint
"https://outlook.office.com/", // 아웃룩
"https://auth.coupangcorp.net/", // 옥타 인증페이지
"https://gemini.google.com/", // 재미나이
"https://www.naver.com/", // 네이버
"https://coupangnam.sharepoint.com/", // 위키
"https://drive.google.com/", // 구글 드라이브
"https://coupang.metapay.co.kr/", // 메타페이
"https://papago.naver.com/", // 파파고
"https://www.coupang.com/", // 쿠팡
"https://search.naver.com/" // 네이버
];

function isBlacklistSite() {
return BLACKLIST_SITES.some(url => location.href.startsWith(url));
}

if (isBlacklistSite()) return;

// ============================================================
// 2. 어드민 상태 확인 → 배너 제어
// ============================================================

function refresh() {
// 기본값을 지정: 값이 없거나 지워진 경우를 명시적으로 처리
chrome.storage.local.get(
{ "__ext_installation_type": "NONE" },
(res) => {
const type = res.__ext_installation_type; // "VISIT" | "NONE" | 기타

if (type === "VISIT") {
showWarningBanner("쿠팡 방문설치ㅣ경쟁사 설치 여부 확인필요");
} else {
removeWarningBanner();
}
}
);
}

// ============================================================
// 3. SPA / 새로고침 대응
// ============================================================

let raf;
const mo = new MutationObserver(() => {
if (raf) cancelAnimationFrame(raf);
raf = requestAnimationFrame(refresh);
});

mo.observe(document.body, {
childList: true,
subtree: true
});

chrome.storage.onChanged.addListener((changes, area) => {
if (area !== "local") return;
if (changes.__ext_installation_type || changes.__ext_installation_seen_at) {
refresh();
}
});

// 최초 1회
refresh();

})();
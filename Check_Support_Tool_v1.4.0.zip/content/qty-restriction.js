// ============================================================
// qty-restriction.js
// 최소 구매 수량 제한
// ============================================================

(function () {
// === 공통: 배너 호스트(스택 컨테이너) ===
const HOST_ID = "__ext_banner_host__";
function ensureBannerHost() {
let host = document.getElementById(HOST_ID);
if (!host) {
host = document.createElement("div");
host.id = HOST_ID;
host.setAttribute("data-ext-banner-host", "1");
Object.assign(host.style, {
all: "initial",
position: "fixed",
top: "20px",
left: "50vw",
transform: "translateX(-50%)",
zIndex: "2147483647",
display: "flex",
flexDirection: "column",
alignItems: "center",
gap: "8px", // 배너 간격
pointerEvents: "none", // 클릭 방해 금지
contain: "layout style paint",
willChange: "transform",
});
(document.documentElement || document.body).appendChild(host);
}
return host;
}
// 호스트가 비면 삭제
function cleanupEmptyHost() {
const host = document.getElementById(HOST_ID);
if (host && host.children.length === 0) host.remove();
}

// ============================================================
// 0. 공통 상태 / 공통 UI
// ============================================================

let bannerEl = null;
let blinkTimer = null;
let blinkCount = 0;

// ------------------------------------------------------------
// 1. 공통 배너
// ------------------------------------------------------------
function showWarningBanner(text) {
if (bannerEl) return;

bannerEl = document.createElement("div");
bannerEl.textContent = text;
bannerEl.setAttribute("data-ext-banner", "qty");

Object.assign(bannerEl.style, {
color: "#ffffffff",
fontSize: "20px",
fontWeight: "700",
background: "rgba(233, 34, 34, 0.91)",
padding: "12px 22px",
borderRadius: "16px",
opacity: "1",
transition: "opacity 0.2s ease",
boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
pointerEvents: "none",
});

ensureBannerHost().appendChild(bannerEl);
startBlink();
}

function removeWarningBanner() {
if (!bannerEl) return;

clearInterval(blinkTimer);
bannerEl.remove();
bannerEl = null;
cleanupEmptyHost(); // ← 추가
}

// ------------------------------------------------------------
// 3. 깜빡임 (5회 후 고정)
// ------------------------------------------------------------
function startBlink() {
blinkCount = 0;
clearInterval(blinkTimer);

blinkTimer = setInterval(() => {
if (!bannerEl) return;

bannerEl.style.opacity =
bannerEl.style.opacity === "1" ? "0" : "1";

blinkCount++;

// on/off = 1회 → 10번 = 5회
if (blinkCount >= 10) {
clearInterval(blinkTimer);
bannerEl.style.opacity = "1";
}
}, 300);
}

// ============================================================
// 4. 사이트 분기 진입점
// ============================================================

const host = location.host;

// ------------------------------------------------------------
// 5-1. 네이버 스마트스토어
// ------------------------------------------------------------
if (host.includes("smartstore.naver.com")) {
runSmartStoreObserver();
return;
}

// ============================================================
// 5-1. 네이버 스마트스토어 전용 로직
// ============================================================

// ------------------------------------------------------------
// 5-1. 구매 영역 컨테이너
// ------------------------------------------------------------
function getNaverPurchaseContainer() {
return document.querySelector("fieldset.zFcPceRwDS");
}

// ------------------------------------------------------------
// 5-1. 최소구매 문구 체크
// ------------------------------------------------------------
function hasNaverMinBuyText(container) {
if (!container) return false;

const p = container.querySelector("p.S_ixevsgwu");
if (!p) return false;

const txt = p.textContent || "";
const m = txt.match(/최소구매\s*(\d+)/);
return m && Number(m[1]) > 1;
}

// ------------------------------------------------------------
// 5-1. 최소구매 문구 컬러링
// ------------------------------------------------------------
function highlightNaverMinBuyText(container) {
const p = container.querySelector("p.S_ixevsgwu");
if (!p) return;

Object.assign(p.style, {
display: "inline-block",
padding: "4px 8px",
border: "2px solid #d32f2f",
backgroundColor: "#fff5f5",
borderRadius: "4px",
fontWeight: "700"
});
}

// ------------------------------------------------------------
// 5-1. 최소구매 문구 하이라이트 제거
// ------------------------------------------------------------
function resetNaverMinBuyText(container) {
const p = container.querySelector("p.S_ixevsgwu");
if (!p) return;

p.style.display = "";
p.style.padding = "";
p.style.border = "";
p.style.backgroundColor = "";
p.style.borderRadius = "";
p.style.fontWeight = "";
}

// ------------------------------------------------------------
// 5-1. 수량 input 강조
// ------------------------------------------------------------
function highlightNaverQtyInput(container) {
const input = container.querySelector("input.WdVaW2Rsa0");
if (!input) return;

input.style.border = "2px solid #d32f2f";
input.style.background = "#fff5f5";
input.style.color = "#d32f2f";
input.style.fontWeight = "700";
}

// ------------------------------------------------------------
// 5-1. 수량 input 원복
// ------------------------------------------------------------
function resetNaverQtyInput(container) {
const input = container.querySelector("input.WdVaW2Rsa0");
if (!input) return;

input.style.border = "";
input.style.background = "";
input.style.color = "";
input.style.fontWeight = "";
}


// ------------------------------------------------------------
// 5-1. 수량 input value > 1 체크
// ------------------------------------------------------------
function hasNaverQtyOverOne(container) {
if (!container) return false;

const input = container.querySelector('input.WdVaW2Rsa0');
if (!input) return false;

const v = Number(input.value);
return !isNaN(v) && v > 1;
}

// ------------------------------------------------------------
// 5-1.상태 판단
// ------------------------------------------------------------
function checkNaverRestriction() {
const container = getNaverPurchaseContainer();
if (!container) return false;

return (
hasNaverMinBuyText(container) ||
hasNaverQtyOverOne(container)
);
}

// ------------------------------------------------------------
// 5-1. 상태 갱신
// ------------------------------------------------------------
function refreshNaver() {
if (checkNaverRestriction()) {
showWarningBanner("최소 구매 수량 확인 필요");
} else {
removeWarningBanner();
}
}

function refreshNaver() {
const container = getNaverPurchaseContainer();
if (!container) return;

const hasMinBuy = hasNaverMinBuyText(container);
const hasQtyOver = hasNaverQtyOverOne(container);

// ---- 최소구매 문구 컬러링 ----
if (hasMinBuy) {
highlightNaverMinBuyText(container);
} else {
resetNaverMinBuyText(container);
}


// ---- 수량 input 컬러링 ----
if (hasQtyOver) {
highlightNaverQtyInput(container);
} else {
resetNaverQtyInput(container);
}

// ---- 경고 문구 ----
if (hasMinBuy || hasQtyOver) {
showWarningBanner("최소 구매 수량 확인 필요");
} else {
removeWarningBanner();
}
}



// ------------------------------------------------------------
// 6. SPA 대응 Observer
// ------------------------------------------------------------
function runSmartStoreObserver() {
let raf;

const mo = new MutationObserver(() => {
if (raf) cancelAnimationFrame(raf);
raf = requestAnimationFrame(refreshNaver);
});

mo.observe(document.body, {
childList: true,
subtree: true,
attributes: true
});

// 최초 1회 실행
refreshNaver();
}

})();
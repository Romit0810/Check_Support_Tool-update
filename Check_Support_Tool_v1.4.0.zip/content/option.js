//============================================================
// option.js
// 어드민 1 전용 옵션
//============================================================
(function () {
if (window.__EXT_OPTION_ACTIVE__) return;
window.__EXT_OPTION_ACTIVE__ = true;

// ── 블랙리스트(컬러링 금지) - URL Prefix 기준 ─────────────────
const AO_BLACKLIST_PREFIXES = [
"https://shopping.naver.com/popup/seller-info", // 네이버 판매자정보 팝업
"http://price.coupang.com", // 어드민
"https://price.coupang.com", // 어드민
"file://", // 파일
"https://docs.google.com/", // 구글 독스
"https://coupang.service-now.com/", // 서비스 나우
"https://coupangnam-my.sharepoint.com/", // sharepoint 1
"https://catalog-tools.coupang.net/quality/vendoritem/", // GO 통합상세
"https://wiki.coupang.net/", // 위키
"https://news.coupang.com/", // 쿠팡 뉴스룸
"https://coupang.okta.com/", // 옥타
"https://m365.cloud.microsoft/", // MS
"https://rcc.coupang.net/", // RCC
"https://wd3.myworkday.com/", // 워크데이
"https://copilot.cloud.microsoft/", // MS
"https://promotion.coupang.net/", // 뽐뿌
"https://www.google.com/", // 구글
"https://coupang.sharepoint.com/", // sharepoint
"https://outlook.office.com/", // 아웃룩
"https://auth.coupangcorp.net/", // 옥타 인증페이지
"https://gemini.google.com/", // 재미나이
"https://www.naver.com/", // 네이버
"https://coupangnam.sharepoint.com/", // 위키
"https://drive.google.com/", // 구글 드라이브
"https://coupang.metapay.co.kr/", // 메타페이
"https://papago.naver.com/", // 파파고
"https://www.coupang.com/", // 쿠팡
];
function aoIsBlacklisted(href) {
try { return AO_BLACKLIST_PREFIXES.some(p => href.startsWith(p)); }
catch { return false; }
}

// ===== 상수 =====
const OPTION_KEY = "__ext_competitor_options"; // 옵션 배열(빈 배열 허용)

const HIGHLIGHT_BG = "#b9ff74";
const HIGHLIGHT_COLOR = "#000000ff";
const SCHEDULE_MS = 150;
const EXT_MARK_ATTR = "data-ao"; // 하이라이트 마커
const ALLOW_CLASS = "__ext-ao-allow"; // 허용 스코프 표시 class
const STYLE_ID = "__ext_option_block_css"; // 무효화 CSS id
const BANNER_ATTR = "data-overseas-banner";

const host = location.host;
const path = location.pathname || "";
const isAdminHost = host === "price.coupang.com";
const isAdmin1 = isAdminHost && /^#\/matching\/\d+(\b|[/?#])?/i.test(location.hash || "");

// ── 유틸 ─────────────────────────────────────────────────────
const log = (...args) => { try { console.log("[OPTION]", ...args); } catch (_) { } };
function isVisible(el) {
if (!el) return false;
if (el.offsetParent !== null) return true;
return el.getClientRects && el.getClientRects().length > 0;
}

function escHtml(s) {
return String(s || "")
.replace(/&/g, "&amp;")
.replace(/</g, "&lt;")
.replace(/>/g, "&gt;")
.replace(/"/g, "&quot;");
}

// [추가] 비교용 정규화: 옵션명 끝에 붙는 꼬리문구 3종 제거 + 공백 정리
// - "-N개 남음" : 하이픈 포함, N은 숫자, 사이 공백 무시
// - "(품절)" : 괄호 포함, 공백 무시
// - "(+N원)" : 괄호+플러스+숫자+원, 천단위 콤마 허용, 공백 무시
function normalizeForExactCompare(s) {
let t = String(s || "").replace(/\s+/g, " ").trim();

// 1) "-N개 남음" (끝에서 제거, 공백 허용)
t = t.replace(/\s*-\s*\d+\s*개\s*남음\s*$/g, "");

// 2) "(품절)" (끝에서 제거, 괄호/공백 허용)
t = t.replace(/\s*\(\s*품절\s*\)\s*$/g, "");

// 3) "(+N원)" (끝에서 제거, 천단위 콤마 허용, 공백 허용)
t = t.replace(/\s*\(\s*\+\s*\d{1,3}(?:,\d{3})*\s*원\s*\)\s*$/g, "");

return t.trim();
}

// 전체 일치만 허용
function buildOptionsRegex(options) {
const sorted = [...options].filter(Boolean).sort((a, b) => b.length - a.length);

const toFlexiblePattern = (s) => {
let esc = String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
esc = esc.replace(/ +/g, "[\\s\\u00A0\\u1680\\u2000-\\u200B\\u202F\\u205F\\u3000]+");
esc = esc.replace(/\\-/g, "[-\\u2212\\u2010-\\u2015]");
return esc;
};

const escaped = sorted.map(toFlexiblePattern);
const WORD = "0-9A-Za-z_\\uAC00-\\uD7A3";
if (!escaped.length) return { sorted, regex: /(?!)/g, source: "(?!)" };

const leftBoundary = `(^|[^${WORD}])`;
const body = `(${escaped.join("|")})`;

// [중요] tail을 캡처 그룹으로 둠
const tail =
`(\\s*-\\s*\\d+\\s*개\\s*남음\\s*|\\s*\\(\\s*품절\\s*\\)\\s*|\\s*\\(\\s*\\+\\s*\\d{1,3}(?:,\\d{3})*\\s*원\\s*\\)\\s*)?`;

const rightBoundary = `(?![${WORD}])`;

const source = `${leftBoundary}${body}${tail}${rightBoundary}`;
return { sorted, regex: new RegExp(source, "g"), source };
}

function traverseRootWithShadow(root, each) {
if (!root) return;
each(root);
if (root.querySelectorAll) {
const all = root.querySelectorAll("*");
all.forEach(el => {
if (el.shadowRoot) {
each(el.shadowRoot);
traverseRootWithShadow(el.shadowRoot, each);
}
});
}
}
function unwrapNode(node) {
const p = node && node.parentNode;
if (!p) return;
const frag = document.createDocumentFragment();
while (node.firstChild) frag.appendChild(node.firstChild);
p.replaceChild(frag, node);
}
function clearAoMark(el) {
if (!el) return;
el.style.backgroundColor = "";
el.style.color = "";
el.style.fontWeight = "";
el.style.outline = "";
if (el.hasAttribute(EXT_MARK_ATTR)) el.removeAttribute(EXT_MARK_ATTR);
}
function unwrapAllHighlights(root = document) {
let dirty = true;
while (dirty) {
dirty = false;
traverseRootWithShadow(root, (r) => {
if (!r.querySelectorAll) return;
const nodes = r.querySelectorAll(`[${EXT_MARK_ATTR}]`);
if (nodes.length) {
nodes.forEach(n => {
if (n.tagName === "SPAN") {
unwrapNode(n);
} else {
clearAoMark(n); // 버튼/기타 네이티브는 스타일/마커만 제거
}
});
dirty = true;
}
});
}
}
function pruneObsoleteHighlightsInScope(scopeRoot, optionsRe) {
if (!scopeRoot.querySelectorAll) return;
let changed = true;
while (changed) {
changed = false;
const nodes = scopeRoot.querySelectorAll(`[${EXT_MARK_ATTR}]`);
for (const n of nodes) {
if (n.querySelector && n.querySelector(`[${EXT_MARK_ATTR}]`)) continue; // leaf만
const txt = (n.textContent || "").trim();
const re = new RegExp(optionsRe.source, "g");
if (!re.test(txt)) {
if (n.tagName === "SPAN") {
unwrapNode(n); // 텍스트 래퍼만 언랩
} else {
clearAoMark(n); // 버튼/기타 네이티브는 마커/스타일만 제거
}
changed = true;
break;
}
}
}
}

// ── 깜빡임 방지 CSS ──────────────────────────────────────────
function isScopedHost() {
if (host === "brand.naver.com") return true;
if (host === "smartstore.naver.com") return true;
if (/\.?11st\.co\.kr$/i.test(host) && path.startsWith("/products/")) return true;
if (/\.?gmarket\.co\.kr$/i.test(host) && path.toLowerCase().startsWith("/item")) return true;
if (/^itempage\d*\.auction\.co\.kr$/i.test(host)) return true;

// 오늘의집: /goods/ 와 /store/goods/ 모두 허용
const isOhouse = /(?:^|\.)ohou\.se$/i.test(host) &&
(/^\/goods\//.test(path) || /^\/store\/goods\//.test(path));
if (isOhouse) return true;

// ⭐ 무신사: www.musinsa.com / store.musinsa.com 의 상품 상세만 허용
// - /products/ (www.musinsa.com)
// - /app/goods/ 또는 /goods/ (store.musinsa.com 등)
if (/(?:^|\.)musinsa\.com$/i.test(host) && (
/^\/products\//.test(path) ||
/^\/app\/goods\//.test(path) ||
/^\/goods\//.test(path)
)) return true;

return false;
}

function injectBlockCSS() {
if (document.getElementById(STYLE_ID)) return;
let css = "";
if (isAdminHost) {
css += `
html [${EXT_MARK_ATTR}]{
background-color: transparent !important;
color: inherit !important;
font-weight: inherit !important;
}
`;
} else if (isScopedHost()) {
css += `
html [${EXT_MARK_ATTR}]{
background-color: transparent !important;
color: inherit !important;
font-weight: inherit !important;
}
.${ALLOW_CLASS} [${EXT_MARK_ATTR}]{
background-color: ${HIGHLIGHT_BG} !important;
color: ${HIGHLIGHT_COLOR} !important;
font-weight: 700 !important;

}
`;

}
if (css.trim()) {
const style = document.createElement("style");
style.id = STYLE_ID;
style.type = "text/css";
style.textContent = css;
(document.head || document.documentElement).appendChild(style);
}
}
injectBlockCSS();

// ── Admin1: 옵션 추출만, 컬러링 금지 + 하트비트 ───────────────
if (isAdmin1) {
log("Admin1 detected → 옵션 추출/저장 + 하트비트");

function getSingleVisibleRow() {
// ★ admin.js(siteitem)과 동일: '외부 매핑' 탭 패널을 확정
const mappingsPaneById = document.querySelector('[id$="-panel-mappings"]');
const mappingsPaneActive = document.querySelector('.ant-tabs-tabpane-active[id$="-panel-mappings"]');
const activeBtn = document.querySelector('.ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn');
const activePaneByActiveBtn = (activeBtn && document.getElementById(activeBtn.getAttribute('aria-controls'))) || null;

const pane = mappingsPaneActive || mappingsPaneById || activePaneByActiveBtn ||
document.querySelector('.ant-tabs-content-holder .ant-tabs-tabpane-active');

if (pane) {
// 1) 가상 테이블(div 기반): 활성 패널 내부에서 '보이는' 행만 수집
const virtualHolder = pane.querySelector(".ant-table-tbody-virtual-holder-inner");
if (virtualHolder && isVisible(virtualHolder)) {
const vRows = Array.from(
virtualHolder.querySelectorAll(".ant-table-row[data-row-key]")
).filter(r => isVisible(r) && (r.textContent || "").trim() !== "");
if (vRows.length === 1) return vRows[0];
}

// 2) 실제 <table> 기반(구버전 호환): 활성 패널 내부에서만 판단
const table = pane.querySelector(".ant-table-body table");
if (table && isVisible(table)) {
const rows = Array.from(table.querySelectorAll("tbody tr"))
.filter(tr =>
isVisible(tr) &&
tr.querySelector("td") &&
tr.textContent.trim() !== ""
);
if (rows.length === 1) return rows[0];
}
}

// ★ admin.js(siteitem)과 동일: 패널 안에서 '정확히 1행'이 아니면 null
return null;
}
function findItemNameElFromRow(rowEl) {
if (!rowEl) return null;
let el = rowEl.querySelector(".ManualMappingListContainer__itemName___27daQ");
if (el) return el;
el = rowEl.querySelector('#itemName, [id="itemName"]');
if (el) return el;
const candidates = Array.from(rowEl.querySelectorAll(".ant-table-cell, td, div"));
for (const c of candidates) {
const t = (c.textContent || "").trim();
if (t && t.length >= 2 && !c.querySelector("input,button,select,textarea")) return c;
}
return null;
}
function extractOptions() {
const rowEl = getSingleVisibleRow();
if (!rowEl) return [];

// [추가] 현재 행에서 경쟁사 링크 host가 brand.naver.com이면 슬래시 허용
let useSlash = false;
try {
const link = rowEl.querySelector('a[href]');
if (link && link.href) {
const u = new URL(link.href);
if (u.hostname === 'brand.naver.com') useSlash = true;
}
} catch (_) { }

const nameEl = findItemNameElFromRow(rowEl);
if (!nameEl) return [];
const text = (nameEl.textContent || "").trim();
const out = [];

// [변경] 구분자 동적 구성: "::" / ":!:" 기본 + (브랜드스토어일 때만 "/")
const delim = useSlash ? '(::|:!:|/)' : '(::|:!:)';
const re = new RegExp(`${delim}\\s*([\\s\\S]*?)(?=\\s*${delim}|$)`, 'g');

let m;
while ((m = re.exec(text)) !== null) {
const seg = String(m[2] || "").replace(/\s+/g, " ").trim();
if (seg) out.push(seg);
}
return Array.from(new Set(out)).filter(Boolean).sort((a, b) => b.length - a.length);
}

function saveOptions() {
const options = extractOptions(); // "::"나 ":!:" 없으면 빈 배열
try {
chrome.storage.local.set({ [OPTION_KEY]: options });
} catch (_) { }
log("(Admin1) 저장 옵션:", options);
}

// 최초 저장 + 변화 감지 저장
saveOptions();
let raf = null;
const mo = new MutationObserver(() => {
if (raf) cancelAnimationFrame(raf);
raf = requestAnimationFrame(saveOptions);
});
mo.observe(document.body, { childList: true, subtree: true, characterData: true });

// 탭 이탈/닫힘 시 정리: 하트비트 종료 + 옵션 즉시 비움
function cleanOnUnload() {
try {
chrome.storage.local.set({ [OPTION_KEY]: [] }); // 옵션만 비움
} catch (_) { }
}
window.addEventListener("beforeunload", cleanOnUnload);
window.addEventListener("pagehide", cleanOnUnload);

// 다른 스크립트 잔여 대비
(function stripAllHighlightsOnce() {
unwrapAllHighlights(document);
})();

return; // Admin1은 컬러링 금지
}

// 어드민 호스트(어드민2 포함) 전체 차단(이중 안전)
if (isAdminHost) {
unwrapAllHighlights(document);
log("Admin host detected → 컬러링 비활성화 및 잔여 언랩");
return;
}

// ── 스코프 레지스트리 (화이트리스트) ─────────────────────────
const SITE_SCOPES = {
entries: [
// NAVER 브랜드스토어: 드롭다운 패널 + 라디오형 옵션(색상/사이즈) 라벨/컨테이너 허용
{
id: "naver_brandstore_option_dropdown",
isMatch() { return host === "brand.naver.com"; },
getAllowedRoots() {
const btnSel = [
'a[role="button"][aria-haspopup="listbox"][data-shp-area-id="optselect"]',
'a[role="button"][aria-haspopup="listbox"][data-shp-contents-type="옵션"]',
].join(", ");
const buttons = Array.from(document.querySelectorAll(btnSel)).filter(isVisible);
const panels = Array.from(document.querySelectorAll('[role="listbox"]')).filter(isVisible);

const allowed = new Set();

// ✅ 드롭다운(buttons/panels)이 있으면 근접 패널 매칭 (없어도 그냥 넘어감)
if (buttons.length && panels.length) {
const MAX_DIST = 600;
for (const btn of buttons) {
const br = btn.getBoundingClientRect();
const bcx = br.left + br.width / 2, bcy = br.top + br.height / 2;
let best = null, bestDist = Infinity;
for (const p of panels) {
if (!p.querySelector('[role="option"]')) continue;
const pr = p.getBoundingClientRect();
const pcx = pr.left + pr.width / 2, pcy = pr.top + pr.height / 2;
const dist = Math.hypot(bcx - pcx, bcy - pcy);
if (dist < bestDist) { bestDist = dist; best = p; }
}
if (best && bestDist <= MAX_DIST) allowed.add(best);
}
}

// 라디오형 옵션 컨테이너/버튼 주변을 확실히 허용 (브랜드스토어/팜스토어 공통 + fallback)
const brandExtra = [
// 주변 제목/컨테이너 (기존)
...document.querySelectorAll("strong.ozMukSs9gm, .UQXwEUpdEN .U9FovFnBmF"),
...document.querySelectorAll(".flicking-viewport[role='radiogroup'], .flicking-viewport[role='radiogroup'] ul.flicking-camera"),
...document.querySelectorAll(".TYJuaB03Ht"),

// 브랜드/팜 공통 라디오 그룹
...document.querySelectorAll('div.W1uViPpPDJ[role="radiogroup"]'), // 색상 칩
...document.querySelectorAll('div.XCOrxJzfAt[role="radiogroup"]'), // 사이즈 버튼

// 속성 fallback
...document.querySelectorAll('div[role="radiogroup"][data-shp-contents-type="색상"]'),
...document.querySelectorAll('div[role="radiogroup"][data-shp-contents-type="사이즈"]'),

// 상위 래퍼도 허용 (자손까지 허용 범위로)
...document.querySelectorAll('div.mEPWmZh5g9'),
...document.querySelectorAll('div.ggfaY5qRku'),
...document.querySelectorAll('div.xfW3DXpUDw'),
].filter(isVisible);

brandExtra.forEach(n => allowed.add(n));

const roots = Array.from(allowed);
roots.forEach(r => r.classList.add(ALLOW_CLASS));
return roots;
},
},
// NAVER 스마트스토어: 옵션/수량 드롭다운 + 라디오형 옵션(사이즈 등) 허용 (+네이버 팜 추가상품 약식 대응)
{
id: "naver_smartstore_quantity_dropdown",
isMatch() { return host === "smartstore.naver.com"; },
getAllowedRoots() {
const btnSel = 'a[role="button"][aria-haspopup="listbox"][data-shp-area-id="optselect"]';
const buttons = Array.from(document.querySelectorAll(btnSel)).filter(isVisible);
const allowed = new Set();

if (buttons.length) {
const NEAR_CONTAINER_SEL = ['.KobocOawE2', '.hChTeQ6YMe', '.DcIEfnCExV'].join(', ');
for (const btn of buttons) {
const container = btn.closest(NEAR_CONTAINER_SEL) || btn.parentElement;
if (container) {
const listboxes = Array.from(container.querySelectorAll('ul[role="listbox"], [role="listbox"]')).filter(isVisible);
for (const lb of listboxes) allowed.add(lb);
}
}
if (allowed.size === 0) {
const panels = Array.from(document.querySelectorAll('ul[role="listbox"], [role="listbox"]')).filter(isVisible);
const MAX_DIST = 800;
for (const btn of buttons) {
const br = btn.getBoundingClientRect();
const bcx = br.left + br.width / 2, bcy = br.top + br.height / 2;
let best = null, bestDist = Infinity;
for (const p of panels) {
if (!p.querySelector('[role="option"]')) continue;
const pr = p.getBoundingClientRect();
const pcx = pr.left + pr.width / 2, pcy = pr.top + pr.height / 2;
const dist = Math.hypot(bcx - pcx, bcy - pcy);
if (dist < bestDist) { bestDist = dist; best = p; }
}
if (best && bestDist <= MAX_DIST) allowed.add(best);
}
}
}

// 라디오형 옵션 컨테이너/버튼(질문 예시 구조) 허용
const smartRadio = [
...document.querySelectorAll("div.XCOrxJzfAt[role='radiogroup']"),
...document.querySelectorAll(".XCOrxJzfAt .wdKPuojthN"),
].filter(isVisible);
smartRadio.forEach(n => allowed.add(n));

// 스마트스토어 이미지형(색상) 라디오 그룹/버튼 허용
const smartImageRadio = [
...document.querySelectorAll("div.WrWW4M9Uiw[role='radiogroup']"),
...document.querySelectorAll(".WrWW4M9Uiw .NoyQpm_sXz"),
].filter(isVisible);
smartImageRadio.forEach(n => allowed.add(n));


// 네이버 팜스토어 '추가상품' 선택 영역 약식 허용
(function addNaverFarmstoreAddons() {
const farmAddOns = [
...document.querySelectorAll('div.orO5q51AZl'),
...document.querySelectorAll('div.ZgZdx4P82q'),
...document.querySelectorAll('a[role="button"][aria-haspopup="listbox"][data-shp-area-id="addpdone"]'),
...document.querySelectorAll('a.JybyQCJXjS[role="button"][aria-haspopup="listbox"]'),
].filter(isVisible);
farmAddOns.forEach(n => allowed.add(n));
})();

// [신규 추가] 네이버 '팜스토어' 색상 라벨 strong 허용
(function addNaverFarmstoreColorTitle() {
// 1)
const titles = Array.from(
document.querySelectorAll('div.xfW3DXpUDw > strong.C7JiRBcY_D')
).filter(isVisible);

// 2) 허용 목록에 추가
titles.forEach(t => allowed.add(t));

})();
smartImageRadio.forEach(n => allowed.add(n));
const roots = Array.from(allowed);
roots.forEach(r => r.classList.add(ALLOW_CLASS));
return roots;
},
},

// 11번가: 구매박스 옵션 드롭다운 내부
{
id: "elevenst_products_dropdown",
isMatch() { return /\.?11st\.co\.kr$/i.test(host) && path.startsWith("/products/"); },
getAllowedRoots() {
const roots = [
...Array.from(document.querySelectorAll(".l_product_buy_list .accordion_body.dropdown_list")),
...Array.from(document.querySelectorAll(".l_product_buy_list ul.option_item_list")),
...Array.from(document.querySelectorAll(".l_product_buy_list ul.b_product_buy_option")),
].filter(isVisible);
roots.forEach(r => r.classList.add(ALLOW_CLASS));
return roots;
},
},

// Gmarket: uxeselect 레이어/리스트 내부
{
id: "gmarket_item_dropdown",
isMatch() { return /\.?gmarket\.co\.kr$/i.test(host) && path.toLowerCase().startsWith("/item"); },
getAllowedRoots() {
const BTN_SEL = [
'button.select-item_option.uxeselect_btn',
'button.uxeselect_btn.select-item_option',
'button.uxeselect_btn',
'button.select-item_option'
].join(", ");
const buttons = Array.from(document.querySelectorAll(BTN_SEL)).filter(isVisible);
if (!buttons.length) return [];
const allowed = new Set();

const PANEL_SEL_STRICT = [
'[role="listbox"].select-item_list',
'ul.select-item_list[role="listbox"]',
'.uxeselect_layer',
'.select-item_layer',
'.option_list',
'.option_select_list',
'.select-list'
].join(', ');

const NEAR_CONTAINER_SEL = [
'.uxeselect', '.select-item', '.option_box', '.option_select',
'.vip_prd_option', '.layer_wrap', '.list_select'
].join(', ');

const hasOptionsStrict = (el) =>
!!el.querySelector('[role="option"], li.option_item, li .option_item, a[role="option"], button[role="option"]');

for (const btn of buttons) {
const sib = btn.nextElementSibling;
if (sib && isVisible(sib) && sib.matches(PANEL_SEL_STRICT) && hasOptionsStrict(sib)) {
allowed.add(sib); continue;
}
const container = btn.closest(NEAR_CONTAINER_SEL) || btn.parentElement;
if (container) {
const localPanels = Array.from(container.querySelectorAll(PANEL_SEL_STRICT)).filter(el => isVisible(el) && hasOptionsStrict(el));
for (const p of localPanels) allowed.add(p);
if (!localPanels.length) {
const relaxed = Array.from(container.querySelectorAll('ul, ol')).filter(el => isVisible(el) && el.querySelector('li'));
for (const p of relaxed) allowed.add(p);
}
}
}

if (allowed.size === 0) {
const allStrictPanels = Array.from(document.querySelectorAll(PANEL_SEL_STRICT)).filter(el => isVisible(el) && hasOptionsStrict(el));
const MAX_DIST = 1000;
for (const btn of buttons) {
const br = btn.getBoundingClientRect();
const bcx = br.left + br.width / 2, bcy = br.top + br.height / 2;
let best = null, bestDist = Infinity;
for (const p of allStrictPanels) {
const pr = p.getBoundingClientRect();
const pcx = pr.left + pr.width / 2, pcy = pr.top + pr.height / 2;
const dist = Math.hypot(bcx - pcx, bcy - pcy);
if (dist < bestDist) { bestDist = dist; best = p; }
}
if (best && bestDist <= MAX_DIST) allowed.add(best);
}
}

const roots = Array.from(allowed);
roots.forEach(r => r.classList.add(ALLOW_CLASS));
log("Gmarket allowed roots:", roots.length);
return roots;
},
},

// Auction: uxeselect 레이어/리스트 + 썸네일형 옵션 리스트 허용
{
id: "auction_item_dropdown",
isMatch() { return /^itempage\d*\.auction\.co\.kr$/i.test(host); },
getAllowedRoots() {
const BTN_SEL = [
'button.select-item_option.uxeselect_btn',
'button.uxeselect_btn.select-item_option',
'button.uxeselect_btn',
'button.select-item_option'
].join(", ");
const buttons = Array.from(document.querySelectorAll(BTN_SEL)).filter(isVisible);
if (!buttons.length) return [];
const allowed = new Set();

const PANEL_SEL_STRICT = [
'[role="listbox"].select-item_list',
'ul.select-item_list[role="listbox"]',
'.uxeselect_layer',
'.select-item_layer',
'.option_list',
'.option_select_list',
'.select-list'
].join(', ');

const NEAR_CONTAINER_SEL = [
'.uxeselect', '.select-item', '.option_box', '.option_select',
'.vip_prd_option', '.layer_wrap', '.list_select',
'.section_opt', '.box_opt', '.area_select'
].join(', ');

const hasOptionsStrict = (el) =>
!!el.querySelector('[role="option"], li.option_item, li .option_item, a[role="option"], button[role="option"]');

for (const btn of buttons) {
const sib = btn.nextElementSibling;
if (sib && isVisible(sib) && sib.matches(PANEL_SEL_STRICT) && hasOptionsStrict(sib)) {
allowed.add(sib); continue;
}
const container = btn.closest(NEAR_CONTAINER_SEL) || btn.parentElement;
if (container) {
const localPanels = Array.from(container.querySelectorAll(PANEL_SEL_STRICT)).filter(el => isVisible(el) && hasOptionsStrict(el));
for (const p of localPanels) allowed.add(p);
if (!localPanels.length) {
const relaxed = Array.from(container.querySelectorAll('ul, ol')).filter(el => isVisible(el) && el.querySelector('li'));
for (const p of relaxed) allowed.add(p);
}
}
}

if (allowed.size === 0) {
const allStrictPanels = Array.from(document.querySelectorAll(PANEL_SEL_STRICT)).filter(el => isVisible(el) && hasOptionsStrict(el));
const MAX_DIST = 1000;
for (const btn of buttons) {
const br = btn.getBoundingClientRect();
const bcx = br.left + br.width / 2, bcy = br.top + br.height / 2;
let best = null, bestDist = Infinity;
for (const p of allStrictPanels) {
const pr = p.getBoundingClientRect();
const pcx = pr.left + pr.width / 2, pcy = pr.top + pr.height / 2;
const dist = Math.hypot(bcx - pcx, bcy - pcy);
if (dist < bestDist) { bestDist = dist; best = p; }
}
if (best && bestDist <= MAX_DIST) allowed.add(best);
}
}

// 썸네일형 옵션 리스트 허용
const auctionExtra = Array.from(document.querySelectorAll("ul.type_thumbnail.item_block_lst")).filter(isVisible);
auctionExtra.forEach(n => allowed.add(n));

const roots = Array.from(allowed);
roots.forEach(r => r.classList.add(ALLOW_CLASS));
log("Auction allowed roots:", roots.length);
return roots;
},
},

// 오늘의집(ohou.se)
{
id: "ohouse_store_goods_scopes",
isMatch() {
return /(?:^|\.)ohou\.se$/i.test(host) &&
(/^\/goods\//.test(path) || /^\/store\/goods\//.test(path));
},
getAllowedRoots() {
const allowed = new Set(
[
// 선택된 옵션 박스(수량/가격 표시 포함)
...document.querySelectorAll('ul[data-testid="selected-option-list"]'),
// 네이티브 셀렉트 3종(옵션, 2차, 추가상품)
...document.querySelectorAll(
'select[data-testid="first-depth-select"], ' +
'select[data-testid="second-depth-select"], ' +
'select[data-testid="additional-select"]'
),
// fallback: 구매/옵션 영역의 범용 래퍼들 (DOM 변화 대응)
...document.querySelectorAll('#buy, [data-testid*="option"], [class*="Option"], [class*="option"]')
].filter(isVisible)
);
const roots = Array.from(allowed);
roots.forEach(r => r.classList.add(ALLOW_CLASS));
return roots;
},
},

// ⭐ 무신사(musinsa.com): 상품 옵션 드롭다운 스코프
{
id: "musinsa_product_option_dropdown",
isMatch() {
return /(?:^|\.)musinsa\.com$/i.test(host) && (
/^\/products\//.test(path) ||
/^\/app\/goods\//.test(path) ||
/^\/goods\//.test(path)
);
},
getAllowedRoots() {
// 선택자: 제공된 DOM 구조 기준 + 약간의 범용화
// - 정적 드롭다운 컨테이너/콘텐츠/아이템
// - 옵션 드롭다운 래퍼 및 트리거도 허용(텍스트 래핑 안전)
const nodes = [
// 전체 래퍼 (스타일드 컴포넌트 prefix 안정화)
...document.querySelectorAll('[class^="OptionDropdown__Wrapper-sc-"]'),
// 정적 드롭다운 컨테이너
...document.querySelectorAll('.static-dropdown-menu[data-mds="StaticDropdownMenu"]'),
// 펼쳐진 드롭다운 콘텐츠
...document.querySelectorAll('[data-mds="StaticDropdownMenuContent"]'),
// 개별 옵션 아이템
...document.querySelectorAll('[data-mds="StaticDropdownMenuItem"]'),
// 트리거(인풋/트리거박스): 텍스트 노드 래핑 대상 될 수 있어 허용
...document.querySelectorAll('[data-mds="DropdownTriggerBox"]'),
...document.querySelectorAll('[data-mds="DropdownTriggerInput"]'),
].filter(isVisible);

const allowed = new Set(nodes);
const roots = Array.from(allowed);
roots.forEach(r => r.classList.add(ALLOW_CLASS));
return roots;
},
},
],

getActiveAllowedRoots() {
const roots = [];
const seen = new Set();
for (const entry of this.entries) {
try {
if (!entry || typeof entry.isMatch !== "function" || typeof entry.getAllowedRoots !== "function") continue;
if (!entry.isMatch()) continue;
const arr = entry.getAllowedRoots() || [];
for (const r of arr) {
if (!r || r.nodeType !== 1) continue;
if (!seen.has(r)) {
seen.add(r);
roots.push(r);
}
}
} catch (e) { }
}
return roots;
}
};

// ── 컬러링(허용 스코프만) & 클린업 ────────────────────────────
function highlightTextNodesInScope(scopeRoot, optionsReLike) {
// ✅ 1단계: 모든 텍스트 노드 먼저 수집 (스냅샷)
const walker = document.createTreeWalker(
scopeRoot, NodeFilter.SHOW_TEXT,
{
acceptNode(node) {
const p = node.parentElement;
if (!node.nodeValue || !p) return NodeFilter.FILTER_REJECT;
if (p.closest && p.closest(`[${BANNER_ATTR}="1"]`)) return NodeFilter.FILTER_REJECT;
if (p.closest && p.closest(`[${EXT_MARK_ATTR}="1"]`)) return NodeFilter.FILTER_REJECT;
const tag = p.tagName;
if (tag === "OPTION" || tag === "SCRIPT" || tag === "STYLE") return NodeFilter.FILTER_REJECT;
return NodeFilter.FILTER_ACCEPT; // ✅ 일단 전부 수집
}
}
);

// ✅ 배열에 모두 담기
const allNodes = [];
let n;
while ((n = walker.nextNode())) {
allNodes.push(n);
}

// ✅ 2단계: 수집된 노드만 필터링 + 처리
const testRe = new RegExp(optionsReLike.source, optionsReLike.flags);
const nodes = allNodes.filter(node => {
// 노드가 여전히 DOM에 있고 부모가 있는지 확인
if (!node || !node.parentNode) return false;
return testRe.test(node.nodeValue);
});

// ✅ 3단계: 필터링된 노드만 컬러링
for (const textNode of nodes) {
// 다시 한번 부모 존재 확인 (안전장치)
if (!textNode.parentNode) continue;

const original = textNode.nodeValue || "";
const escaped = escHtml(original);
const re = new RegExp(optionsReLike.source, "g");

const highlightedHtml = escaped.replace(
re,
(m, g1, g2, g3) =>
`${g1 || ""}<span ${EXT_MARK_ATTR}="1" style="background-color:${HIGHLIGHT_BG};color:${HIGHLIGHT_COLOR};font-weight:700;">${escHtml(g2)}</span>${g3 || ""}`
);

const wrapper = document.createElement("span");
wrapper.innerHTML = highlightedHtml;

if (textNode.parentNode) {
textNode.parentNode.replaceChild(wrapper, textNode);
}
}
}

function highlightNativeSelectsInScope(scopeRoot, sortedOptions) {
if (!scopeRoot.querySelectorAll) return;

// 비교 대상(우리 옵션 키)도 정규화
const keysNorm = sortedOptions.map(k => normalizeForExactCompare(k));

const selects = scopeRoot.querySelectorAll("select");
selects.forEach(sel => {
const opts = sel.options || [];
for (let i = 0; i < opts.length; i++) {
const opt = opts[i];
const raw = (opt.textContent || "");
const labelNorm = normalizeForExactCompare(raw);

const matched = keysNorm.some(k => k && labelNorm === k);
if (matched) {
opt.style.backgroundColor = HIGHLIGHT_BG;
opt.style.color = HIGHLIGHT_COLOR;
opt.style.fontWeight = "700";
} else {
opt.style.backgroundColor = "";
opt.style.color = "";
opt.style.fontWeight = "";
}
}
});
}

// 라디오 버튼 과다 칠해 방지: 버튼 자체 스타일링/마커 부여 금지(텍스트만 래핑)
function highlightRadioButtonsByAttributesInScope(scopeRoot, sortedOptions) {
if (!scopeRoot.querySelectorAll) return;

// 브랜드스토어(W1uViPpPDJ) + 스마트스토어(XCOrxJzfAt, WrWW4M9Uiw) + 속성 fallback
const radioGroups = [
...scopeRoot.querySelectorAll('div.XCOrxJzfAt[role="radiogroup"]'),
...scopeRoot.querySelectorAll('div.WrWW4M9Uiw[role="radiogroup"]'),
...scopeRoot.querySelectorAll('div.W1uViPpPDJ[role="radiogroup"]'),
...scopeRoot.querySelectorAll('div[role="radiogroup"][data-shp-contents-type="색상"]'),
...scopeRoot.querySelectorAll('div[role="radiogroup"][data-shp-contents-type="사이즈"]'),
];

radioGroups.forEach(group => {
const btns = group.querySelectorAll('button[role="radio"]');

btns.forEach(btn => {
// 1) 기존에 버튼 자체에 남아 있을 수 있는 스타일/마커 제거
btn.style.backgroundColor = "";
btn.style.color = "";
btn.style.fontWeight = "";
btn.style.outline = "";
if (btn.getAttribute(EXT_MARK_ATTR) === "1") btn.removeAttribute(EXT_MARK_ATTR);
});
});
}

// 허용루트가 0개일 때는 전부 언랩하지 않도록 완화(스코프 DOM 아직 못 찾았을 수 있음)
function clearHighlightsOutsideAllowed(allowedRoots) {
const allNodes = document.querySelectorAll(`[${EXT_MARK_ATTR}]`);
if (!allowedRoots || allowedRoots.length === 0) {
// 과거: 모두 언랩 → 현재: 아무 것도 하지 않음(투명 CSS 상태에서 다음 틱 대기)
return;
}
const isAllowed = (el) => allowedRoots.some(r => r.contains(el));
let dirty = true;
while (dirty) {
dirty = false;
const nodes = document.querySelectorAll(`[${EXT_MARK_ATTR}]`);
for (const n of nodes) {
if (!isAllowed(n)) {
if (n.tagName === "SPAN") {
unwrapNode(n); // 텍스트 래퍼만 언랩
} else {
clearAoMark(n); // 버튼/기타 네이티브는 마커/스타일만 제거
}
dirty = true;
break;
}
}
}
}


// ── 실행 스케줄/메인 ────────────────────────────────────────
let scheduled = null;
let running = false;
function scheduleHighlight() {
if (scheduled) return;
scheduled = setTimeout(() => { scheduled = null; runHighlight(); }, SCHEDULE_MS);
}


function runHighlight() {
if (running) return;
running = true;

// 블랙리스트 URL에서는 컬러링 전체 비활성
if (aoIsBlacklisted(location.href)) { running = false; return; }

chrome.storage.local.get(["__ext_option_enabled", OPTION_KEY], res => {
// ✅ 토글 꺼져있으면 즉시 종료
if (res.__ext_option_enabled !== true) {
unwrapAllHighlights(document);
running = false;
return;
}

try {
const list = (res && Array.isArray(res[OPTION_KEY])) ? res[OPTION_KEY] : [];

// 옵션 배열만 보고 판단
if (!list.length) {
unwrapAllHighlights(document);
return;
}

const { sorted: sortedOptions, regex: optionsRe } = buildOptionsRegex(list);

if (isScopedHost()) {
const allowedRoots = SITE_SCOPES.getActiveAllowedRoots();

// 허용 루트가 아직 못 잡혔으면, 전역 언랩은 하지 않고 다음 틱 대기
if (!allowedRoots || allowedRoots.length === 0) {
return;
}

clearHighlightsOutsideAllowed(allowedRoots);
for (const root of allowedRoots) {
traverseRootWithShadow(root, (r) => {
highlightTextNodesInScope(r, optionsRe);
highlightNativeSelectsInScope(r, sortedOptions);
highlightRadioButtonsByAttributesInScope(r, sortedOptions);
});
pruneObsoleteHighlightsInScope(root, optionsRe);
}
return;
}

// 비-스코프 사이트: 전역 적용 → 오매치 정리
traverseRootWithShadow(document, (root) => {
highlightTextNodesInScope(root, optionsRe);
highlightNativeSelectsInScope(root, sortedOptions);
highlightRadioButtonsByAttributesInScope(root, sortedOptions);
});
pruneObsoleteHighlightsInScope(document, optionsRe);

} finally {
running = false;
}
});
}

// 최초 1회
runHighlight();

// DOM 변화 대응 (배너 변화 무시 + 스로틀)
let raf2 = null;
const mo2 = new MutationObserver((mutations) => {
const banner = document.querySelector(`[${BANNER_ATTR}="1"]`);
const bannerOnly = banner && mutations.length > 0 && mutations.every(m => {
if (m.type !== "childList") return true;
const allNodes = [
...Array.from(m.addedNodes || []),
...Array.from(m.removedNodes || [])
].filter(n => n && n.nodeType === 1);
if (allNodes.length === 0) return true;
return allNodes.every(n => n === banner || (n.closest && n.closest(`[${BANNER_ATTR}="1"]`)));
});
if (bannerOnly) return;
if (raf2) cancelAnimationFrame(raf2);
raf2 = requestAnimationFrame(scheduleHighlight);
});

if (document.body) {
mo2.observe(document.body, {
childList: true, subtree: true, characterData: location.host !== "price.coupang.com"
});
} else {
new MutationObserver((_, obs) => {
if (document.body) {
mo2.observe(document.body, { childList: true, subtree: true, characterData: true });
obs.disconnect();
}
}).observe(document.documentElement || document, { childList: true, subtree: true });
}

// storage 변경: 옵션/하트비트 갱신 시 바로 재평가. 옵션이 비면 즉시 언랩.
if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.onChanged) {
chrome.storage.onChanged.addListener((changes, areaName) => {
if (areaName !== "local") return;

if (changes[OPTION_KEY]) {
const v = changes[OPTION_KEY].newValue;
if (!Array.isArray(v) || v.length === 0) {
unwrapAllHighlights(document); // 옵션이 비면 즉시 제거
return;
}
scheduleHighlight(); // 옵션이 있으면 재하이라이트
}
// HEARTBEAT_KEY 관련 분기 전체 삭제
});
}

// ✅ 옵션 토글 메시지 처리
chrome.runtime.onMessage.addListener((msg) => {
if (msg?.action === "option_refresh") {
scheduleHighlight();
}
});

log("Loaded at", host, path, { scoped: isScopedHost() });
})();
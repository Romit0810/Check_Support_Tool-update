/*************************************************
* Coupang Price Admin Helper - content-ce.js
* 목적: 어드민에서 추출된 KAN(=카테고리)을 스토리지에서 받아
* CSV 매핑 후 카테고리별 토스트(kanid, Product, brand, 필수속성) 표시
* 특징:
* - DOM에서 KAN을 다시 찾지 않음 (기존 content.js가 저장하는 __ext_last_kan 사용)
* - __ext_admin_error(오류)일 때는 토스트 숨김
* - 해시 변경/스토리지 변경 시 자동 갱신
*************************************************/

console.log("[KAN CE] injected:", location.href, "hash:", location.hash);

// ================================
// 상수/상태
// ================================
const DEBUG = true;

// 토글/접힘 상태 키
const TOGGLE_KEY = "__ext_ce_required_enabled";
const COLLAPSE_KEY = "__ext_ce_collapsed"; // 접힘 상태 저장

// 기타 상수
const KAN_REGEX = /^[0-9]{3,4}$/; // 3~4자리
const SHOW_IF_NOT_IN_CSV = false; // CSV에 없을 때도 토스트 표시 여부

// 전역 상태
const STATE = {
enabled: false, // 토글 기본 OFF
csvLoaded: false,
lastKanId: null,
toastEl: null,
collapsed: false
};

// KAN 매핑 저장소
let KAN_MAP = {}; // kanId -> { Product, brand, requiredItems[] }

// 내부 UI 조작 시 MutationObserver 무시 플래그
let DOM_MUTATION_MUTE = false;

// ================================
// 유틸
// ================================
const norm = (s) => (s || "").toLowerCase().replace(/\s+/g, "");
function normalizeKanId(v) {
return (v || "")
.replace(/\uFEFF/g, "")
.replace(/[^\d]/g, "")
.trim();
}
function splitItems(text) {
if (!text) return [];
return text.split(/\r?\n/g).map(t => t.trim()).filter(Boolean);
}

// ================================
// 페이지 판별
// ================================
function isAdminMatchingPage() {
const h = location.hash || "";
return /#\/matching(\/\d+)?/.test(h); // "#/matching" 또는 "#/matching/숫자"
}

// ================================
// 스토리지 헬퍼 (토글/접힘)
// ================================
async function loadToggleState() {
try {
// local 우선
const localGot = await chrome.storage.local.get(TOGGLE_KEY);
if (typeof localGot[TOGGLE_KEY] === "boolean") {
return !!localGot[TOGGLE_KEY];
}
// local에 없으면 sync에서 가져와서 local로 마이그레이션
const syncGot = await chrome.storage.sync.get(TOGGLE_KEY);
if (typeof syncGot[TOGGLE_KEY] === "boolean") {
const val = !!syncGot[TOGGLE_KEY];
await chrome.storage.local.set({ [TOGGLE_KEY]: val });
return val;
}
} catch (e) {
console.warn("[KAN CE] loadToggleState err:", e);
}
return false; // 기본 OFF
}

async function saveToggleState(enabled) {
try {
await chrome.storage.local.set({ [TOGGLE_KEY]: !!enabled });
} catch (e) {
console.warn("[KAN CE] saveToggleState err:", e);
}
}

async function loadCollapsedState() {
try {
const got = await chrome.storage.local.get(COLLAPSE_KEY);
if (typeof got[COLLAPSE_KEY] === "boolean") return !!got[COLLAPSE_KEY];
} catch {}
return false;
}
async function saveCollapsedState(collapsed) {
try {
await chrome.storage.local.set({ [COLLAPSE_KEY]: !!collapsed });
} catch {}
}

// ================================
// CSV 로드
// ================================
async function loadKanCsv() {
try {
const url = chrome.runtime.getURL("kanid_information.csv");
if (DEBUG) console.log("[KAN CE] CSV URL:", url);

const res = await fetch(url);
const text = await res.text();

KAN_MAP = parseCSVToMap(text);
STATE.csvLoaded = true;

console.log("[KAN CE] CSV loaded. mapSize=", Object.keys(KAN_MAP).length);
} catch (e) {
console.error("[KAN CE] CSV load error:", e);
KAN_MAP = {};
STATE.csvLoaded = false;
}
}

// ================================
// CSV 파싱 (콤마 + 따옴표 멀티라인 지원)
// ================================
function parseCSVWithQuotes(text) {
const rows = [];
let row = [];
let field = "";
let inQuotes = false;

const pushField = () => { row.push(field); field = ""; };
const pushRow = () => {
if (row.length && row.some(c => (c || "").trim() !== "")) rows.push(row);
row = [];
};

for (let i = 0; i < text.length; i++) {
const ch = text[i];
const next = text[i + 1];

if (ch === '"') {
if (inQuotes && next === '"') { field += '"'; i++; }
else { inQuotes = !inQuotes; }
continue;
}

if (ch === "," && !inQuotes) { pushField(); continue; }

if ((ch === "\n" || ch === "\r") && !inQuotes) {
if (ch === "\r" && next === "\n") i++;
pushField(); pushRow(); continue;
}

field += ch;
}

pushField(); pushRow();
return rows;
}

function findHeaderIndex(headerArr, candidates) {
const normHeader = headerArr.map(h => norm(h));
for (const c of candidates) {
const target = norm(c);

let i = normHeader.findIndex(h => h === target);
if (i >= 0) return i;

i = normHeader.findIndex(h => h.includes(target));
if (i >= 0) return i;
}
return -1;
}

function parseCSVToMap(csvText) {
const rows = parseCSVWithQuotes(csvText);
if (rows.length < 2) return {};

const header = rows[0].map(h => (h || "").trim());
const idx = {
kanId: findHeaderIndex(header, ["kan id", "kanid", "kan_id"]),
Product: findHeaderIndex(header, ["kan 4", "product"]),
brand: findHeaderIndex(header, ["brand"]),
required:findHeaderIndex(header, ["필수속성", "required"])
};

if (idx.kanId < 0) {
console.warn("[KAN CE] 'kan id' 컬럼을 찾지 못했습니다. header:", header);
return {};
}

const map = {};
for (let i = 1; i < rows.length; i++) {
const cols = rows[i];

const kanId = normalizeKanId(cols[idx.kanId]);
if (!kanId) continue;

const Product = idx.Product >= 0 ? (cols[idx.Product] || "").trim() : "";
const brand = idx.brand >= 0 ? (cols[idx.brand] || "").trim() : "";
const requiredRaw = idx.required >= 0 ? (cols[idx.required] || "").trim() : "";

map[kanId] = {
Product,
brand,
requiredItems: splitItems(requiredRaw)
};
}
return map;
}

// ================================
// 토스트 UI
// ================================
function ensureToast() {
if (STATE.toastEl) return STATE.toastEl;

const el = document.createElement("div");
el.id = "kan-helper-toast";

el.style.position = "fixed";
el.style.right = "16px";
el.style.bottom = "16px";
el.style.zIndex = "999999";
el.style.width = "360px";
el.style.background = "rgba(40,40,40,0.92)";
el.style.color = "#fff";
el.style.padding = "15px";
el.style.borderRadius = "10px";
el.style.boxShadow = "0 8px 20px rgba(0,0,0,0.35)";

el.innerHTML = `
<div style="display:flex; align-items:center; justify-content:space-between;">
<div style="font-weight:800;font-size:14px;">KANID Helper</div>
<div style="display:flex; gap:8px; align-items:center;">
<button id="kan-toggle"
style="width:30px;height:30px;border-radius:8px;border:1px solid rgba(255,255,255,0.18);
background:rgba(255,255,255,0.08);color:#fff;cursor:pointer;">▾</button>
<button id="kan-close"
style="width:30px;height:30px;border-radius:8px;border:1px solid rgba(255,255,255,0.18);
background:rgba(255,255,255,0.08);color:#fff;cursor:pointer;">✕</button>
</div>
</div>

<div style="margin-top:12px; display:grid; grid-template-columns: 1fr 1fr; gap:12px;">
<div>
<div style="opacity:0.7;font-size:12px;">KANID</div>
<div id="t-kanid" style="font-weight:900;font-size:16px;margin-top:2px;"></div>
</div>
<div>
<div style="opacity:0.7;font-size:12px;">Product</div>
<div id="t-Product" style="font-weight:800;font-size:14px;margin-top:4px;"></div>
</div>
</div>

<div id="kan-collapsible">
<div style="margin-top:10px;">
<div style="opacity:0.7;font-size:12px;">BRAND</div>
<div id="t-brand" style="margin-top:2px;"></div>
</div>

<div style="margin-top:10px;opacity:0.7;font-size:12px;">필수속성</div>
<ul id="t-required" style="margin:6px 0 0;padding-left:16px;line-height:1.5;list-style:disc;"></ul>
</div>
`;

document.body.appendChild(el);

// 닫기
el.querySelector("#kan-close").addEventListener("click", () => {
el.remove();
STATE.toastEl = null;
});

// 접기/펼치기
const toggleBtn = el.querySelector("#kan-toggle");
const collapsible = el.querySelector("#kan-collapsible");

function applyCollapsedUI() {
const collapsed = STATE.collapsed;
collapsible.style.display = collapsed ? "none" : "block";
toggleBtn.textContent = collapsed ? "▸" : "▾";
}

toggleBtn.addEventListener("click", async () => {
// 내부 UI 조작으로 인한 DOM 변화는 Observer에서 무시
DOM_MUTATION_MUTE = true;
try {
STATE.collapsed = !STATE.collapsed;
applyCollapsedUI();
await saveCollapsedState(STATE.collapsed);
} finally {
setTimeout(() => { DOM_MUTATION_MUTE = false; }, 50);
}
});

applyCollapsedUI();
STATE.toastEl = el;
return el;
}

function removeToast() {
const el = STATE.toastEl;
if (el && el.parentNode) el.parentNode.removeChild(el);
STATE.toastEl = null;
}

function showToastForKan(kanId) {
const toast = ensureToast();
const data = KAN_MAP[kanId];

// 상단 정보
toast.querySelector("#t-kanid").textContent = kanId;
toast.querySelector("#t-Product").textContent = data?.Product || "-";
toast.querySelector("#t-brand").textContent = data?.brand || "-";

// 필수속성 리스트
const ul = toast.querySelector("#t-required");
ul.innerHTML = ""; // 항상 초기화

const items = (data?.requiredItems && data.requiredItems.length > 0)
? data.requiredItems
: ["필수속성 없음 / 카테고리 가이드 참고"];

for (const t of items) {
const li = document.createElement("li");
li.textContent = t;
ul.appendChild(li);
}
}

// ================================
// 평가/렌더 (스토리지 기반)
// ================================
async function reevaluate(reason = "") {
try {
if (!STATE.enabled) {
if (DEBUG) console.log("[KAN CE][BLOCK] enabled=false", reason);
removeToast();
return;
}
if (!STATE.csvLoaded) {
if (DEBUG) console.log("[KAN CE][BLOCK] csvLoaded=false", reason);
removeToast();
return;
}
if (!isAdminMatchingPage()) {
if (DEBUG) console.log("[KAN CE][BLOCK] not matching page", reason, "hash=", location.hash);
removeToast();
return;
}

const got = await chrome.storage.local.get(["__ext_last_kan", "__ext_admin_error"]);
const error = !!got.__ext_admin_error;
const kan = String(got.__ext_last_kan || "").trim();

if (error) {
if (DEBUG) console.log("[KAN CE][BLOCK] __ext_admin_error=true", reason);
removeToast();
return;
}

if (!kan || !KAN_REGEX.test(kan)) {
if (DEBUG) console.log("[KAN CE][BLOCK] invalid/missing KAN:", kan, reason);
removeToast();
return;
}

// CSV에 없는데 보여주지 않을 옵션이면 무시
if (!KAN_MAP[kan] && !SHOW_IF_NOT_IN_CSV) {
if (DEBUG) console.log("[KAN CE][BLOCK] KAN not found in CSV:", kan, reason);
removeToast();
return;
}

if (kan !== STATE.lastKanId) {
STATE.lastKanId = kan;
if (DEBUG) console.log("[KAN CE][PASS] showToast for", kan, reason);
showToastForKan(kan);
}
} catch (e) {
console.error("[KAN CE] reevaluate error:", e);
}
}

// ================================
// 옵저버 & 스토리지 구독
// ================================
function startObserver() {
if (DEBUG) console.log("[KAN CE] startObserver()");

// DOM 변화시(탭 전환/리렌더 등) 디바운스 평가
const obs = new MutationObserver(() => {
if (DOM_MUTATION_MUTE) return; // 내부 UI 변경은 무시
window.clearTimeout(startObserver._t);
startObserver._t = window.setTimeout(() => reevaluate("mutation"), 150);
});
obs.observe(document.documentElement, {
childList: true, subtree: true, characterData: true, attributes: true
});

// 해시 변경 (페이지 라우팅)
window.addEventListener("hashchange", () => {
STATE.lastKanId = null;
reevaluate("hashchange");
});

// 스토리지 변경 (local + sync 모두 처리)
chrome.storage.onChanged.addListener((changes, area) => {
if (area === "local") {
if ("__ext_last_kan" in changes) {
if (DEBUG) console.log("[KAN CE] __ext_last_kan changed:", changes.__ext_last_kan.newValue);
STATE.lastKanId = null;
reevaluate("storage:kan");
}
if ("__ext_admin_error" in changes) {
if (DEBUG) console.log("[KAN CE] __ext_admin_error changed:", changes.__ext_admin_error.newValue);
STATE.lastKanId = null;
reevaluate("storage:error");
}

// ✅ 토글(local) 변경
if (TOGGLE_KEY in changes) {
STATE.enabled = !!changes[TOGGLE_KEY].newValue;
if (DEBUG) console.log("[KAN CE] CE toggle changed (local):", STATE.enabled);
STATE.lastKanId = null;
if (!STATE.enabled) {
removeToast();
} else {
reevaluate("local:ce-toggle");
}
}

// ✅ 접힘 상태 변경
if (COLLAPSE_KEY in changes) {
STATE.collapsed = !!changes[COLLAPSE_KEY].newValue;
if (STATE.toastEl) {
const collapsible = STATE.toastEl.querySelector("#kan-collapsible");
const toggleBtn = STATE.toastEl.querySelector("#kan-toggle");
if (collapsible && toggleBtn) {
collapsible.style.display = STATE.collapsed ? "none" : "block";
toggleBtn.textContent = STATE.collapsed ? "▸" : "▾";
}
}
}
}

// ✅ 호환성: 누군가 sync에만 쓰는 경우 → local로 즉시 미러링 (단일 소스 유지)
if (area === "sync" && TOGGLE_KEY in changes) {
const enabled = !!changes[TOGGLE_KEY].newValue;
chrome.storage.local.set({ [TOGGLE_KEY]: enabled }).catch(() => {});
// local onChanged가 이어서 트리거되므로 여기서 추가 처리 금지
}
});

// 1초 폴링(혹시 변경 누락 대비)
setInterval(() => reevaluate("poll"), 1000);

// 최초 1회
reevaluate("init");
}

// ================================
// init
// ================================
(async () => {
try {
if (DEBUG) console.log("[KAN CE] init start");

await loadKanCsv();

// ✅ 토글/접힘 상태: local 우선 로드 (sync에만 있으면 local로 마이그레이션)
STATE.enabled = await loadToggleState();
STATE.collapsed = await loadCollapsedState();

if (DEBUG) console.log(
"[KAN CE] enabled:", STATE.enabled,
"csvLoaded:", STATE.csvLoaded,
"collapsed:", STATE.collapsed
);

startObserver();
} catch (e) {
console.error("[KAN CE] init crashed:", e);
}
})();

// 선택: 팝업에서 보낸 즉시 재평가 신호
chrome.runtime.onMessage.addListener((msg) => {
if (msg && msg.action === "ce_reevaluate") {
STATE.lastKanId = null;
reevaluate("msg:ce_reevaluate");
}
});
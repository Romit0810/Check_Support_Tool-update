// ============================================================
// model-name.js
// 어드민의 모델명 -> 외부사이트에 컬러링 (겹침 구간 Range 스왑 포함)
// ============================================================

(function () {
"use strict";

/* ============================================================
* 0. 스타일
* ============================================================ */
const TEXT_MARK_CLASS = "__ext-model-mark";
const TEXT_MARK_MISMATCH_CLASS = "__ext-model-mark-mismatch";
const STYLE_ID = "__ext-model-style";
const COLOR_HIT = "#ffb039"; // 모델 일치 주황
const COLOR_MISMATCH = "#ff7b39ff"; // 허용 불일치 주황(진함)
const STORAGE_KEY_MODELS = "__ext_model_names_norm";

// 겹침 효과 모드: 'stable' | 'blink'
// - 'stable' : 깜빡임 없이 모델(주황) 우선, 옵션(초록)은 겹치지 않는 구간 유지
// - 'blink' : 겹치는 문자 구간만 색상 스왑 애니메이션
const OVERLAP_EFFECT_MODE = 'stable';

if (!document.getElementById(STYLE_ID)) {
const style = document.createElement("style");
style.id = STYLE_ID;
style.textContent = `
.${TEXT_MARK_CLASS}{
background:${COLOR_HIT} !important;
pointer-events:none !important;
}
.${TEXT_MARK_MISMATCH_CLASS}{
background:${COLOR_MISMATCH} !important;
pointer-events:none !important;
}

/* ⭐⭐ 겹치는 '문자 구간' 전용 색상 스왑(옵션↔모델) - 천천히(2초) */
.__ext-overlap-swap{
animation: __ext-swap-colors 2s ease-in-out infinite !important;
will-change: background-color;
}
@keyframes __ext-swap-colors{
0%,49.9% { background:#b9ff74 !important; } /* 옵션 초록 */
50%,100% { background:#ffb039 !important; } /* 모델 주황 */
}
`;
(document.head || document.documentElement).appendChild(style);
}

function unpaintAll() {
const all = document.querySelectorAll(`.${TEXT_MARK_CLASS}, .${TEXT_MARK_MISMATCH_CLASS}`);
for (const span of all) {
const parent = span.parentNode;
if (!parent) continue;
const text = document.createTextNode(span.textContent || "");
parent.replaceChild(text, span);
if (typeof parent.normalize === "function") parent.normalize();
}
}

/* ============================================================
* 1. 설정 - 블랙리스트 및 불일치 허용 리스트
* ============================================================ */
const BLACKLIST_SITES = [
"https://shopping.naver.com/popup/seller-info",
"http://price.coupang.com",
"https://price.coupang.com",
"file://",
"https://docs.google.com/",
"https://coupang.service-now.com/",
"https://coupangnam-my.sharepoint.com/",
"https://catalog-tools.coupang.net/quality/vendoritem/",
"https://wiki.coupang.net/",
"https://news.coupang.com/",
"https://coupang.okta.com/",
"https://m365.cloud.microsoft/",
"https://rcc.coupang.net/",
"https://wd3.myworkday.com/",
"https://copilot.cloud.microsoft/",
"https://promotion.coupang.net/",
"https://www.google.com/",
"https://coupang.sharepoint.com/",
"https://outlook.office.com/",
"https://auth.coupangcorp.net/",
"https://gemini.google.com/",
"https://www.naver.com/",
"https://coupangnam.sharepoint.com/",
"https://drive.google.com/",
"https://coupang.metapay.co.kr/",
"https://papago.naver.com/",
"https://www.coupang.com/",
"https://search.naver.com/"
];

const MISMATCH_ALLOWED_CHARS =
["CY", "W", "I", "B", "Y", "P", "M", "C", "G", "N", "Q", "R",
"BK", "BLACK", "WH", "RD", "BL", "BL",
"GREEN", "GR", "GRY", "SL", "SV",
"GD", "GD", "PK", "OR", "ORANGE", "PP", "PURPLE",
"BR", "BROWN", "BG", "BE", "NV", "NAVY", "IV", "IVORY",
"CH", "CR", "KH", "MR", "OL"];

// 실행 제외 KANID
const KANID_BLOCKLIST = new Set([
//Electronics
"9130",
//Computer & Digital
"9047", "8893", "5341", "5340", "8732", "9117", "9051", "2266", "2480", "2276", "2476", "2267", "2477", "2478", "5329", "2273", "2274", "5330", "2275", "9053", "2479", "5328", "2272", "5332", "9055", "9058", "5336", "5335", "4221", "8642", "9071", "8816", "5752", "8640", "8641", "8598", "5477", "5342", "2296", "8078", "8649", "8639", "9120", "8966", "8967", "8971", "8975", "5311", "7377", "2289", "5305", "5304", "5302", "2251", "5268", "5270", "5269", "5267", "5271", "8993", "5290", "5274", "5272", "8996", "5279", "2249", "5273", "2250", "8998", "8999", "5247"
]);

/* ============================================================
* 2. 유틸
* ============================================================ */
const normalizeModel = (s) => {
if (!s) return "";
return s.replace(/[^0-9A-Za-z\-\s]/g, "").replace(/\s+/g, " ").toUpperCase();
};
const normalizeForMatching = (s) => {
if (!s) return "";
return s.replace(/[^0-9A-Za-z]/g, "").toUpperCase();
};
const isAdminPage = () => location.host.includes("price.coupang.com");
const isBlacklistedSite = () => {
const currentUrl = location.href;
return BLACKLIST_SITES.some(site => currentUrl.startsWith(site));
};

function isStopwordLike(norm) {
if (!norm) return false;
const exact = new Set([
"WIFI", "WIFI6", "WIFI6E", "WIFI7",
"WIN11", "WIN10", "WINDOWS11", "WINDOWS10",
"HOME", "PRO", "EDU",
"LTE", "5G", "4G", "BLUETOOTH", "BT", "CELLULAR",
"CM", "MM", "INCH", "IN",
"GB", "TB", "MB",
"HZ", "KHZ", "MHZ", "GHZ",
"W", "WH",
"HDR", "HDR10", "HDR10PLUS", "IPS", "VA", "OLED", "QLED",
"APPLE", "PS4", "L", "ML", "LITER", "LITRE"
]);
if (exact.has(norm)) return true;
if (/^WIN(10|11)(HOME|PRO|EDU)?$/.test(norm)) return true;
if (/^WINDOWS(10|11)(HOME|PRO|EDU)?$/.test(norm)) return true;
if (/^APPLE(19|20)\d{2}$/.test(norm)) return true;
if (/^\d+(GB|TB|MB|HZ|KHZ|MHZ|GHZ|W|WH|CM|MM|IN|L|ML)$/.test(norm)) return true;
if (/^\d+K$/.test(norm)) return true;
if (/^\d{3,4}P$/.test(norm)) return true;
if (/^\d+X\d+$/.test(norm)) return true;
if (norm === "IN1" || /^\d+IN1$/.test(norm)) return true;
return false;
}

function isDimensionLikeText(raw) {
if (!raw) return false;
const s = raw.trim();
if (/^[xX×]\s*\d+(\.\d+)?\s*(CM|MM|IN|INCH|M)?$/i.test(s)) return true;
if (/^\d+(\.\d+)?\s*[xX×]\s*\d+(\.\d+)?\s*(CM|MM|IN|INCH|M)?$/i.test(s)) return true;
return false;
}

function splitAllowedSuffix(modelNorm) {
const allowed = MISMATCH_ALLOWED_CHARS.map(c => c.toUpperCase())
.sort((a, b) => b.length - a.length);
for (const suf of allowed) {
if (modelNorm.endsWith(suf)) {
return { base: modelNorm.slice(0, -suf.length), suffix: suf, allowed };
}
}
return { base: modelNorm, suffix: "", allowed };
}

function hasSafeLeftBoundary(text, startIdx) {
if (startIdx <= 0) return true;
const prevChar = text[startIdx - 1] || "";
return !(/[A-Za-z0-9]/.test(prevChar));
}

function createTextWalker(rootEl, { blockInside = [], maxLen = 600 } = {}) {
return document.createTreeWalker(
rootEl,
NodeFilter.SHOW_TEXT,
{
acceptNode(node) {
const p = node.parentElement;
if (!p) return NodeFilter.FILTER_REJECT;
for (const sel of blockInside) {
if (p.closest(sel)) return NodeFilter.FILTER_REJECT;
}
const v = node.nodeValue || "";
if (!v || v.length > maxLen) return NodeFilter.FILTER_REJECT;
return NodeFilter.FILTER_ACCEPT;
}
}
);
}

/* ============================================================
* 3. 모델명 판별
* ============================================================ */
function isLikelyModelToken(raw) {
if (!raw) return false;
const text = raw.trim();
if (!text) return false;

let check = text.split("(")[0].split("+")[0].trim();
if (!check) return false;

check = check.replace(/[‐-‒–—−]/g, "-");
if (/[가-힣]/.test(check)) return false;
if (!/^[0-9A-Za-z\-\/._ ]+$/.test(check)) return false;

const normNoSymbol = normalizeForMatching(check);
if (normNoSymbol.length < 3 || normNoSymbol.length > 30) return false;
if (isStopwordLike(normNoSymbol)) return false;

if (/^[A-Za-z]\d{1,3}\s+[A-Za-z0-9]{2,}(?:[-\/._·‐‑–—−])[A-Za-z0-9]{2,}$/.test(check)) {
return true;
}

if (/\s/.test(check)) {
const parts = check.split(/\s+/).filter(Boolean);
const subtokenOK = parts.some(p => {
const pNorm = normalizeForMatching(p);
if (!pNorm) return false;
if (isStopwordLike(pNorm)) return false;
const pHasLetter = /[A-Za-z]/.test(pNorm);
const pHasDigit = /\d/.test(pNorm);
const pHasSymbol = /[-\/._]/.test(p);
return (pHasLetter && pHasDigit) || pHasSymbol;
});
if (!subtokenOK) return false;
}

const hasLetter = /[A-Za-z]/.test(normNoSymbol);
const hasDigit = /\d/.test(normNoSymbol);
const hasHyphenOrSlashOrUnder = /[-\/_]/.test(check);

if (hasLetter && hasDigit) {
// ok
} else if (hasHyphenOrSlashOrUnder && normNoSymbol.length >= 6) {
// ok
} else if (/^[A-Za-z]{10,}$/.test(normNoSymbol)) {
// ok
} else {
return false;
}

if (/^\d+(GB|TB|MB|HZ|KHZ|MHZ|GHZ|W|WH|CM|G)$/i.test(normNoSymbol)) return false;
return true;
}

/* ============================================================
* 4. Admin 모델명 추출 (요약)
* ============================================================ */
function getAdminHeaderEl() {
return document.querySelector("div.Heading3[data-elm-id='Name__CoupangItem']");
}
function getAdminAlertItems() {
return document.querySelectorAll('li[data-elm-id="Alert__OperationNotification__item"]');
}
function getKanIdFromAdmin() {
try {
const labelSpans = Array.from(document.querySelectorAll('[data-elm-id="text"] span, [data-elm-id="text"]'));
for (const label of labelSpans) {
const t = (label.textContent || "").trim().toUpperCase();
if (t === "KAN ID") {
const container = label.closest("div");
const valueDiv = container && container.nextElementSibling ? container.nextElementSibling : null;
const raw = valueDiv ? (valueDiv.textContent || "") : "";
const m = raw.match(/\d+/);
if (m && m[0]) return m[0];
}
}
} catch (_) { }
return null;
}

function extractModelsFromAlert() {
const out = new Set();
const items = getAdminAlertItems();

items.forEach(li => {
const clone = li.cloneNode(true);
clone.querySelectorAll(`.${TEXT_MARK_CLASS}, .${TEXT_MARK_MISMATCH_CLASS}`)
.forEach(el => el.replaceWith(document.createTextNode(el.textContent || "")));
const txt = clone.textContent || "";
const lower = txt.toLowerCase();
if (!lower.includes("[model name]")) return;

const startMarker = "[model name]_";
const endMarker = "_대응가능]_[ca]";
let startIdx = lower.indexOf(startMarker);
if (startIdx === -1) startIdx = lower.indexOf("[model name]");
if (startIdx === -1) return;

let searchFrom = startIdx;
while (true) {
const endIdx = lower.indexOf(endMarker, searchFrom);
if (endIdx === -1) break;

const segment = txt.slice(startIdx, endIdx);
const segLower = segment.toLowerCase();
const blkEnd = segLower.lastIndexOf("_대응가능]");
if (blkEnd !== -1) {
const openIdx = segment.lastIndexOf("[", blkEnd);
if (openIdx !== -1) {
let modelBlock = segment.slice(openIdx + 1, blkEnd);
modelBlock = modelBlock.replace(/\s+/g, " ").trim();

const splitter = /\s*(?:,|\/|에|and|&|to)\s*/i;
const pieces = modelBlock.split(splitter).map(p => p.trim()).filter(Boolean);
pieces.forEach(piece => {
let cleaned = piece.replace(/_?대응가능$/i, "").trim();
cleaned = cleaned.replace(/^\[+|\]+$/g, "").trim();
if (!cleaned) return;
cleaned = cleaned.replace(/\s+/g, " ");
if (isLikelyModelToken(cleaned)) out.add(normalizeModel(cleaned));
});
}
}
searchFrom = endIdx + endMarker.length;
}

if (out.size === 0) {
const candidates = [...(txt.matchAll(/\[([^\]]+)\]/g))].map(m => m[1]);
candidates.forEach(block => {
const blockTrim = (block || "").trim();
const bLower = blockTrim.toLowerCase();
if (!blockTrim) return;
if (bLower.startsWith("pbs-")) return;
if (bLower.startsWith("brand_")) return;
if (bLower.startsWith("group number")) return;
if (bLower === "ca" || bLower === "ce" || bLower === "al") return;

let added = false;
const tokens = blockTrim.match(/[A-Za-z0-9][A-Za-z0-9\-\/._ ]{1,}/g) || [];
tokens.forEach(token => {
const t = token.trim();
if (!t) return;
if (isLikelyModelToken(t)) { out.add(normalizeModel(t)); added = true; }
});

if (!added) {
const phrase = blockTrim.replace(/\s+/g, " ");
if (/^[A-Z0-9 ]{3,}$/.test(phrase) && /[A-Z]/.test(phrase)) {
if (!/^(GROUP NUMBER|BRAND_|PBS|CE|AL)(\b|_)/i.test(phrase)) {
out.add(normalizeModel(phrase));
}
}
}
});
}
});

return [...out];
}

/* ============================================================
* 4. Admin 모델명 추출 (개선: 헤더에서 여러 모델 동시 수집)
* ============================================================ */
function extractAdminModels() {
const models = new Set();
const alertModels = [];
let headerFoundList = [];

// 1) 헤더에서 '모든' 모델 후보를 수집
const headerEl = getAdminHeaderEl();
if (headerEl) {
// [중요] 헤더 엘리먼트 복제 후, 모델과 무관한 부속 엘리먼트를 제거하여 '순수 텍스트'만 추출
const clone = headerEl.cloneNode(true);
clone.querySelectorAll('[data-elm-id="Link__CopyVI"], [data-elm-id="CoupangItem__VendorItemId"]').forEach(el => el.remove());

const headerTextRaw = clone.textContent || "";
const headerText = headerTextRaw.replace(/\s+/g, " ").trim(); // 공백 정리

// "::" 구분자 기준으로 섹션 분리 (각 섹션 별로 모델 후보 탐색)
const sections = headerText.split("::").map(s => s.trim()).filter(Boolean);

// [핵심] 섹션 전체를 훑으며 "모든" 모델 후보를 누적
for (const section of sections) {
if (!section) continue;

// 1) 대괄호/괄호 안쪽에서도 토큰 추출해야 하므로, 전체에서 후보 토큰을 싹 긁어옴
// - 아래 정규식은 '모델형 토큰'이 될 법한 문자열을 넓게 긁어온 뒤, isLikelyModelToken으로 최종 필터링함
const candidates = section.match(/[A-Za-z0-9][A-Za-z0-9\-\/._ ]{1,}/g) || [];

// 2) 각 후보를 정제하고 모델성 판단
for (let cand of candidates) {
if (!cand) continue;

// 괄호 앞부분만 사용 (예: "ABC-123 (블랙)" -> "ABC-123")
cand = (cand.split("(")[0] || "").trim();
// 여분 공백 정리
cand = cand.replace(/\s+/g, " ").trim();
if (!cand) continue;

// 모델 가능성 판단
if (isLikelyModelToken(cand)) {
const fixed = normalizeModel(cand);
headerFoundList.push(fixed);
models.add(fixed); // [중요] '누적'만 하고, 절대 break 하지 않음
}
}
}
}

// 2) Alert(배너)에서도 추가 수집 (기존 로직 유지)
extractModelsFromAlert().forEach(m => { alertModels.push(m); models.add(m); });

// 3) 디버그 로그 (여러 개가 제대로 들어갔는지 확인용)
console.log("✅ model name");
console.log("헤더에서 추출:", headerFoundList.length ? headerFoundList.join(", ") : "(없음)");
console.log("배너에서 추출:", alertModels.length ? alertModels.join(", ") : "(없음)");

// 4) Set -> Array 변환하여 리턴 (중복 제거된 결과)
return [...models];
}

/* ============================================================
* 5. 컬러링 공통
* ============================================================ */
function canAllowMismatch(adminModel, externalText) {
const adminNorm = normalizeForMatching(adminModel);
const externalNorm = normalizeForMatching(externalText);
const { base: adminBase, suffix: adminSuffix, allowed } = splitAllowedSuffix(adminNorm);

// 외부가 최소한 어드민 '기본'과 동일하게 시작해야 함
if (!externalNorm.startsWith(adminBase)) return null;

// 외부 기준으로 어드민 '기본' 뒤쪽 문자열(=접미사 후보) 추출
const externalSuffix = externalNorm.slice(adminBase.length);

// 외부에 접미사가 아예 없으면 불일치 아님
if (!externalSuffix) return null;

// 외부 접미사가 허용 리스트인지 확인 (예: BK, WH, SV, ... )
if (!allowed.includes(externalSuffix)) return null;

// ✅ 변경 포인트:
// - 어드민에 접미사가 없어도(=adminSuffix === "") 외부의 허용 접미사가 있으면 '불일치'로 인정
// - 어드민에 접미사가 있으면, 서로 다를 때만 '불일치'
if (adminSuffix && externalSuffix === adminSuffix) {
// 어드민과 동일한 접미사면 불일치가 아님
return null;
}

// 실제 시각적 분리는 호출부에서 처리하므로, 매칭 성공 신호만 반환
const baseLen = adminBase.length; // 주의: 정규화 길이 기준이지만 호출부에서 직접 prefix/suffix를 다시 계산함
const matchPart = externalText.slice(0, baseLen);
const mismatchPart = externalText.slice(baseLen);
return { matchPart, mismatchPart };
}


function buildLooseRegexAdmin(model) {
const normalized = normalizeForMatching(model);
const core = normalized.split("").map((ch, i) => i === normalized.length - 1 ? `${ch}` : `${ch}[-\\/_\\s]*`).join("");
const rightBoundary = `(?=$|[^A-Za-z0-9])`;
return new RegExp(`${core}${rightBoundary}`, "i");
}

function buildLooseRegexExternal(model) {
const normalized = normalizeForMatching(model);
const core = normalized.split("").map((ch, i) => i === normalized.length - 1 ? `${ch}` : `${ch}[-\\/_\\s]*`).join("");
const rightBoundary = `(?=$|[^A-Za-z0-9])`;
return new RegExp(`${core}${rightBoundary}`, "i");
}

function buildMismatchRegex(model) {
const adminNorm = normalizeForMatching(model);
const { base: adminBase, allowed } = splitAllowedSuffix(adminNorm);
const allowedPattern = allowed.join("|");
const SEP = `[\\-\\/._\\s·‐‑–—−]*`;
return new RegExp(
adminBase.split("").map(ch => ch + SEP).join("") +
`(${allowedPattern})` +
`(?=${SEP}|$)`,
"iu"
);
}

/* ==================== 어드민 컬러링 (테스트용) ==================== */
function highlightInElementAdmin(el, models) {
if (!el || !models.length) return;
const regexes = models.map(buildLooseRegexAdmin);
const walker = createTextWalker(el, { blockInside: [`.${TEXT_MARK_CLASS}`], maxLen: 600 });
const paintedOnce = new Set();

let node;
while ((node = walker.nextNode())) {
for (let i = 0; i < regexes.length; i++) {
const re = regexes[i];
const modelKey = models[i];
if (paintedOnce.has(modelKey)) continue;

const m = re.exec(node.nodeValue);
if (!m) continue;

const startIdx = m.index;
if (!hasSafeLeftBoundary(node.nodeValue, startIdx)) continue;

const full = m[0];
const trimmed = full.replace(/[-\/_\s]+$/, "");
if (!trimmed) continue;

paintedOnce.add(modelKey);

const suffix = full.slice(trimmed.length);
const span = document.createElement("span");
span.className = TEXT_MARK_CLASS;
span.textContent = trimmed;

const before = document.createTextNode(node.nodeValue.slice(0, startIdx));
const suffixNode = document.createTextNode(suffix);
const after = document.createTextNode(node.nodeValue.slice(startIdx + full.length));

const parent = node.parentNode;
parent.insertBefore(before, node);
parent.insertBefore(span, node);
parent.insertBefore(suffixNode, node);
parent.insertBefore(after, node);
parent.removeChild(node);
break;
}
}
}
/* ==================== 어드민 컬러링 끝 (테스트용) ==================== */


/* ============================================================
* 5-β. 외부 컬러링(스냅샷 순회) — 중간 멈춤 방지
* ============================================================ */
function highlightInElementExternal(el, models) {
if (!el || !models.length) return;

const walker = createTextWalker(el, { blockInside: [`.${TEXT_MARK_CLASS}`, `.${TEXT_MARK_MISMATCH_CLASS}`], maxLen: 600 });
// 1) 텍스트 노드 스냅샷 수집(변형 중 건너뛰기 방지)
const nodes = [];
let n; while ((n = walker.nextNode())) nodes.push(n);

const isHighlightWorthy = (text) => {
const norm = normalizeForMatching(text);
if (!norm) return false;
if (isDimensionLikeText(text)) return false;
if (isStopwordLike(norm)) return false;
if (/\d/.test(norm)) return true;
if (/[-\/_]/.test(text) && norm.length >= 6) return true;
if (/^[A-Z]{10,}$/.test(norm)) return true;
return false;
};

// 2) 노드 배열을 돌며 적용
for (const node of nodes) {
if (!node || !node.parentNode) continue;

let applied = false;
for (let i = 0; i < models.length; i++) {
const model = models[i];

// (a) 허용 불일치 먼저
const mmRe = buildMismatchRegex(model);
const mm = mmRe.exec(node.nodeValue);
if (mm) {
if (hasSafeLeftBoundary(node.nodeValue, mm.index)) {
const info = canAllowMismatch(model, mm[0]);
if (info) {
const full = mm[0];
if (isHighlightWorthy(full)) {
const allowed = MISMATCH_ALLOWED_CHARS.map(c => c.toUpperCase()).sort((a, b) => b.length - a.length);
let suffix = "";
for (const a of allowed) {
if (full.toUpperCase().endsWith(a)) { suffix = full.slice(-a.length); break; }
}
const prefix = full.slice(0, full.length - suffix.length);

const before = document.createTextNode(node.nodeValue.slice(0, mm.index));
const matchSpan = document.createElement("span"); matchSpan.className = TEXT_MARK_CLASS; matchSpan.textContent = prefix;
const mismatchSpan = document.createElement("span"); mismatchSpan.className = TEXT_MARK_MISMATCH_CLASS; mismatchSpan.textContent = suffix;
const after = document.createTextNode(node.nodeValue.slice(mm.index + full.length));

const parent = node.parentNode;
parent.insertBefore(before, node);
parent.insertBefore(matchSpan, node);
parent.insertBefore(mismatchSpan, node);
parent.insertBefore(after, node);
parent.removeChild(node);

applied = true;
break;
}
}
}
}

// (b) 일반 매칭
const re = buildLooseRegexExternal(model);
const m = re.exec(node.nodeValue);
if (m) {
const startIdx = m.index;
const prevChar = startIdx > 0 ? node.nodeValue[startIdx - 1] : "";
if (prevChar && /[A-Za-z0-9]/.test(prevChar)) {
continue;
}
const full = m[0];
const trimmed = full.replace(/[-\/_\s]+$/, "");
if (!trimmed) continue;
if (!isHighlightWorthy(trimmed)) continue;

const suffix = full.slice(trimmed.length);

const before = document.createTextNode(node.nodeValue.slice(0, startIdx));
const span = document.createElement("span"); span.className = TEXT_MARK_CLASS; span.textContent = trimmed;
const suffixNode = document.createTextNode(suffix);
const after = document.createTextNode(node.nodeValue.slice(startIdx + full.length));

const parent = node.parentNode;
parent.insertBefore(before, node);
parent.insertBefore(span, node);
parent.insertBefore(suffixNode, node);
parent.insertBefore(after, node);
parent.removeChild(node);

applied = true;
break;
}
}
if (!applied) continue;
}
}

/* ============================================================
* 6. 실행
* ============================================================ */
function runAdmin() {
// ✅ 토글 꺼져있으면 즉시 종료
chrome.storage.local.get(["__ext_model_enabled", "__ext_last_unit"], (res) => {
if (res.__ext_model_enabled !== true) {
unpaintAll();
return;
}

const unit = res.__ext_last_unit;
if (unit !== "Electronics" && unit !== "Computer & Digital") {
chrome.storage.local.set({ [STORAGE_KEY_MODELS]: [] });
unpaintAll(); return;
}

const kanId = getKanIdFromAdmin();
if (kanId && KANID_BLOCKLIST.has(String(kanId))) {
chrome.storage.local.set({ [STORAGE_KEY_MODELS]: [] });
unpaintAll(); return;
}

const models = extractAdminModels();
if (!models.length) {
chrome.storage.local.set({ [STORAGE_KEY_MODELS]: [] });
unpaintAll(); return;
}

chrome.storage.local.set({ [STORAGE_KEY_MODELS]: models });
// 테스트 칠하기
highlightInElementAdmin(getAdminHeaderEl(), models);
document.querySelectorAll('.ant-alert-content').forEach(el => highlightInElementAdmin(el, models));
});
}

function runExternal() {
if (isBlacklistedSite()) { unpaintAll(); return; }

// ✅ 토글 꺼져있으면 즉시 종료
chrome.storage.local.get(["__ext_model_enabled", STORAGE_KEY_MODELS], res => {
if (res.__ext_model_enabled !== true) {
unpaintAll();
return;
}
const models = res[STORAGE_KEY_MODELS] || [];
if (!models.length) { unpaintAll(); return; }

// 1) 모델 먼저 칠하기(스냅샷 방식: 중간 멈춤 방지)
highlightInElementExternal(document.body, models);
});
}

/* ============================================================
* 7. 엔진
* ============================================================ */
const debounced = debounce(() => {
if (isAdminPage()) runAdmin();
else runExternal();
}, 120);

function debounce(fn, wait) {
let t;
return () => {
clearTimeout(t);
t = setTimeout(fn, wait);
};
}

window.addEventListener("hashchange", debounced);
document.addEventListener("DOMContentLoaded", debounced);
new MutationObserver(debounced).observe(document.body, { childList: true, subtree: true });
if (document.readyState !== "loading") debounced();

// ✅ 모델명 토글 메시지 처리
chrome.runtime.onMessage.addListener((msg) => {
if (msg?.action === "model_refresh") {
if (isAdminPage()) runAdmin();
else runExternal();
}
});

log("Loaded at", host, path, { scoped: isScopedHost() });
})();

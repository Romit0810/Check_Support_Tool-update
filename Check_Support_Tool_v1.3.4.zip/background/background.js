// ============================================================
// background.js
// ============================================================


// 서비스워커 로드 및 기본 이벤트
chrome.runtime.onInstalled.addListener(() => {
console.log("[BG] onInstalled");
refreshAdminState(); // 설치 직후 즉시 상태 갱신
wakeAdmin1Tabs(); // 로드시 이미 떠있는 Admin1 탭 깨우기
});

chrome.runtime.onStartup?.addListener(() => {
console.log("[BG] onStartup");
refreshAdminState(); // 브라우저 시작 직후 즉시 상태 갱신
wakeAdmin1Tabs(); // 시작 시에도 Admin1 탭 깨우기
});

// 기본 아이콘이 보이지 않도록, 서비스워커가 살아난 즉시 오류 세팅
(function initErrorBadge() {
chrome.storage.local.set({ __ext_admin_error: true }, () => {
chrome.action.setBadgeText({ text: "!" });
chrome.action.setBadgeBackgroundColor({ color: "#FF4081" });
chrome.action.setBadgeTextColor?.({ color: "#000000ff" });
console.log("[BG] 초기 오류 배지 세팅(기본 아이콘 방지)");
});
})();

// Ping 확인 (popup/content -> 서비스워커 살아있는지 확인)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (msg === "ping") {
console.log("[BG] ping 받음");
sendResponse("pong");
}
});

// 경쟁사 접속버튼
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (msg && msg.action === "open_competitor_link_from_external") {

chrome.tabs.query({ url: ["*://price.coupang.com/*"] }, (tabs) => {
// Admin1('#/matching/숫자') 탭만 대상
const admin1Tabs = (tabs || []).filter(t =>
/#\/matching\/\d+(\b|[/?#])?/i.test(t.url || "")
);

if (admin1Tabs.length === 0) {
sendResponse({ ok: false });
return;
}

chrome.tabs.sendMessage(
admin1Tabs[0].id,
{ action: "open_competitor_link" },
(res) => {
sendResponse(res && res.ok ? { ok: true } : { ok: false });
}
);
});

return true; // 비동기 응답 필수
}
});

// 경쟁사 접속버튼 / 보리보리
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (msg && msg.action === "open_incognito_url" && typeof msg.url === "string") {
try {
chrome.windows.create({ url: msg.url, incognito: true }, (win) => {
if (chrome.runtime.lastError) {
sendResponse({ ok: false });
return;
}
sendResponse({ ok: true, windowId: win && win.id });
});
} catch (_) {
sendResponse({ ok: false });
}
return true; // ★ 비동기 응답
}
});

// Admin 상태 관리 함수 & 이벤트
// Admin 페이지 상태를 확인하고 오류 여부를 관리하는 함수
function refreshAdminState() {
// price.coupang.com 탭 모두 가져오기
chrome.tabs.query({ url: ["*://price.coupang.com/*"] }, (tabs) => {
// 어드민1만 집계, 어드민2 집계 제외
const admin1Tabs = (tabs || []).filter(t => /#\/matching\/\d+(\b|[/?#])?/i.test(t.url || ""));
const admin1Count = admin1Tabs.length;

// 유효 결과(검색된상태)도 Admin1이 1개 이상이면 true
const viidOk = admin1Count > 0;

chrome.storage.local.set({
__ext_admin_tabs: admin1Count, // 'Admin1(매칭/숫자) 탭 수'
__ext_admin_matching_tabs: admin1Count, // 명시적 키(선택) - 유지/활용 가능
__ext_admin_viid_ok: viidOk // Admin1 검색 결과 존재 여부
}, () => {
// 오류 판정: Admin1 없음(0) / 2개 이상 / 결과 없음
let isError = false;
if (admin1Count === 0 || admin1Count > 1 || !viidOk) isError = true;

chrome.storage.local.get("__ext_admin_error", (res) => {
if (res.__ext_admin_error !== isError) {
chrome.storage.local.set({ __ext_admin_error: isError }, () => {
console.log("[BG] __ext_admin_error 강제 갱신:", res.__ext_admin_error, "→", isError);
});
}
});
});

// Admin1 검색된 탭이 없으면 배너 OFF
if (admin1Count === 0 || !viidOk) {
chrome.storage.local.remove(["__ext_last_unit"]);
}
});
}

// 이미 떠있는 Admin1 탭(#/matching/숫자) 깨워서 admin.js 주입 → 추출 트리거
function wakeAdmin1Tabs() {
try {
chrome.tabs.query({ url: ["*://price.coupang.com/*"] }, (tabs) => {
const admin1Tabs = (tabs || []).filter(t =>
/#\/matching\/\d+(\b|[/?#])?/i.test(t.url || "")
);

admin1Tabs.forEach((tab) => {
// 1) 우선 extract 시도 (이미 주입되어 있다면 바로 응답)
chrome.tabs.sendMessage(tab.id, { action: "extract_and_highlight" }, (res) => {
if (chrome.runtime.lastError || !res) {
// 2) 미주입/슬립이면 admin.js를 주입하고 잠깐 대기 후 재요청
try {
chrome.scripting?.executeScript?.(
{ target: { tabId: tab.id }, files: ["content/admin.js"] }, //
() => {
setTimeout(() => {
try {
chrome.tabs.sendMessage(tab.id, { action: "extract_and_highlight" }, () => { });
} catch (e) { }
}, 300); // 주입 직후 SPA가 DOM/데이터 준비될 시간을 더 줌
}
);
} catch (e) {
console.warn("[BG] wakeAdmin1Tabs inject error:", e);
}
}
});
});
});
} catch (e) {
console.warn("[BG] wakeAdmin1Tabs error:", e);
}
}

// 탭 생성/삭제/갱신/활성화 이벤트에서 상태 갱신
chrome.tabs.onCreated.addListener(() => refreshAdminState());
chrome.tabs.onRemoved.addListener(() => refreshAdminState());
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {

// URL이 변경되거나 해시만 바뀌어도 상태 갱신
if ((changeInfo.url && /price\.coupang\.com/.test(changeInfo.url)) ||
(tab && tab.url && /price\.coupang\.com/.test(tab.url))) {
refreshAdminState();
}
});

chrome.tabs.onActivated.addListener(() => refreshAdminState());

// 오류 여부가 변경되면 아이콘 배지로 표시
chrome.storage.onChanged.addListener((changes, area) => {
if (area !== "local") return;
if ("__ext_admin_error" in changes) {
const { newValue } = changes.__ext_admin_error;
console.log("[BG] __ext_admin_error 변경:", newValue ? "오류 발생" : "정상");

// 오류 상태 → 분홍색 !, 정상 → 노란색 O
if (newValue) {
chrome.action.setBadgeText({ text: "!" });
chrome.action.setBadgeBackgroundColor({ color: "#FF4081" });
chrome.action.setBadgeTextColor?.({ color: "#000000ff" });
} else {
chrome.action.setBadgeText({ text: "O" });
chrome.action.setBadgeBackgroundColor({ color: "#FFEB3B" });
chrome.action.setBadgeTextColor?.({ color: "#000000" });
}
}
});

// CSV 업로드 처리 (팝업에서 보낸 파일 저장 및 검증)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (!msg || msg.action !== "upload_blacklist_file") return;
console.log("[BG] CSV 업로드 요청 수신:", msg.filename);

try {
// 파일 내용, 이름, 업로드 시간 저장
chrome.storage.local.set({
__ext_uploaded_csv: msg.csvText,
__ext_uploaded_filename: msg.filename,
__ext_uploaded_timestamp: Date.now(),
}, () => {
console.log("[BG] CSV 저장 완료:", msg.filename);

// 저장 직후 즉시 검증
chrome.storage.local.get(["__ext_uploaded_filename"], (chk) => {
console.log("[BG] 저장 검증:", chk);
});

// 팝업 리셋 방지 응답
setTimeout(() => sendResponse({ ok: true }), 150);
});
} catch (e) {
console.error("[BG] CSV 업로드 오류:", e);
sendResponse({ ok: false });
}
return true; // 비동기 응답 유지
});

// 업로드된 CSV 정보 요청 처리
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (msg && msg.action === "get_uploaded_file_info") {
chrome.storage.local.get(["__ext_uploaded_filename", "__ext_uploaded_csv"], (res) => {
sendResponse(res || {}); // 업로드된 파일 정보 반환
});
return true; // 비동기 응답 유지
}
});

// 서비스워커 suspend / resume 관리
// 서비스워커가 suspend에서 복귀했을 때 캐시 확인
chrome.runtime.onSuspendCanceled?.addListener(() => {
console.log("[BG] Service worker resumed, verifying cached storage…");
chrome.storage.local.get(["__ext_uploaded_filename", "__ext_uploaded_csv"], (res) => {
if (res.__ext_uploaded_filename) {
console.log("[BG] Cached file still present:", res.__ext_uploaded_filename);
} else {
console.warn("[BG] Cached file missing after resume → will restore soon if popup reopens");
}
});
});

// 서비스워커 suspend 시 저장 상태 확인
chrome.runtime.onSuspend?.addListener(() => {
console.log("[BG] onSuspend → 강제 flush");
chrome.storage.local.get(null, (res) => {
console.log("[BG] Suspend 직전 저장된 키 수:", Object.keys(res).length);
});
});

// KeepAlive 연결 유지 (서비스워커 슬립 방지)
let keepAlivePort = null;
chrome.runtime.onConnect.addListener((port) => {
if (port.name === "keepAlive") {
console.log("[BG] KeepAlive 연결됨");
keepAlivePort = port;
port.onDisconnect.addListener(() => {
console.log("[BG] KeepAlive 해제됨");
keepAlivePort = null;
});
}
});

// 자동 업데이트 확인
(async function manualUpdateCheck() {
const UPDATE_URL = "https://raw.githubusercontent.com/Romit0810/Check_Support_Tool-update/main/update.xml";
const CURRENT_VERSION = chrome.runtime.getManifest().version;

try {
const res = await fetch(UPDATE_URL + "?t=" + Date.now(), { cache: "no-store" });
if (!res.ok) { console.warn("[UPDATE] XML 요청 실패:", res.status); return; }

const text = await res.text();
const match = text.match(/<updatecheck[^>]+version=['"]([\d.]+)['"]/i);
if (!match) { console.warn("[UPDATE] XML 내 버전 정보 없음"); return; }

const latestVersion = match[1].trim();
console.log(`[UPDATE] 현재 버전: ${CURRENT_VERSION}, 최신 버전: ${latestVersion}`);

if (compareVersions(latestVersion, CURRENT_VERSION) > 0) {
console.log("%c🎉 새 버전 발견됨", "color: green; font-weight: bold;");
chrome.notifications.create({
type: "basic",
iconUrl: "icons/icon128.png",
title: "Check_Support_Tool 업데이트",
message: `새로운 버전 ${latestVersion}이 확인되었습니다.\n클릭 시 ZIP 다운로드로 이동합니다.`,
priority: 2
});

// 파일 상단 전역
let __updateClickHandlerBound = false;

// manualUpdateCheck 내부 조건문에서 리스너 등록 전에
if (!__updateClickHandlerBound) {
chrome.notifications.onClicked.addListener((notificationId) => {
// notificationId 체크해 특정 알림일 때만 열어도 됨
chrome.tabs.create({
url: `https://raw.githubusercontent.com/Romit0810/Check_Support_Tool-update/main/Check_Support_Tool_v${latestVersion}.zip`
});
});
__updateClickHandlerBound = true;
}

} else {
console.log("%c✅ 최신 버전입니다.", "color: #00c853; font-weight: bold;");
}
} catch (err) {
console.error("[UPDATE] 업데이트 확인 중 오류:", err);
}

// 3시간마다 자동 재실행
setTimeout(manualUpdateCheck, 1000 * 60 * 60 * 3);

// 버전 비교 함수
function compareVersions(a, b) {
const pa = a.split('.').map(n => parseInt(n, 10));
const pb = b.split('.').map(n => parseInt(n, 10));
for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
const na = pa[i] || 0;
const nb = pb[i] || 0;
if (na > nb) return 1;
if (na < nb) return -1;
}
return 0;
}

self.manualUpdateCheck = manualUpdateCheck;
})();

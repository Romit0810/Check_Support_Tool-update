// ============================================================
// background.js
// ============================================================

// 서비스워커 로드 및 기본 이벤트
chrome.runtime.onInstalled.addListener(() => {
  console.log("[BG] onInstalled");
  refreshAdminState();
  wakeAdmin1Tabs();

  // 1시간마다 업데이트 체크
  chrome.alarms.create("updateCheck", { periodInMinutes: 60 });
});

chrome.runtime.onStartup?.addListener(() => {
  console.log("[BG] onStartup");
  refreshAdminState();
  wakeAdmin1Tabs();

  // 브라우저 시작 시 알람 재생성
  chrome.alarms.create("updateCheck", { periodInMinutes: 60 });
});

// 기본 아이콘이 보이지 않도록, 서비스워커가 살아난 즉시 오류 세팅
(function initErrorBadge() {
  chrome.storage.local.set({ __ext_admin_error: true }, () => {
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#FF4081" });
    chrome.action.setBadgeTextColor?.({ color: "#000000ff" });
    console.log("[BG] 초기 오류 배지 세팅(기본 아이콘 방지)");
  });
})();

// Ping 확인
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg === "ping") {
    console.log("[BG] ping 받음");
    sendResponse("pong");
  }
});

// 경쟁사 접속버튼
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.action === "open_competitor_link_from_external") {
    chrome.tabs.query({ url: ["*://price.coupang.com/*"] }, (tabs) => {
      const admin1Tabs = (tabs || []).filter(t =>
        /#\/matching\/\d+(\b|[/?#])?/i.test(t.url || "")
      );
      if (admin1Tabs.length === 0) { sendResponse({ ok: false }); return; }
      chrome.tabs.sendMessage(admin1Tabs[0].id, { action: "open_competitor_link" }, (res) => {
        sendResponse(res && res.ok ? { ok: true } : { ok: false });
      });
    });
    return true;
  }
});

// 경쟁사 접속버튼 / 보리보리
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.action === "open_incognito_url" && typeof msg.url === "string") {
    try {
      chrome.windows.create({ url: msg.url, incognito: true }, (win) => {
        if (chrome.runtime.lastError) { sendResponse({ ok: false }); return; }
        sendResponse({ ok: true, windowId: win && win.id });
      });
    } catch (_) { sendResponse({ ok: false }); }
    return true;
  }
});

// Admin 상태 관리
function refreshAdminState() {
  chrome.tabs.query({ url: ["*://price.coupang.com/*"] }, (tabs) => {
    const admin1Tabs = (tabs || []).filter(t => /#\/matching\/\d+(\b|[/?#])?/i.test(t.url || ""));
    const admin1Count = admin1Tabs.length;
    const viidOk = admin1Count > 0;

    chrome.storage.local.set({
      __ext_admin_tabs: admin1Count,
      __ext_admin_matching_tabs: admin1Count,
      __ext_admin_viid_ok: viidOk
    }, () => {
      let isError = false;
      if (admin1Count === 0 || admin1Count > 1 || !viidOk) isError = true;
      chrome.storage.local.get("__ext_admin_error", (res) => {
        if (res.__ext_admin_error !== isError) {
          chrome.storage.local.set({ __ext_admin_error: isError }, () => {
            console.log("[BG] __ext_admin_error 강제 갱신:", res.__ext_admin_error, "→", isError);
          });
        }
      });
    });

    if (admin1Count === 0 || !viidOk) {
      chrome.storage.local.remove(["__ext_last_unit"]);
    }
  });
}

// Admin1 탭 깨워서 admin.js 주입
function wakeAdmin1Tabs() {
  try {
    chrome.tabs.query({ url: ["*://price.coupang.com/*"] }, (tabs) => {
      const admin1Tabs = (tabs || []).filter(t =>
        /#\/matching\/\d+(\b|[/?#])?/i.test(t.url || "")
      );
      admin1Tabs.forEach((tab) => {
        chrome.tabs.sendMessage(tab.id, { action: "extract_and_highlight" }, (res) => {
          if (chrome.runtime.lastError || !res) {
            try {
              chrome.scripting?.executeScript?.(
                { target: { tabId: tab.id }, files: ["content/admin.js"] },
                () => {
                  setTimeout(() => {
                    try { chrome.tabs.sendMessage(tab.id, { action: "extract_and_highlight" }, () => { }); } catch (e) { }
                  }, 300);
                }
              );
            } catch (e) { console.warn("[BG] wakeAdmin1Tabs inject error:", e); }
          }
        });
      });
    });
  } catch (e) { console.warn("[BG] wakeAdmin1Tabs error:", e); }
}

// 탭 이벤트
chrome.tabs.onCreated.addListener(() => refreshAdminState());
chrome.tabs.onRemoved.addListener(() => refreshAdminState());
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if ((changeInfo.url && /price\.coupang\.com/.test(changeInfo.url)) ||
    (tab && tab.url && /price\.coupang\.com/.test(tab.url))) {
    refreshAdminState();
  }
});
chrome.tabs.onActivated.addListener(() => refreshAdminState());

// 배지 표시
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if ("__ext_admin_error" in changes) {
    const { newValue } = changes.__ext_admin_error;
    console.log("[BG] __ext_admin_error 변경:", newValue ? "오류 발생" : "정상");
    if (newValue) {
      chrome.action.setBadgeText({ text: "!" });
      chrome.action.setBadgeBackgroundColor({ color: "#FF4081" });
      chrome.action.setBadgeTextColor?.({ color: "#000000ff" });
    } else {
      chrome.action.setBadgeText({ text: "O" });
      chrome.action.setBadgeBackgroundColor({ color: "#FFEB3B" });
      chrome.action.setBadgeTextColor?.({ color: "#000000" });
    }
  }
});

// CSV 업로드 처리
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.action !== "upload_blacklist_file") return;
  console.log("[BG] CSV 업로드 요청 수신:", msg.filename);
  try {
    chrome.storage.local.set({
      __ext_uploaded_csv: msg.csvText,
      __ext_uploaded_filename: msg.filename,
      __ext_uploaded_timestamp: Date.now(),
    }, () => {
      console.log("[BG] CSV 저장 완료:", msg.filename);
      chrome.storage.local.get(["__ext_uploaded_filename"], (chk) => { console.log("[BG] 저장 검증:", chk); });
      setTimeout(() => sendResponse({ ok: true }), 150);
    });
  } catch (e) {
    console.error("[BG] CSV 업로드 오류:", e);
    sendResponse({ ok: false });
  }
  return true;
});

// CSV 정보 요청
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.action === "get_uploaded_file_info") {
    chrome.storage.local.get(["__ext_uploaded_filename", "__ext_uploaded_csv"], (res) => {
      sendResponse(res || {});
    });
    return true;
  }
});

// 서비스워커 suspend / resume
chrome.runtime.onSuspendCanceled?.addListener(() => {
  console.log("[BG] Service worker resumed, verifying cached storage…");
  chrome.storage.local.get(["__ext_uploaded_filename", "__ext_uploaded_csv"], (res) => {
    if (res.__ext_uploaded_filename) {
      console.log("[BG] Cached file still present:", res.__ext_uploaded_filename);
    } else {
      console.warn("[BG] Cached file missing after resume");
    }
  });
});

chrome.runtime.onSuspend?.addListener(() => {
  console.log("[BG] onSuspend → 강제 flush");
  chrome.storage.local.get(null, (res) => {
    console.log("[BG] Suspend 직전 저장된 키 수:", Object.keys(res).length);
  });
});

// KeepAlive
let keepAlivePort = null;
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "keepAlive") {
    console.log("[BG] KeepAlive 연결됨");
    keepAlivePort = port;
    port.onDisconnect.addListener(() => {
      console.log("[BG] KeepAlive 해제됨");
      keepAlivePort = null;
    });
  }
});

// ============================================================
// 업데이트 확인 - 예전 동일한 즉시실행함수(IIFE) 방식으로 복원
// "type": "module" 환경에서 일반 async function은 hoisting 안 됨
// IIFE 방식은 선언과 동시에 실행되므로 onInstalled 호출 불필요
// ============================================================
(async function manualUpdateCheck() {
  const UPDATE_URL = "https://raw.githubusercontent.com/Romit0810/Check_Support_Tool-update/main/update.xml";
  const CURRENT_VERSION = chrome.runtime.getManifest().version;

  try {
    const res = await fetch(UPDATE_URL + "?t=" + Date.now(), { cache: "no-store" });
    if (!res.ok) { console.warn("[UPDATE] XML 요청 실패:", res.status); return; }

    const text = await res.text();
    const match = text.match(/<updatecheck[^>]+version=['"]([\d.]+)['"]/i);
    if (!match) { console.warn("[UPDATE] XML 내 버전 정보 없음"); return; }

    const latestVersion = match[1].trim();
    console.log(`[UPDATE] 현재 버전: ${CURRENT_VERSION}, 최신 버전: ${latestVersion}`);

    if (compareVersions(latestVersion, CURRENT_VERSION) > 0) {
      console.log("%c🎉 새 버전 발견됨!", "color: green; font-weight: bold;");

      chrome.storage.local.set({ __latest_update_version: latestVersion });

      // 예전 방식 그대로 - await/getURL 없이 콜백 방식
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icons/icon128.png",
        title: "Check_Support_Tool 업데이트",
        message: `새로운 버전 ${latestVersion}이 확인되었습니다.\n클릭 해주세요.`,
        priority: 2
      });

    } else {
      console.log("%c✅ 최신 버전입니다.", "color: #00c853; font-weight: bold;");
    }
  } catch (err) {
    console.error("[UPDATE] 업데이트 확인 중 오류:", err);
  }

  // 예전 방식 그대로 - setTimeout 3시간 재귀
  setTimeout(manualUpdateCheck, 1000 * 60 * 60 * 3);

  function compareVersions(a, b) {
    const pa = a.split('.').map(n => parseInt(n, 10));
    const pb = b.split('.').map(n => parseInt(n, 10));
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const na = pa[i] || 0;
      const nb = pb[i] || 0;
      if (na > nb) return 1;
      if (na < nb) return -1;
    }
    return 0;
  }

  self.manualUpdateCheck = manualUpdateCheck;
})();

// 알람 기반 업데이트 체크 보조 (MV3용)
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "updateCheck") {
    console.log("[UPDATE] alarm 실행됨");
    self.manualUpdateCheck?.();
  }
});

// 업데이트 알림 클릭 처리
chrome.notifications.onClicked.addListener((notificationId) => {
  chrome.storage.local.get("__latest_update_version", (res) => {
    if (!res.__latest_update_version) return;
    chrome.tabs.create({
      url: `https://raw.githubusercontent.com/Romit0810/Check_Support_Tool-update/main/Check_Support_Tool_v${res.__latest_update_version}.zip`
    });
  });
});
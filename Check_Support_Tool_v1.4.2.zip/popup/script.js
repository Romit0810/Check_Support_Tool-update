// 날짜 포맷 함수 (YY.MM.DD 형식)
function formatDate(date) {
const yy = String(date.getFullYear()).slice(2);
const mm = String(date.getMonth() + 1).padStart(2, '0');
const dd = String(date.getDate()).padStart(2, '0');
return `${yy}.${mm}.${dd}`;
}

// 기준일: 오늘 00시
function getTodayMidnight() {
const now = new Date();
return new Date(now.getFullYear(), now.getMonth(), now.getDate());
}

// 특정 일수 뒤 날짜 구하기
function addDays(baseDate, days) {
const result = new Date(baseDate);
result.setDate(result.getDate() + days);
return result;
}

// DOM 업데이트
function updateDates() {
const today = getTodayMidnight();

// TODAY 날짜
document.getElementById("today-date").textContent = formatDate(today);
}

// 실행
updateDates();

// 5줄 패널 시트에서 동적 렌더링
function addDaysFromToday(n) {
const today = getTodayMidnight();
return formatDate(addDays(today, n));
}

function resolvePanelValue(value) {
// {days:숫자} → 실제 날짜로 변환
return value.replace(/\{days:(\d+)\}/g, (_, n) => addDaysFromToday(Number(n)));
}

function renderPanelGrid(rows) {
const grid = document.getElementById("panel-grid");
if (!grid) return;
if (!rows || rows.length === 0) return;

grid.innerHTML = rows.map(r =>
`<div class="label">${r.label}</div>
<div class="value">${resolvePanelValue(r.value)}</div>`
).join("");
}

chrome.storage.local.get("popup_panel_rows", (res) => {
renderPanelGrid(res.popup_panel_rows || []);
});

// 유통기한 기능 토글 상태 출력
const expiryToggle = document.getElementById("expiry-toggle");
if (expiryToggle) {
expiryToggle.addEventListener("change", function () {
if (this.checked) {
console.log("유통기한 기능: 켜짐");
// 여기에 켜졌을 때 기능 추가 가능
} else {
console.log("유통기한 기능: 꺼짐");
// 여기에 꺼졌을 때 기능 추가 가능
}
});
}
// ============================================================
// background.js
// ============================================================

chrome.runtime.onInstalled.addListener(() => {
console.log("[BG] onInstalled");
refreshAdminState();
wakeAdmin1Tabs();

chrome.alarms.create("updateCheck", { periodInMinutes: 60 }); // 1시간마다 업데이트 체크
manualUpdateCheck(); // 설치 직후 1번 즉시 체크
});

chrome.runtime.onStartup?.addListener(() => {
console.log("[BG] onStartup");
refreshAdminState();
wakeAdmin1Tabs();

chrome.alarms.create("updateCheck", { periodInMinutes: 60 }); // 브라우저 시작 시 알람 재생성
manualUpdateCheck(); // 시작 시 1번 즉시 체크
});

// 기본 아이콘이 보이지 않도록, 서비스워커가 살아난 즉시 오류 세팅
(function initErrorBadge() {
chrome.storage.local.set({ __ext_admin_error: true }, () => {
chrome.action.setBadgeText({ text: "!" });
chrome.action.setBadgeBackgroundColor({ color: "#FF4081" });
chrome.action.setBadgeTextColor?.({ color: "#000000ff" });
console.log("[BG] 초기 오류 배지 세팅(기본 아이콘 방지)");
});
})();

// Ping 확인 (popup/content -> 서비스워커 살아있는지 확인)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (msg === "ping") {
console.log("[BG] ping 받음");
sendResponse("pong");
}
});

// ============================================================
// 경쟁사 (보리보리) 접속버튼
// ============================================================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (msg && msg.action === "open_competitor_link_from_external") {

chrome.tabs.query({ url: ["*://price.coupang.com/*"] }, (tabs) => {
// Admin1('#/matching/숫자') 탭만 대상
const admin1Tabs = (tabs || []).filter(t =>
/#\/matching\/\d+(\b|[/?#])?/i.test(t.url || "")
);

if (admin1Tabs.length === 0) {
sendResponse({ ok: false });
return;
}

chrome.tabs.sendMessage(
admin1Tabs[0].id,
{ action: "open_competitor_link" },
(res) => {
sendResponse(res && res.ok ? { ok: true } : { ok: false });
}
);
});

return true; // 비동기 응답 필수
}
});

// 보리보리
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (msg && msg.action === "open_incognito_url" && typeof msg.url === "string") {
try {
chrome.windows.create({ url: msg.url, incognito: true }, (win) => {
if (chrome.runtime.lastError) {
sendResponse({ ok: false });
return;
}
sendResponse({ ok: true, windowId: win && win.id });
});
} catch (_) {
sendResponse({ ok: false });
}
return true; // ★ 비동기 응답
}
});

// ============================================================
// Admin 상태 관리 함수 & 이벤트
// 페이지 상태를 및 오류여부 확인
// ============================================================

function refreshAdminState() {
// price.coupang.com 탭 모두 가져오기
chrome.tabs.query({ url: ["*://price.coupang.com/*"] }, (tabs) => {
// 어드민1만 집계, 어드민2 집계 제외
const admin1Tabs = (tabs || []).filter(t => /#\/matching\/\d+(\b|[/?#])?/i.test(t.url || ""));
const admin1Count = admin1Tabs.length;

// 유효 결과(검색된상태)도 Admin1이 1개 이상이면 true
const viidOk = admin1Count > 0;

chrome.storage.local.set({
__ext_admin_tabs: admin1Count, // 'Admin1(매칭/숫자) 탭 수'
__ext_admin_matching_tabs: admin1Count, // 명시적 키(선택) - 유지/활용 가능
__ext_admin_viid_ok: viidOk // Admin1 검색 결과 존재 여부
}, () => {

// 오류 판정: Admin1 없음(0) / 2개 이상 / 결과 없음
let isError = false;
if (admin1Count === 0 || admin1Count > 1 || !viidOk) isError = true;

chrome.storage.local.get("__ext_admin_error", (res) => {
if (res.__ext_admin_error !== isError) {
chrome.storage.local.set({ __ext_admin_error: isError }, () => {
console.log("[BG] __ext_admin_error 강제 갱신:", res.__ext_admin_error, "→", isError);
});
}
});
});

// Admin1 검색된 탭이 없으면 배너 OFF
if (admin1Count === 0 || !viidOk) {
chrome.storage.local.remove(["__ext_last_unit"]);
}
});
}

// 이미 떠있는 Admin1 탭(#/matching/숫자) 깨워서 admin.js 주입 → 추출 트리거
function wakeAdmin1Tabs() {
try {
chrome.tabs.query({ url: ["*://price.coupang.com/*"] }, (tabs) => {
const admin1Tabs = (tabs || []).filter(t =>
/#\/matching\/\d+(\b|[/?#])?/i.test(t.url || "")
);

admin1Tabs.forEach((tab) => {
// 1) 우선 extract 시도 (이미 주입되어 있다면 바로 응답)
chrome.tabs.sendMessage(tab.id, { action: "extract_and_highlight" }, (res) => {
if (chrome.runtime.lastError || !res) {
// 2) 미주입/슬립이면 admin.js를 주입하고 잠깐 대기 후 재요청
try {
chrome.scripting?.executeScript?.(
{ target: { tabId: tab.id }, files: ["content/admin.js"] }, //
() => {
setTimeout(() => {
try {
chrome.tabs.sendMessage(tab.id, { action: "extract_and_highlight" }, () => { });
} catch (e) { }
}, 300); // 주입 직후 SPA가 DOM/데이터 준비될 시간을 더 줌
}
);
} catch (e) {
console.warn("[BG] wakeAdmin1Tabs inject error:", e);
}
}
});
});
});
} catch (e) {
console.warn("[BG] wakeAdmin1Tabs error:", e);
}
}

// ============================================================
// 어드민 2 - > 어드민 1 자동검색 안정화
// ============================================================
function triggerAdmin1ExtractionCycle() {
chrome.tabs.query({ url: ["*://price.coupang.com/*"] }, (tabs) => {
const admin1Tabs = (tabs || []).filter(t =>
/#\/matching\/\d+(\b|[/?#])?/i.test(t.url || "")
);
if (admin1Tabs.length === 0) {
console.warn("[BG] triggerAdmin1ExtractionCycle: Admin1 탭 없음");
return;
}

const tab = admin1Tabs[0];

try {
chrome.tabs.update(tab.id, { autoDiscardable: false });
} catch (_) { /* ignore */ }

const attemptExtract = (tabId, delay) => {
setTimeout(() => {
try {
chrome.tabs.sendMessage(tabId, { action: "extract_and_highlight" }, (res) => {
if (chrome.runtime.lastError || !res) {
try {
chrome.scripting?.executeScript?.(
{ target: { tabId }, files: ["content/admin.js"] },
() => setTimeout(() => {
try {
chrome.tabs.sendMessage(tabId, { action: "extract_and_highlight" }, () => { });
} catch (e2) { /* ignore */ }
}, 250)
);
} catch (e1) {
}
}
});
} catch (e0) {
}
}, delay);
};

attemptExtract(tab.id, 0);
attemptExtract(tab.id, 80);
attemptExtract(tab.id, 160);
attemptExtract(tab.id, 300);
attemptExtract(tab.id, 500);
attemptExtract(tab.id, 1000);
});
}

function triggerAdmin1ModelCycle() {
chrome.tabs.query({ url: ["*://price.coupang.com/*"] }, (tabs) => {
const admin1Tabs = (tabs || []).filter(t =>
/#\/matching\/\d+(\b|[/?#])?/i.test(t.url || "")
);
if (admin1Tabs.length === 0) return;
const tabId = admin1Tabs[0].id;

const tryOnce = (delay) => {
setTimeout(() => {
try {
chrome.tabs.sendMessage(tabId, { action: "model_refresh" }, () => { });
} catch (_) { }
}, delay);
};

[0, 100, 200, 350, 500, 700, 900].forEach(tryOnce);
});
}

chrome.tabs.onCreated.addListener(() => refreshAdminState());
chrome.tabs.onRemoved.addListener(() => refreshAdminState());
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {

if ((changeInfo.url && /price\.coupang\.com/.test(changeInfo.url)) ||
(tab && tab.url && /price\.coupang\.com/.test(tab.url))) {
refreshAdminState();
}
});

chrome.tabs.onActivated.addListener(() => refreshAdminState());

chrome.storage.onChanged.addListener((changes, area) => {
if (area !== "local") return;

if ("__ext_deal_id" in changes) {
try { triggerAdmin1ExtractionCycle(); } catch (_) { }
}

if ("__ext_admin_error" in changes) {
const { newValue } = changes.__ext_admin_error;
console.log("[BG] __ext_admin_error 변경:", newValue ? "오류 발생" : "정상");

// 오류 상태 → 분홍색 !, 정상 → 노란색 O
if (newValue) {
chrome.action.setBadgeText({ text: "!" });
chrome.action.setBadgeBackgroundColor({ color: "#FF4081" });
chrome.action.setBadgeTextColor?.({ color: "#000000ff" });
} else {
chrome.action.setBadgeText({ text: "O" });
chrome.action.setBadgeBackgroundColor({ color: "#FFEB3B" });
chrome.action.setBadgeTextColor?.({ color: "#000000" });
}


}
});
// ============================================================
// CSV 업로드 처리 (팝업에서 보낸 파일 저장 및 검증)
// ============================================================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (!msg || msg.action !== "upload_blacklist_file") return;
console.log("[BG] CSV 업로드 요청 수신:", msg.filename);

try {
// 파일 내용, 이름, 업로드 시간 저장
chrome.storage.local.set({
__ext_uploaded_csv: msg.csvText,
__ext_uploaded_filename: msg.filename,
__ext_uploaded_timestamp: Date.now(),
}, () => {
console.log("[BG] CSV 저장 완료:", msg.filename);

// 저장 직후 즉시 검증
chrome.storage.local.get(["__ext_uploaded_filename"], (chk) => {
console.log("[BG] 저장 검증:", chk);
});

// 팝업 리셋 방지 응답
setTimeout(() => sendResponse({ ok: true }), 150);
});
} catch (e) {
console.error("[BG] CSV 업로드 오류:", e);
sendResponse({ ok: false });
}
return true; // 비동기 응답 유지
});

// 업로드된 CSV 정보 요청 처리
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (msg && msg.action === "get_uploaded_file_info") {
chrome.storage.local.get(["__ext_uploaded_filename", "__ext_uploaded_csv"], (res) => {
sendResponse(res || {}); // 업로드된 파일 정보 반환
});
return true; // 비동기 응답 유지
}
});

// 서비스워커 suspend / resume 관리
// 서비스워커가 suspend에서 복귀했을 때 캐시 확인
chrome.runtime.onSuspendCanceled?.addListener(() => {
console.log("[BG] Service worker resumed, verifying cached storage…");
chrome.storage.local.get(["__ext_uploaded_filename", "__ext_uploaded_csv"], (res) => {
if (res.__ext_uploaded_filename) {
console.log("[BG] Cached file still present:", res.__ext_uploaded_filename);
} else {
console.warn("[BG] Cached file missing after resume → will restore soon if popup reopens");
}
});
});

// 서비스워커 suspend 시 저장 상태 확인
chrome.runtime.onSuspend?.addListener(() => {
console.log("[BG] onSuspend → 강제 flush");
chrome.storage.local.get(null, (res) => {
console.log("[BG] Suspend 직전 저장된 키 수:", Object.keys(res).length);
});
});

// KeepAlive 연결 유지 (서비스워커 슬립 방지)
let keepAlivePort = null;
chrome.runtime.onConnect.addListener((port) => {
if (port.name === "keepAlive") {
console.log("[BG] KeepAlive 연결됨");
keepAlivePort = port;
port.onDisconnect.addListener(() => {
console.log("[BG] KeepAlive 해제됨");
keepAlivePort = null;
});
}
});

// ============================================================
// [업데이트 관련]
// ============================================================

// 업데이트 설정
const UPDATE_XML_URL = "https://raw.githubusercontent.com/Romit0810/Check_Support_Tool-update/main/update.xml";
const UPDATE_NOTIFICATION_ID = "CST_UPDATE_AVAILABLE";

// 알람에서 업데이트 체크
chrome.alarms.onAlarm.addListener((alarm) => {
if (alarm.name === "updateCheck") {
console.log("[UPDATE] alarm 실행됨");
manualUpdateCheck();
}
});

// 업데이트 알림 클릭 → ZIP 다운로드 탭 오픈 (전역 1회 등록)
chrome.notifications.onClicked.addListener((notificationId) => {
if (notificationId !== UPDATE_NOTIFICATION_ID) return;

chrome.storage.local.get("__latest_update_version", (res) => {
const v = res.__latest_update_version;
if (!v) return;

chrome.tabs.create({
url: `https://raw.githubusercontent.com/Romit0810/Check_Support_Tool-update/main/Check_Support_Tool_v${v}.crx`
});
});
});

// 메시지로도 강제 업데이트 체크 가능
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (msg && msg.action === "manual_update_check") {
manualUpdateCheck()
.then((result) => sendResponse({ ok: true, result }))
.catch((e) => sendResponse({ ok: false, error: String(e) }));
return true; // 비동기 응답
}
});

// [추가] auto-search.js가 "방금 검색 제출됨"을 알릴 때 → 즉시 추출 사이클 실행
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (msg && msg.action === "auto_search_submitted") {
try { triggerAdmin1ExtractionCycle(); } catch (_) { }
try { triggerAdmin1ModelCycle(); } catch (_) { } // [추가]
sendResponse?.({ ok: true });
}
});


// 실제 업데이트 체크 함수 (콘솔 최소 출력 버전)
async function manualUpdateCheck() {
const CURRENT_VERSION = chrome.runtime.getManifest().version;
let latestVersion = null;

try {
const res = await fetch(UPDATE_XML_URL + "?t=" + Date.now(), { cache: "no-store" });
if (!res.ok) return;

const text = await res.text();
const match = text.match(/<updatecheck[^>]+version=['"]([\d.]+)['"]/i);
if (!match) return;

latestVersion = match[1].trim();

// 콘솔
console.log("현재 버전 :", CURRENT_VERSION);
console.log("최신 버전 :", latestVersion);

if (compareVersions(latestVersion, CURRENT_VERSION) > 0) {

await chrome.storage.local.set({ __latest_update_version: latestVersion });

console.log("새 버전이 있습니다.");

chrome.notifications.create(
UPDATE_NOTIFICATION_ID,
{
type: "basic",
iconUrl: chrome.runtime.getURL("icons/icon128.png"),
title: "Check_Support_Tool 업데이트",
message: `새로운 버전 ${latestVersion}이 확인되었습니다.\n클릭시 ZIP 다운로드로 이동합니다.`,
priority: 2
}
);

} else {
console.log("현재 최신 버전입니다.");
}

} catch (err) {
// 에러 콘솔제거
}

function compareVersions(a, b) {
const pa = String(a).split('.').map(n => parseInt(n, 10) || 0);
const pb = String(b).split('.').map(n => parseInt(n, 10) || 0);
for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
const na = pa[i] || 0;
const nb = pb[i] || 0;
if (na > nb) return 1;
if (na < nb) return -1;
}
return 0;
}
}

// 전역 호출용 유지
self.manualUpdateCheck = manualUpdateCheck;


// ============================================================
// Apps Script 동기화 _ 로밋
// ============================================================
const MY_WEBAPP_URL = "https://script.google.com/a/macros/cpg.coupang.com/s/AKfycbx07HDzUzeBGTMKvceMFxs5Y8gfYQJJTXCdC8DfBj0nbhON8EOGseuonv0vPgCffvz9mQ/exec";

const REGISTRY = [
{
tab: "BlacklistSite", // 탭명
key: "BlacklistSite", // 저장 키 = 탭명
transform: (rows) => {
return (rows || [])
.filter(r => {
const en = String(r?.Enabled ?? "").trim().toUpperCase();
const on = (en === "TRUE" || en === "1" || en === "Y");
const u = String(r?.Url ?? "").trim();
return on && u;
})
.map(r => String(r.Url).trim());
}
},
{
tab: "etx_banner.js",
key: "etx_banner_rules",
transform: (rows) => {
return (rows || [])
.filter(r => {
const en = String(r?.Enabled ?? "").trim().toUpperCase();
return (en === "TRUE" || en === "1" || en === "Y");
})
.map(r => ({
name: String(r?.Name ?? "").trim(),
condition: String(r?.Condition ?? "").trim().toLowerCase(),
kanid: String(r?.Kanid ?? "").trim(),
kan2: String(r?.Kan2 ?? "").trim(),
unit: String(r?.Unit ?? "").trim(),
url: String(r?.Url ?? "").trim(),
banner: String(r?.Banner ?? "").trim(),
}));
}
},
{
tab: "expiry-date.js",
key: "expiry_banner_rules",
transform: (rows) => {
return (rows || [])
.filter(r => {
const en = String(r?.Enabled ?? "").trim().toUpperCase();
return (en === "TRUE" || en === "1" || en === "Y");
})
.map(r => ({
units: String(r?.Unit ?? "").trim(),
banner: String(r?.Banner ?? "").trim(),
}));
}
},
{
tab: "window-baby.js",
key: "window_baby_kans",
transform: (rows) => {
return (rows || [])
.filter(r => {
const en = String(r?.Enabled ?? "").trim().toUpperCase();
return (en === "TRUE" || en === "1" || en === "Y");
})
.map(r => String(r?.Kanid ?? "").trim())
.filter(Boolean);
}
},
{
tab: "popup.html",
key: "popup_panel_rows",
transform: (rows) => {
return (rows || [])
.filter(r => {
const en = String(r?.Enabled ?? "").trim().toUpperCase();
return (en === "TRUE" || en === "1" || en === "Y");
})
.map(r => ({
label: String(r?.Label ?? "").trim(),
value: String(r?.Value ?? "").trim(),
}));
}
}
// 객체추가 위치
];

async function syncRegistry() {
try {
const res = await fetch(MY_WEBAPP_URL + "?t=" + Date.now(), { cache: "no-store", redirect: "follow" });
if (!res.ok) throw new Error("HTTP " + res.status);
const json = await res.json();
const toSave = {};

REGISTRY.forEach(({ tab, key, transform }) => {
const rows = Array.isArray(json?.[tab]) ? json[tab] : [];
try {
toSave[key] = transform(rows);
console.log(`[REGISTRY] ${tab} → ${key}: ${rows.length} rows → ${Array.isArray(toSave[key]) ? toSave[key].length : (toSave[key] ? 1 : 0)
} saved`);
} catch (e) {
console.warn(`[REGISTRY] ${tab} 변환 중 오류:`, e);
}
});

if (Object.keys(toSave).length > 0) {
await chrome.storage.local.set(toSave);
console.log("[REGISTRY] 저장완료 키:", Object.keys(toSave));
}
} catch (e) {
console.warn("[REGISTRY] 동기화 실패:", e);
}
}

// 최초 1회 + 30분 주기
syncRegistry();
chrome.alarms.create("sync_registry", { periodInMinutes: 30 });
chrome.alarms.onAlarm.addListener((alarm) => {
if (alarm.name === "sync_registry") syncRegistry();
});

/*********************************************************************/


// ============================================================
// 구글 스프레드시트 동기화 섹션 (Apps Script 버전)
// ============================================================

const KAN_SHEET_URL = "https://script.google.com/a/macros/cpg.coupang.com/s/AKfycbxSZ53HGrvzhkLfoo6wR-fB5PUt11B7WfK8yb2JR0vpe29EplJwt6rtXaHRNUWvIXI12Q/exec";

async function syncKanDataFromServer() {
try {
const res = await fetch(KAN_SHEET_URL + "?t=" + Date.now(), { redirect: 'follow' });
const data = await res.json();

// ⚠️ 여기서 키 이름이 반드시 "__ext_master_data" 이어야 합니다!
await chrome.storage.local.set({ "__ext_master_data": data });

console.log("[BG] ✅ 데이터 저장 완료 (키: __ext_master_data)");
} catch (e) {
console.error("[BG] ❌ 동기화 중 오류:", e);
}
}

// [background.js 맨 하단에 추가]
// 서비스 워커 로드 시 즉시 동기화 실행
syncKanDataFromServer();

// 1시간마다 주기적으로 동기화 (옵션)
chrome.alarms.create("sync_kan_data", { periodInMinutes: 60 });
chrome.alarms.onAlarm.addListener((alarm) => {
if (alarm.name === "sync_kan_data") syncKanDataFromServer();
});


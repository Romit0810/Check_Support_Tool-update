// =================================================================================
// admin.js
// 어드민의 Vendoritem ID, Siteitemid, KAN ID, Unitname1저장 및 방문설치, 경쟁사접속버튼 기능
// =================================================================================

console.log("[CONTENT] admin.js 로드됨:", location.href);

(function () {

// 공통 상수 / 유틸 함수

// KAN ID / UNITNAME 형식 체크용 정규식
const KAN_REGEX = /^[0-9]{3,4}$/;
const UNIT_REGEX = /^[A-Za-z0-9&, ]+$/;

// 문자열 정리 (공백 통일)
const tnorm = (s) => (s || "").replace(/\s+/g, " ").trim();

// 대소문자 무시 비교
const ciEq = (a, b) => tnorm(a).toLowerCase() === tnorm(b).toLowerCase();

// installation-type.js의 방문 설치
function hasVisitInstall(text) {
return /(방문\s*설치|출장\s*장착|출장\s*교체)/.test(text);
}

// dmin 페이지 감지 함수

function isAdminPage() {
return /price\.coupang\.com/.test(location.host);
}

function isAdminMatchingPage() {
const h = location.hash || "";
// Admin1만 true
return /^#\/matching\/\d+(\b|[/?#])?/i.test(h);
}

// Admin 값 찾기

function findLabelExactCI(text) {
const all = document.querySelectorAll("body *");
for (const el of all) {
const txt = tnorm(el.textContent);
if (!txt) continue;
if (ciEq(txt, text)) return el;
}
return null;
}

function findValueUnder(labelEl) {
if (!labelEl) return null;

const parent = labelEl.parentElement;
if (parent) {
const kids = Array.from(parent.children);
const idx = kids.indexOf(labelEl);
for (let i = idx + 1; i < kids.length; i++) {
const s = kids[i];
const val = tnorm(s.textContent);
if (val) return s;
}
}

const all = Array.from(document.querySelectorAll("body *"));
const pos = all.indexOf(labelEl);

for (let i = pos + 1; i < Math.min(all.length, pos + 150); i++) {
const e = all[i];
const val = tnorm(e.textContent);
if (val) return e;
}

return null;
}

// Admin 요소 보임 여부 체크

function isVisible(el) {
if (!el) return false;
if (el.offsetParent !== null) return true;
return el.getClientRects && el.getClientRects().length > 0;
}

function findVisibleLabelExactCI(text) {
const all = document.querySelectorAll("th, td, div, span, a, button");

for (const el of all) {
const txt = tnorm(el.textContent || "");
if (!txt) continue;
if (ciEq(txt, text) && isVisible(el)) return el;
}

return null;
}

// Admin 데이터 추출

function extractAdminAndHighlight() {

if (!isAdminMatchingPage())
return { kan: null, unit: null, vendor: null, siteitem: null };

let kan = null;
let unit = null;
let vendor = null;
let siteitem = null;
let kan2 = null;

// installation-type.js의 방문 설치 로직ㅣ쿠팡 딜명 방문설치 여부 판단

let installationType = null;

// 어드민 상품명 영역
const titleEl = document.querySelector(
"div.Heading3[data-elm-id='Name__CoupangItem']"
);

if (titleEl) {
const titleText = titleEl.textContent || "";
if (hasVisitInstall(titleText)) {
installationType = "VISIT";
}
}

// 1. KAN
const kanLabel = findLabelExactCI("KAN ID");
if (kanLabel) {
const valEl = findValueUnder(kanLabel);
if (valEl) {
const v = tnorm(valEl.textContent);
if (KAN_REGEX.test(v)) kan = v;
}
}

// 2. KAN2
const kan2Label = findLabelExactCI("KAN2");
if (kan2Label) {
const valEl = findValueUnder(kan2Label);
if (valEl) {
const v = tnorm(valEl.textContent);
// 형식 제한 없이 그대로 저장 (문자열)
if (v) kan2 = v;
}
}

// 3. UNITNAME1
const unitLabel = findLabelExactCI("UNITNAME1");
if (unitLabel) {
const valEl = findValueUnder(unitLabel);
if (valEl) {
const v = tnorm(valEl.textContent);
if (UNIT_REGEX.test(v)) unit = v;
}
}

// 4. Vendoritem
const vendorLabel = findLabelExactCI("Vendoritem ID");
if (vendorLabel) {
const valEl = findValueUnder(vendorLabel);
if (valEl) {
const v = (valEl.textContent || "").trim();
if (/^[0-9]{9,12}$/.test(v)) vendor = v;
}
}

// 5. Siteitem (외부매핑 탭 패널 한정 + 최신 셀렉터 보강)
let shouldRemoveCachedSiteitem = true;

{
// ★ 외부매핑 패널을 확정
const mappingsPaneById = document.querySelector('[id$="-panel-mappings"]');
const mappingsPaneActive = document.querySelector('.ant-tabs-tabpane-active[id$="-panel-mappings"]');
const activeBtn = document.querySelector('.ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn');
const activePaneByActiveBtn = (activeBtn && document.getElementById(activeBtn.getAttribute('aria-controls'))) || null;

const pane = mappingsPaneActive || mappingsPaneById || activePaneByActiveBtn ||
document.querySelector('.ant-tabs-content-holder .ant-tabs-tabpane-active');

if (pane) {
// 1) 가상 테이블(div 기반)
const virtualHolder = pane.querySelector(".ant-table-tbody-virtual-holder-inner");
if (virtualHolder && isVisible(virtualHolder)) {
const vRows = Array.from(
virtualHolder.querySelectorAll(".ant-table-row[data-row-key]")
).filter(r => isVisible(r) && (r.textContent || "").trim() !== "");

if (vRows.length === 1) {
const r = vRows[0];

// 1-1) 최신: 데이터 속성 기반 셀 우선 (가장 확실)
let cell = r.querySelector('td[data-elm-id="AutoMapping__Competitor-siteitemId"]');
if (cell) {
const txt = (cell.textContent || "").trim();
if (/^\d{1,14}$/.test(txt)) siteitem = txt;
}

// 1-2) data-row-key가 숫자면 사용
if (!siteitem) {
const key = r.getAttribute("data-row-key");
if (/^\d{1,14}$/.test(key)) siteitem = key;
}

// 1-3) id 셀 fallback
if (!siteitem) {
const idCell = r.querySelector("#id, [id='id']");
const fromIdCell = idCell ? (idCell.textContent || "").trim() : "";
if (/^\d{1,14}$/.test(fromIdCell)) siteitem = fromIdCell;
}

// 1-4) 숫자만 있는 셀 마지막 fallback
if (!siteitem) {
const cells = Array.from(r.querySelectorAll(".ant-table-cell, td"));
for (const c of cells) {
const txt = (c.textContent || "").trim();
if (/^\d{1,14}$/.test(txt)) { siteitem = txt; break; }
}
}
}
}

// 2) 구버전: 실제 <table>
if (!siteitem) {
const table = pane.querySelector(".ant-table-body table");
if (table && isVisible(table)) {
const rows = Array.from(table.querySelectorAll("tbody tr"))
.filter(tr => isVisible(tr) && tr.querySelector("td") && tr.textContent.trim() !== "");
if (rows.length === 1) {
const r = rows[0];

// 2-1) 최신: 데이터 속성 기반 셀 우선
let cell = r.querySelector('td[data-elm-id="AutoMapping__Competitor-siteitemId"]');
if (cell) {
const txt = (cell.textContent || "").trim();
if (/^\d{1,14}$/.test(txt)) siteitem = txt;
}

// 2-2) 숫자 fallback
if (!siteitem) {
const tds = Array.from(r.querySelectorAll("td"));
for (const td of tds) {
const txt = (td.textContent || "").trim();
if (/^\d{1,14}$/.test(txt)) { siteitem = txt; break; }
}
}
}
}
}
}

if (siteitem) shouldRemoveCachedSiteitem = false;
}

// 저장
const toStore = {};

if (kan && KAN_REGEX.test(kan)) toStore.__ext_last_kan = kan;
if (unit && UNIT_REGEX.test(unit)) toStore.__ext_last_unit = unit;
if (vendor) toStore.__ext_last_vendor = vendor;
if (siteitem) toStore.__ext_last_siteitem = siteitem;
if (kan2) toStore.__ext_last_kan2 = kan2;

// installation-type.js의 방문 설치 로직ㅣ방문설치 상태 저장

if (installationType === "VISIT") {
toStore.__ext_installation_type = "VISIT";
// 마지막으로 방문설치를 감지한 시각(밀리초) 저장
toStore.__ext_installation_seen_at = Date.now();
} else {
// 명시적으로 NONE으로 기록하고, seen_at 제거
toStore.__ext_installation_type = "NONE";
chrome.storage.local.remove(["__ext_installation_seen_at"]);
}

if (Object.keys(toStore).length) {

chrome.storage.local.set(toStore);

if (shouldRemoveCachedSiteitem) {
chrome.storage.local.remove(["__ext_last_siteitem"]);
}

} else {

chrome.storage.local.remove([
"__ext_last_kan",
"__ext_last_unit",
"__ext_last_vendor",
"__ext_last_siteitem",
"__ext_installation_type"
]);
}

const isKanOK = !!kan && KAN_REGEX.test(kan);
const isUnitOK = !!unit && UNIT_REGEX.test(unit);
const isVendorOK = !!vendor && /^[0-9]{9,12}$/.test(vendor);

chrome.storage.local.get(
["__ext_admin_tabs", "__ext_admin_viid_ok", "__ext_admin_error"],
(res) => {

const tabCount = res.__ext_admin_tabs || 0;
const hasValidResult = res.__ext_admin_viid_ok;
const prevError = res.__ext_admin_error;

let isError = !(isKanOK && isUnitOK && isVendorOK);

if (tabCount === 0 || tabCount > 1 || !hasValidResult) {
isError = true;
}

if (prevError !== isError) {
chrome.storage.local.set(
{ __ext_admin_error: isError },
() => console.log("[CONTENT] __ext_admin_error 갱신:", prevError, "→", isError)
);
}
}
);

return { kan, unit, vendor, siteitem, kan2 };
}

// Admin 라우트 변경 감지
function onAdminRouteChange() {
if (isAdminMatchingPage()) {
extractAdminAndHighlight();
} else {
clearAdminHighlights();

// 매칭 상세 화면을 벗어난 경우 방문설치 상태를 즉시 해제
chrome.storage.local.set({ __ext_installation_type: "NONE" });
chrome.storage.local.remove(["__ext_installation_seen_at"]);
}
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

// 기존 Admin 정보 추출
if (msg && msg.action === "extract_and_highlight") {
const data = extractAdminAndHighlight();
sendResponse(data);
return true;
}

// 경쟁사 접속 버튼
// (어드민 결과 1줄일 때만 = siteitem 있을 때만)
if (msg && msg.action === "open_competitor_link") {

chrome.storage.local.get("__ext_last_siteitem", (res) => {
const siteitem = res.__ext_last_siteitem;

// 경쟁사 접속 버튼 로직
// [공통] 어드민 결과가 1줄이 아닐 경우 siteitem 없음 → 차단
if (!siteitem) {
sendResponse({ ok: false });
return;
}

try {
// 화면에 보이는 한 줄의 행을 구하는 헬퍼
const getSingleVisibleRow = () => {
// 1) 가상 테이블(div 기반)
const virtualHolder = document.querySelector(".ant-table-tbody-virtual-holder-inner");
if (virtualHolder && isVisible(virtualHolder)) {
const vRows = Array.from(
virtualHolder.querySelectorAll(".ant-table-row[data-row-key]")
).filter(r => isVisible(r) && (r.textContent || "").trim() !== "");
if (vRows.length === 1) return vRows[0];
}
// 2) 실제 table 태그 기반 (호환)
const table = document.querySelector(".ant-table-body table");
if (table && isVisible(table)) {
const rows = Array.from(table.querySelectorAll("tbody tr"))
.filter(tr =>
isVisible(tr) &&
tr.querySelector("td") &&
tr.textContent.trim() !== ""
);
if (rows.length === 1) return rows[0];
}
return null;
};

// URLSearchParams에서 대소문자 무시 파라미터 읽기
const getParamInsensitive = (sp, key) => {
key = String(key).toLowerCase();
for (const [k, v] of sp.entries()) {
if (String(k).toLowerCase() === key) return v;
}
return null;
};

// 문자열을 최대 3회까지 디코딩
const multiDecode = (s, maxTimes = 3) => {
let out = s;
for (let i = 0; i < maxTimes; i++) {
try {
const dec = decodeURIComponent(out);
if (dec === out) break;
out = dec;
} catch (_) {
break;
}
}
return out;
};

// 문자열/URL 안에서 **11st 전용** 상품번호만 엄격 추출
// 허용: prdNo / No (8~12자리) 또는 /products/(ma/)?{8~12자리}
const extract11stNoStrict = (s) => {
if (!s) return null;

const tryUrl = (str) => {
try {
const u = new URL(str);
// ① prdNo / No
let p = getParamInsensitive(u.searchParams, "prdNo");
if (p && /^\d{8,12}$/.test(p)) return p;

p = getParamInsensitive(u.searchParams, "No");
if (p && /^\d{8,12}$/.test(p)) return p;

// ② 경로 패턴
const m = u.pathname.match(/\/products\/(?:ma\/)?(\d{8,12})(?:[/?#]|$)/i);
if (m && m[1]) return m[1];

return null;
} catch {
// URL이 아니면 경로 패턴만 체크
const m = String(str).match(/\/products\/(?:ma\/)?(\d{8,12})(?:[/?#]|$)/i);
return m && m[1] ? m[1] : null;
}
};

// 1) 그대로 시도
let no = tryUrl(s);
if (no) return no;

// 2) 디코딩 반복하며 시도
const d = multiDecode(s, 3);
if (d !== s) {
no = tryUrl(d);
if (no) return no;
}

return null;
};

const rowEl = getSingleVisibleRow();
if (!rowEl) {
sendResponse({ ok: false });
return;
}

// originSite 영역의 링크들을 수집 (한 행 기준)
const originLinks = Array.from(
rowEl.querySelectorAll('#originSite a[href], [id="originSite"] a[href]')
);

// [스마트스토어] (storefarm → smartstore 변환)
{
const naverLink = rowEl.querySelector(
'#originSite a.ManualMappingListContainer__siteLink___hZYay[href^="http://storefarm.naver.com"],' +
'#originSite a.ManualMappingListContainer__siteLink___hZYay[href^="https://storefarm.naver.com"]'
);
if (naverLink && naverLink.href) {
const newUrl = naverLink.href.replace(
/^https?:\/\/storefarm\.naver\.com/,
"https://smartstore.naver.com"
);
window.open(newUrl, "_blank");
sendResponse({ ok: true, site: "naver" });
return;
}
}

// [현대H몰]
// - originSite 내 hmall/hyundaihmall 링크가 있을 때만 시도
// - slitmCd: (1) 링크의 slitmCd 파라미터 → (2) crawlerOriginId 숫자 블록(백업)
// - 최종 URL: https://www.hmall.com/pd/pda/itemPtc?slitmCd={숫자}
{
const hmallAnchor = originLinks.find(a =>
/hmall\.com|hyundaihmall\.com/i.test(a.href || "")
);

if (hmallAnchor && hmallAnchor.href) {
let slitmCd = null;

// 1) 링크 쿼리 파라미터에서 slitmCd 우선 추출
try {
const u = new URL(hmallAnchor.href);
const q = getParamInsensitive(u.searchParams, "slitmCd");
if (q && /^\d{6,}$/.test(q)) {
slitmCd = q;
}
} catch (_) { /* ignore */ }

// 2) 백업: crawlerOriginId 셀 텍스트에서 숫자 블록 추출
if (!slitmCd) {
const crawlerCell = rowEl.querySelector("#crawlerOriginId, [id='crawlerOriginId']");
if (crawlerCell) {
const raw = (crawlerCell.textContent || "").trim(); // 예: "2088774877,2088774877,00001"
const m = raw.match(/(\d{6,})/);
if (m) slitmCd = m[1];
}
}

if (slitmCd) {
const hmallUrl = `https://www.hmall.com/pd/pda/itemPtc?slitmCd=${slitmCd}`;
window.open(hmallUrl, "_blank");
sendResponse({ ok: true, site: "hmall", slitmCd });
return;
}
}
}

// [보리보리]
// - originSite 내 링크가 "https://m.boribori.co.kr/" 로 시작할 때만 시도
// - 해당 "전체 URL"을 크롬 시크릿 창(Incognito)으로 열기
{
const boriboriAnchor = originLinks.find(a =>
(a && a.href && a.href.startsWith("https://m.boribori.co.kr/"))
);

if (boriboriAnchor && boriboriAnchor.href) {
chrome.runtime.sendMessage(
{ action: "open_incognito_url", url: boriboriAnchor.href },
(resp) => {
if (resp && resp.ok) {
sendResponse({ ok: true, site: "boribori", incognito: true });
} else {
sendResponse({ ok: false });
}
}
);
return; // 비동기 응답 유지
}
}

// [G마켓]
// - originSite에 http://www.gmarket.co.kr/ 링크 있을 때
// - crawlerOriginId 셀에서 "825118604,6355311307" 형태의 텍스트 추출
// - 쉼표 앞 첫 숫자만 goodscode로 사용
{
const gmarketAnchor = originLinks.find(a =>
a && a.href && a.href.startsWith("http://www.gmarket.co.kr/")
);

if (gmarketAnchor) {
// crawlerOriginId 셀 찾기
const crawlerCell = rowEl.querySelector('#crawlerOriginId');
if (crawlerCell) {
const raw = (crawlerCell.textContent || "").trim(); // "825118604,6355311307"

// 쉼표 앞 숫자만 추출
const match = raw.match(/^(\d{6,})/);
if (match && match[1]) {
const firstId = match[1]; // 825118604
const url = `https://item.gmarket.co.kr/Item?goodscode=${firstId}`;

window.open(url, "_blank"); // 일반 탭
sendResponse({ ok: true, site: "gmarket", goodscode: firstId });
return;
}
}
}
}

// 여기까지 오면 변환 대상 링크가 없거나 파싱 실패
sendResponse({ ok: false });
return;

} catch (e) {
sendResponse({ ok: false });
return;
}

});

return true; // 비동기 응답 유지
}

});

// Admin 전체 메인 실행
function main() {

if (isAdminPage()) {

// 페이지 처음 열릴 때 Admin 정보 불러오기
onAdminRouteChange();

// Admin은 hash(#/matching/1234) 기반 네비게이션이라
// 상품 클릭할 때마다 이 이벤트가 꼭 필요함
window.addEventListener("hashchange", onAdminRouteChange);

// Admin 화면은 AJAX 갱신이 많기 때문에
// DOM 변화를 계속 감시해야 버튼/값이 유지됨
// [수정] rAF는 백그라운드에서 정지될 수 있어 setTimeout(디바운스)로 전환
let moTimer = null;
const mo = new MutationObserver(() => {
if (moTimer) clearTimeout(moTimer);
moTimer = setTimeout(onAdminRouteChange, 80);
});

mo.observe(document.body, {
childList: true,
subtree: true,
attributes: true,
});
// 방문설치 상태 해제
window.addEventListener("beforeunload", () => {
chrome.storage.local.set({ __ext_installation_type: "NONE" });
chrome.storage.local.remove(["__ext_installation_seen_at"]);
});
}
}

//DOM 로딩 이후 main 실행
if (document.readyState === "loading") {
document.addEventListener("DOMContentLoaded", main);
} else {
main();
}

})();

// ===============================================================
// expiry-date.js
// 유통기한 배너/컬러링 기능
// ===============================================================

(function () {

  // ============================================================
  // 시트 연동 — 유통기한 배너 룰 캐시
  // ============================================================
  let __expiry_banner_rules__ = null;

  function __loadExpiryBannerRules(cb) {
    chrome.storage.local.get(["expiry_banner_rules"], (res) => {
      __expiry_banner_rules__ = Array.isArray(res.expiry_banner_rules)
        ? res.expiry_banner_rules : [];
      if (typeof cb === "function") cb();
    });
  }
  __loadExpiryBannerRules();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.expiry_banner_rules) {
      __expiry_banner_rules__ = Array.isArray(changes.expiry_banner_rules.newValue)
        ? changes.expiry_banner_rules.newValue : [];
    }
  });


  // ===============================================================
  // 1. 페이지 열리자마자 1회 실행
  // ===============================================================
  function earlyScan() {
    if (!document.body) return;

    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT
    );

    let node;
    let count = 0;

    while ((node = walker.nextNode())) {
      const text = node.nodeValue;
      if (!text) continue;

      if (
        text.includes("소비") ||
        text.includes("유통") ||
        /\d{2,4}[./-]\d{1,2}/.test(text)
      ) {
        highlightInteractive(node); // CSS highlight만
      }

      if (++count > 300) break; // CPU 보호
    }
  }

  // 페이지 시작 시 즉시 1회 실행
  //earlyScan(); 삭제 11번가,옥션 느려짐


  // ===============================================================
  // 2. 컬러링 색상
  // ===============================================================
  const COLOR_FUTURE = "#fbff00"; // 미래 5년 이내
  const COLOR_PAST = "#efefef"; // 5년 초과
  const COLOR_OLD_BG = "#595959ff"; // 과거 날짜 배경
  const COLOR_OLD_TEXT = "#ffffffff"; // 과거 날짜 글씨


  // ===============================================================
  // 3. 전각 숫자 → 반각 숫자 변환 (１０ → 10)
  // ===============================================================
  function normalizeText(s) {
    if (!s) return s;
    return s.replace(/[０-９]/g, ch =>
      String.fromCharCode(ch.charCodeAt(0) - 0xFEE0)
    );
  }

  // ===============================================================
  // 5. 블랙리스트 사이트 (시트 연동)
  //  - storage 키: __blacklist_site (string[])
  //  - Url 접두사로 startsWith 평가
  // ===============================================================
  let __blacklist_site = null;

  // storage에서 최신 리스트 반영
  function __ext_loadBlacklistSite(cb) {  // ← 함수명만 변경(단수, S 없음)
    try {
      chrome.storage.local.get(["BlacklistSite"], (res) => {
        __blacklist_site = (res.BlacklistSite || []).map(s => String(s || "").trim());
        if (typeof cb === "function") cb(); // 성공 시에도 콜백 호출
      });
    } catch {
      __blacklist_site = [];
      if (typeof cb === "function") cb();
    }
  }


  function isBlacklistSite() {
    const href = location.href;
    const list = Array.isArray(__blacklist_site) ? __blacklist_site : [];
    const hardHit = list.some(u => href.startsWith(u));

    // ⭐ 유통기한 전용 예외:
    // - 쿠팡은 블랙리스트에 있어도 "완전 차단"에서 제외 → 컬러링은 계속 허용
    // - 배너는 기존 makeBanner()에서 쿠팡 비노출이 이미 적용됨
    if (hardHit && location.hostname.endsWith("coupang.com")) {
      return false;
    }
    return hardHit;
  }

  // 최초 1회 로드
  __ext_loadBlacklistSite();

  // 동기화/변경 즉시 반영
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.BlacklistSite) {
      __blacklist_site = (changes.BlacklistSite.newValue || []).map(s => String(s || "").trim());
    }
  });

  // ===============================================================
  // 6. 블랙리스트 영역
  // 배너 O , 영역 컬러링만 X
  // ===============================================================
  const BLACKLIST_ZONES = [
    "div[class*='GBT']",  // 네이버 쿠폰 영역

    // =====================
    // 네이버 팜스토어 추천/묶음 상품 영역 (유통기한 제외)
    // =====================
    ".fCEg6dDK_j",

    // =====================
    // 롯데마트 리뷰 전체 영역 (유통기한 제외)
    // =====================
    "[data-test='bop-reviews-container']",

    // 옥션 제외구역
    ".box__txt-information",
    ".box__extra-information",
    ".box__layer-delivery-info",

    // [스마트스토어 팜스토어] 함께 구매하기/슬롯 리스트(안정: 속성기반)
    "[data-shp-inventory='together']",
    "[data-shp-area^='together']",   // together.pd, together.mylist 등 전체 차단
    ".yvHtFsGXSz",                    // (동적으로 바뀌는 경우가 있어 보조로 추가)

    // [스마트스토어] AI 리뷰요약/리뷰 토픽 필터 영역
    "[data-shp-inventory='revlist']",
    ".kN8yxR0dw4",                    // AI 리뷰요약 상단 래퍼(보조)
    ".t58CVFijk8",                    // 리뷰 토픽/필터 컨테이너(보조)

    // =====================
    // [브랜드스토어] '다른 구성 골라 담아' 추천 슬롯 전체 제외
    //  - 안정: 속성 기반 (othr.* 전역 차단)
    //  - 보조: 현재 DOM 클래스(변경될 수 있어 보조로만 사용)
    // =====================
    "[data-shp-inventory='othr']",
    "[data-shp-area^='othr.']",
    ".YJ5KtpTRrX", // 섹션 래퍼(보조)
    ".ZiGMALtlGM", // 리스트 UL(보조)
    ".ECPK8hDyX1"  // 리스트 LI(보조)
  ];
  function isInsideBlockedZone(node) {
    if (!node || !node.parentElement) return false;
    return BLACKLIST_ZONES.some(sel => node.parentElement.closest(sel));
  }

  // ===============================================================
  // 7. [리뷰 / 문의 컨테이너] — 스캔 단계에서 완전 제외
  //    (날짜 + 키워드 전부 차단, 배너와 무관)
  // ===============================================================
  const REVIEW_BLOCK_CONTAINERS = [
    // =====================
    // 쿠팡
    // =====================
    ".sdp-review",
    ".product-question",
    "#btf-qna",                  // 쿠팡 Q&A 섹션 id
    // =====================
    // 네이버 스마트스토어
    // =====================
    ".mBAnjcgCAm", // Q&A 본문 (유통기한 문장)
    "._KZYoIkWz3", // 리뷰이벤트 배너
    ".PKOHGAVVrm", // 네이버 리뷰이벤트 (다른 클래스 버전)
    "[data-shp-contents-type='review']", // 스토어픽/리뷰 카드
    ".zAX67kpex5", // 리뷰 카드 전체
    ".ysDyZDZUJu", // 문의 날짜 영역
    ".JZWzuE6Wry", // 스토어픽 li
    "[data-shp-contents-type='review']",

    // =====================
    // 네이버 윈도우
    // =====================
    ".YfYso7QHys",
    ".KYZyDeYO6p",
    ".urMwfIJQ0c",

    // =====================
    // 지마켓
    // =====================
    ".tb_qna", // 문의 테이블
    "tr[id^='qna_']", // 문의 row

    // =====================
    // 옥션
    // =====================
    ".box__info",

    // =====================
    // 11번가
    // =====================
    ".review",
    ".qna",
    "li.review_list_element",           // 11번가 리뷰 카드 루트
    ".c_product_review_cont",           // 11번가 리뷰 본문 컨테이너
    ".c_product_reviewer",              // 11번가 리뷰 작성자 블록
    ".c_product_review_thumbnail2",     // 11번가 리뷰 썸네일 리스트 (보조)

    // =====================
    // 네이버 팜스토어 / 네이버 윈도우
    // 리뷰 토픽 버튼(#유통기한 등) UI 영역
    // =====================
    ".eg-flick-viewport",
    ".eg-flick-camera",
    ".eg-flick-panel",

    // =====================
    // 무신사 (Musinsa)
    // - 상품문의 / 후기 요약 / 별점 표시 등 전부 제외
    // =====================
    "section[data-section-name='prd_inquire']",                 // 상품문의 섹션 전체
    ".UIList__Wrap-sc-1ogtw3x-0[data-section-name='prd_inquire']",
    ".UIList__List-sc-1ogtw3x-1",                               // 문의 리스트 UL
    ".UIList__Box-sc-1ogtw3x-4",                                // 문의 LI
    ".UIList__Question-sc-1ogtw3x-6",                           // 문의 박스

    ".ReviewSummary__Wrap-sc-p64drh-1",                         // 상세 상단 요약(별점/후기수)
    ".ReviewStarScore__Container-sc-1ba4cma-0",                 // 별점 컨테이너
    ".GoodsReviewTitle__Container-sc-wp7nul-0",                 // 후기 타이틀/별점 컨테이너
    ".GoodsReviewTitle__TitleContainer-sc-wp7nul-1"             // 후기 타이틀 내부 래퍼
  ];


  function isInsideReviewContainer(node) {
    const el = node?.parentElement;
    if (!el) return false;

    // =====================
    // 옥션(auction.co.kr) — [예외]
    // "상품 정보 제공 고시" 블록은 리뷰/문의 영역이 아님
    //  - div#divOfficialNotice.prodnoti ... 안쪽
    //  - ul#ucOfficialNotice_ulMain.prodnoti_lst 안쪽
    // 상위에 .box__info 가 있어도 여기만큼은 스캔 허용
    // =====================
    if (
      location.href.includes("auction.co.kr") &&
      (el.closest("#divOfficialNotice") || el.closest("ul.prodnoti_lst") || el.closest("#ucOfficialNotice_ulMain"))
    ) {
      return false;
    }

    return REVIEW_BLOCK_CONTAINERS.some(sel => el.closest(sel));
  }


  // ===============================
  // 8. [11번가] 리뷰/문의 영역 식별 헬퍼
  // ===============================
  function is11stReviewZone(node) {
    if (!location.href.includes("11st.co.kr")) return false;
    const el = node?.nodeType === Node.TEXT_NODE ? node.parentElement : node;
    if (!el) return false;

    // 직접 매칭되는 리뷰/문의/요약/썸네일/판매자답글 영역
    const direct =
      el.closest(".prdc_bbs") ||                 // Q&A 테이블
      el.closest(".qna") ||                      // 문의 컨테이너
      el.closest(".review") ||                   // 리뷰 컨테이너(있는 페이지도 있음)
      el.closest(".cont_text_wrap") ||           // 리뷰 본문
      el.closest("dl.c_product_review_rate3") || // 리뷰 요약 점수 DL
      el.closest(".c_product_review_rate3") ||   // 리뷰 요약 점수 컨테이너
      el.closest(".c_product_review_thumbnail2") || // 리뷰 썸네일 리스트
      el.closest(".c_product_review_seller") ||  // 판매자 답글
      el.closest("[data-log-actionid-area='review_detail']") || // 리뷰 상세 썸네일 버튼 영역
      el.closest("li.review_list_element") ||    // [추가] 11번가 리뷰 카드 루트
      el.closest(".c_product_review_cont") ||    // [추가] 11번가 리뷰 본문 컨테이너
      el.closest(".c_product_reviewer");         // [추가] 11번가 리뷰 작성자 블록

    if (direct) return true;

    // 컨테이너 휴리스틱: 같은 .cont 내부에 리뷰 관련 블럭이 함께 있으면 리뷰 영역으로 간주
    const cont = el.closest("div.cont");
    if (
      cont && (
        cont.querySelector(".cont_text_wrap") ||
        cont.querySelector(".c_product_review_thumbnail2") ||
        cont.querySelector(".c_product_review_seller") ||
        cont.querySelector("dl.c_product_review_rate3") ||
        cont.querySelector(".c_product_review_rate3") ||
        cont.closest("li.review_list_element") ||    // .cont가 리뷰 카드 안에 있으면 리뷰로 간주
        cont.closest(".c_product_review_cont")       // .cont가 리뷰 본문 컨테이너 안이면 리뷰로 간주
      )
    ) {
      return true;
    }

    return false;
  }


  // ===============================================================
  // 9. 블랙리스트 사이트면 기능 즉시 종료
  // ===============================================================
  if (isBlacklistSite()) {
    console.log("[GLOBAL] 블랙리스트 사이트 → 기능 중단");
    return;
  }


  // ===============================================================
  // 10. 문자 공백 정리
  // ===============================================================
  const tnorm = (s) => (s || "").replace(/\s+/g, " ").trim();

  // ===============================================================
  // 11. 오늘 날짜(00시 기준)
  // ===============================================================
  function todayMidnight() {
    const n = new Date();
    return new Date(n.getFullYear(), n.getMonth(), n.getDate());
  }

  const PUNCT = "[\\s,.:/\\-·]*"; // 날짜 중간에 들어갈 수 있는 문자들
  const TRAIL = "(?=$|[^0-9])"; // 숫자 뒤에 문장부호 있어도 인식


  // ===============================================================
  // 12.컬러링 제외 키워드 (근처 40글자 안에 있으면 제외)
  // ===============================================================
  const EXCLUDE_NEAR = [
    "쿠팡상품번호",
    "상품번호",
    "출시년월",
    "모델명",
    "등록일",
    "kcal",
    "A/S 책임자",
    "동일 모델의 출시연월",
    "최종정보수정일",
    "제조사/원산지",
    "상품코드",
    "소비자상담 관련 전화번호",
    "보내실곳",
    "cm",
    "mm",
    "인증번호",
    "인증정보",
    "전화번호",
    "oz",
    "도착 예정",
    "kg",
    "g",
    "X",
    "안전기준적합확인신고번호 또는 안전확인대상 생활화학제품승인번호",
    "만원",
    "%"
  ];

  const EXCLUDE_RE = new RegExp(
    EXCLUDE_NEAR
      .map(w => w.replace(/[\s]/g, "")
        .split(/(?=[가-힣A-Za-z])/)
        .join(PUNCT))
      .join("|"),
    "i"
  );

  const EX_RANGE = 40; // 주변 40글자 검사

  // ===============================================================
  // 바로 인접할 때만 제외
  //  - 예: 3.6kg, 20cm, 12oz, 100kcal → 제외(O)
  //  - 예: ...kg ... (멀리 떨어져 있으면) → 제외(X)
  // ===============================================================
  const UNIT_TOKENS = ["kg", "cm", "oz", "kcal", "g", "X", "mm", "모델명", "%"];

  // 안전한 정규식 이스케이프 (특수문자 포함 단위 토큰 보호)
  function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

  // 숫자 뒤에 단위가 즉시(공백 허용) 오는지 검사: 텍스트의 end 이후
  //  - \b(단어경계) 대신 "다음 문자가 단어가 아님" 경계로 변경
  //  - 단어문자: 0-9 A-Za-z 가-힣 _
  const WORD_BREAK_AFTER = '(?=$|[^0-9A-Za-z가-힣_])';
  const UNIT_ALT = UNIT_TOKENS.map(escapeRe).join("|");
  const UNIT_ADJ_AFTER_RE = new RegExp(`^\\s*(?:${UNIT_ALT})${WORD_BREAK_AFTER}`, "i");

  // 숫자 앞에 단위가 즉시(공백 허용) 오는지 검사: 텍스트의 start 이전
  const UNIT_ADJ_BEFORE_RE = new RegExp(`(?:${UNIT_ALT})\\s*$`, "i");

  // '근처(40글자)'에서 단위 단어가 보이는지 (PUNCT 허용) — near검사용
  //  - near용은 "토큰 전체가 보이는지"만 확인하므로 escape 없이 문자 단위 분해 유지
  const UNIT_NEAR_SRC = UNIT_TOKENS.map(u => u.split("").join(PUNCT)).join("|");
  const UNIT_NEAR_RE = new RegExp(UNIT_NEAR_SRC, "i");
  const UNIT_NEAR_RE_G = new RegExp(UNIT_NEAR_SRC, "ig");

  function isUnitAdjacent(text, start, end) {
    const after = (text.slice(end) || "").replace(/^\s+/, "");
    const before = (text.slice(0, start) || "").replace(/\s+$/, "");
    return UNIT_ADJ_AFTER_RE.test(after) || UNIT_ADJ_BEFORE_RE.test(before);
  }

  // ===============================================================
  // 13. 컬러링 되는 키워드
  // ===============================================================
  const KEYWORDS = [
    "임박",
    "소비기한", "소비 기한",
    "유통기한", "유통 기한",
    "유효기간", "유효 기간",
    "유효일",
    "사용기간", "사용 기간",
    "유통일자", "유통 일자",
    "개봉 후 사용기간",
    "사용기한 또는",
    "품질유지기한",
    "사용기한"
  ];

  const keywordRe = new RegExp(
    `(${KEYWORDS.map(k => k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|")})`,
    "gi"
  );

  // ===============================================================
  // 14. 컬러링 되는 날짜 형식
  // ===============================================================
  const dateRes = [
    // ② YYYY년 MM월 DD일
    new RegExp(`\\b((?:19|20)?\\d{2}${PUNCT}년${PUNCT}\\d{1,2}${PUNCT}월${PUNCT}\\d{1,2}${PUNCT}일)`, "g"),

    // ⭐ YYYY년 MM월 (일자 없음) — 인터랙티브 경로에서도 잡히도록 추가
    new RegExp(`\\b((?:19|20)?\\d{2}${PUNCT}년${PUNCT}\\d{1,2}${PUNCT}월)(?!${PUNCT}\\d)`, "g"),

    // ③ YYYY-MM-DD / YYYY.MM.DD / YYYY/MM/DD
    new RegExp(`\\b((?:19|20)?\\d{2}${PUNCT}\\d{1,2}${PUNCT}\\d{1,2})${TRAIL}`, "g"),

    // ④ 25.09.27 (두자리년도)
    new RegExp(`\\b(\\d{2}\\.\\d{2}\\.\\d{2})${TRAIL}`, "g"),

    // ⭐ [신규] MM.DD (월.일) → 올해로 간주 (예: 02.04 = 올해 2/4)
    //   - 첫 번째는 01~12 월만 허용
    //   - 두 번째는 01~31 일만 허용
    //   - 뒤에 .숫자(세번째 조각)가 오면 제외(이미 Y.M.D가 잡음)
    new RegExp(`\\b((?:0?[1-9]|1[0-2])${PUNCT}(?:0?[1-9]|[12]\\d|3[01]))(?!${PUNCT}\\d)`, "g"),

    // ⑤ 250927 / 20250927
    new RegExp(`(?<!\\d)(\\d{6}|\\d{8})${TRAIL}`, "g"),

    // ⑥ YYYY.MM 또는 YY.MM (→ 말일 처리)
    new RegExp(`\\b((?:19|20)?\\d{2}\\.\\d{1,2})(?!\\.\\d)`, "g"),
    new RegExp(`\\b(\\d{2}\\.\\d{1,2})(?!\\.\\d)`, "g"),

    // ⑦ YYYY-MM
    new RegExp(`\\b((?:19|20)?\\d{2}[-/]\\d{1,2})(?![-/]\\d)`, "g")
  ];


  // ===============================================================
  // 15. 텍스트에서 날짜를 '실제 날짜'로 바꾸는 함수
  // ===============================================================
  function parseYMD(s) {
    let m;

    // YYYY년 MM월 DD일
    m = s.match(/^(?:\s*)((?:19|20)?\d{2})\s*년\s*(\d{1,2})\s*월\s*(\d{1,2})\s*일/);
    if (m && validYMD(normalYear(m[1]), +m[2], +m[3]))
      return { y: normalYear(m[1]), m: +m[2], d: +m[3] };

    // YYYY년 MM월 → 말일로 처리
    m = s.match(/^(?:\s*)((?:19|20)?\d{2})\s*년\s*(\d{1,2})\s*월/);
    if (m && validYM(normalYear(m[1]), +m[2])) {
      const y = normalYear(m[1]);
      const mo = +m[2];
      const lastDay = new Date(y, mo, 0).getDate(); // 말일
      return { y, m: mo, d: lastDay };
    }

    // 공백/한글 제거한 버전 (공통)
    const clean = s.replace(/\s|년|월|일/g, "").replace(/·/g, ".");

    // ⭐ [신규] MM.DD (월.일) → 올해로 간주
    //  - 첫 번째: 1~12
    //  - 두 번째: 1~31
    //  - 유효한 날짜만 반환
    m = clean.match(/^((?:0[1-9]|1[0-2])[.\-\/](?:0[1-9]|[12]\d|3[01]))$/);
    if (m) {
      const [mmStr, ddStr] = m[1].split(/[.\-\/]/);
      const mm = parseInt(mmStr, 10);
      const dd = parseInt(ddStr, 10);
      const y = todayMidnight().getFullYear();

      if (validYMD(y, mm, dd)) {
        return { y, m: mm, d: dd };
      }
    }

    // YYYY-MM-DD / YYYY.MM.DD / YYYY/MM/DD
    m = clean.match(/^((?:19|20)?\d{2})[.\-\/](\d{1,2})[.\-\/](\d{1,2})$/);
    if (m && validYMD(normalYear(m[1]), +m[2], +m[3]))
      return { y: normalYear(m[1]), m: +m[2], d: +m[3] };

    // 250927 / 20250927
    m = clean.match(/^(\d{8}|\d{6})$/);
    if (m) {
      const t = m[1];
      let y, mo, da;
      if (t.length === 8) {
        y = +t.slice(0, 4);
        mo = +t.slice(4, 6);
        da = +t.slice(6, 8);
      } else {
        y = normalYear(t.slice(0, 2));
        mo = +t.slice(2, 4);
        da = +t.slice(4, 6);
      }
      if (validYMD(y, mo, da))
        return { y, m: mo, d: da };
    }

    // YYYY-MM or YYYY.MM → 말일로 처리
    m = clean.match(/^((?:19|20)?\d{2})[.\-\/](\d{1,2})$/);
    if (m && validYM(normalYear(m[1]), +m[2])) {
      const y = normalYear(m[1]);
      const mo = +m[2];
      const lastDay = new Date(y, mo, 0).getDate(); // 말일
      return { y, m: mo, d: lastDay };
    }

    return null;
  }

  function normalYear(y) {
    return String(y).length === 2 ? 2000 + (+y) : +y;
  }

  function validYM(y, m) {
    return y >= 1900 && y <= 2099 && m >= 1 && m <= 12;
  }

  function validYMD(y, m, d) {
    if (!validYM(y, m)) return false;
    const dt = new Date(y, m - 1, d);
    return dt.getFullYear() === y &&
      dt.getMonth() + 1 === m &&
      dt.getDate() === d;
  }

  function toDate(obj) {
    return new Date(obj.y, obj.m - 1, obj.d || 1);
  }


  // ===============================================================
  // 16. 특정 텍스트 주변에 “컬러링 하면 안 되는 단어”가 있는지 검사
  // ===============================================================
  function hasExcludedAround(text, start, end, node) {

    const left = Math.max(0, start - EX_RANGE);
    const right = Math.min(text.length, end + EX_RANGE);
    const slice = text.slice(left, right);

    // 근처(40글자)에 제외 단어가 있으면 컬러링 금지
    // ➜ 단, 'kcal/cm/oz/kg'만 보이는 경우에는 "바로 인접"일 때만 제외
    if (EXCLUDE_RE.test(slice)) {
      // 단위 단어만으로 인한 매치인지 판정 (단위를 제거하고 다시 검사)
      const sliceNoUnits = slice.replace(UNIT_NEAR_RE_G, "");
      const hasOtherExcl = EXCLUDE_RE.test(sliceNoUnits);

      if (hasOtherExcl) {
        // 단위 외 다른 제외어가 있으면 그대로 제외
        return true;
      } else if (UNIT_NEAR_RE.test(slice)) {
        // 단위만 보이는 경우 → '바로 인접'할 때만 제외
        if (isUnitAdjacent(text, start, end)) {
          return true;
        }
        // 단위가 근처에 있지만 인접하지 않다면 제외하지 않음(계속 진행)
      }
    }

    // 부모·이전·다음 텍스트까지 확인(더 정확하게)
    const p = node?.parentElement?.textContent || "";
    const prev = node?.previousSibling?.textContent || "";
    const next = node?.nextSibling?.textContent || "";
    const around = prev + p + next;

    // 부모·형제 텍스트까지 포함한 'around'에서도 같은 규칙 적용
    if (EXCLUDE_RE.test(around)) {
      const aroundNoUnits = around.replace(UNIT_NEAR_RE_G, "");
      const hasOtherExcl = EXCLUDE_RE.test(aroundNoUnits);

      if (hasOtherExcl) {
        return true;
      } else if (UNIT_NEAR_RE.test(around)) {
        if (isUnitAdjacent(text, start, end)) {
          return true; // 단위가 '바로 인접'한 경우에만 제외
        }
      }
    }
    // =====================================================
    // 17. 리뷰 / 문의 영역 DOM 기준 차단
    // =====================================================

    const el = node.parentElement;
    if (!el) return false;

    // =====================================================
    // 최종정보수정일 문구 옆 날짜 컬러링 제외
    // =====================================================
    {
      // 라벨과 값이 보통 같이 놓이는 '부모 컨테이너'만 대상으로 잡기
      // (span은 현재 값 노드일 수 있어 제외)
      const container = el.closest(".seller_update, .sellerUpdate, p, div, td, dd, li");
      if (container) {
        // 컨테이너 안의 텍스트 노드를 앞에서부터 훑어서,
        // '현재 node'에 도달하기 전까지의 텍스트를 priorText로 누적
        let priorText = "";
        const tw = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
        let cur;
        while ((cur = tw.nextNode())) {
          if (cur === node) break;     // 현재 매치 텍스트 직전까지만 누적
          priorText += cur.nodeValue || "";
        }

        // 공백 제거 후 "최종정보수정일"이 있었으면 컬러링 제외
        const priorPacked = priorText.replace(/\s+/g, "");
        if (/최\s*종\s*정\s*보\s*수\s*정\s*일/i.test(priorPacked)) {
          return true;
        }
      }
    }

    // =====================
    // 18. 11번가 리뷰/문의 영역 차단
    // =====================
    if (is11stReviewZone(node)) {
      return true;
    }

    if (
      el.closest(".sdp-review") || // 쿠팡 리뷰 영역
      el.closest("[class*='review']") || // 공통 리뷰 클래스
      el.closest("[id*='review']") || // review 들어간 id
      el.closest("[class*='qna']") || // 문의(Q&A)
      el.closest("[id*='qna']") || // 문의(Q&A)
      el.closest("tr[id^='qna_']") || // 지마켓 문의 tr
      el.closest("[class*='inquiry']") || // inquiry(문의)
      el.closest("[class*='comment']") // 댓글/후기
    ) {
      return true; // 
    }

    // ─────────────────────────────
    // 19. 상품번호 행 전체 차단 (네이버)
    // ─────────────────────────────
    const row = node.parentElement?.closest("tr");
    if (row && row.textContent.includes("상품번호")) {
      return true;
    }

    // ─────────────────────────────
    // [추가] 리스트 항목(li) 라벨(.stit 등) 기반 제외
    //  - 예: <li><span class="stit">상품번호</span><span class="cont">F231208419</span></li>
    // ─────────────────────────────
    const li = node.parentElement?.closest("li");
    if (li) {
      // 자주 쓰이는 라벨 클래스 후보들
      const labelEl = li.querySelector(".stit, .title, .tit, .label, .key, .th, .hd, [data-role='label']");
      if (labelEl) {
        const labelText = (labelEl.textContent || "").replace(/\s+/g, "");
        if (EXCLUDE_RE.test(labelText)) {
          return true;
        }
      }
    }

    // ─────────────────────────────
    // [추가] DL 구조(dt/dd)에서도 dt가 제외 키워드면 dd 전체 제외
    // ─────────────────────────────
    const dd = node.parentElement?.closest("dd");
    if (dd) {
      const dt = dd.previousElementSibling && dd.previousElementSibling.tagName === "DT"
        ? dd.previousElementSibling
        : null;
      if (dt) {
        const dtText = (dt.textContent || "").replace(/\s+/g, "");
        if (EXCLUDE_RE.test(dtText)) {
          return true;
        }
      }
    }

    // ─────────────────────────────
    // 인라인 라벨-값 구조(같은 컨테이너 안에서 라벨 텍스트가
    // '앞에' 오고, 값(날짜/숫자)이 '뒤에' 오는 패턴) 차단
    //  - 예: <div class="seller_update">최종정보수정일 <span>2026-01-05</span></div>
    //  - 또는 <p>최종정보수정일: <em>2026.01.05</em></p>
    // ─────────────────────────────
    (function () {
      const el = node?.parentElement;
      if (!el) return;

      // 1) 대상 컨테이너: 너무 크게 잡지 말고, 보통 라벨-값이 함께 놓이는 작은 블록 위주
      const container = el.closest(".seller_update, span, p, div, td, dd, li");
      if (!container) return;

      // 2) 컨테이너 내에서 '현재 노드 이전' 형제들만 이어붙여 라벨 부분 텍스트 구성
      let priorText = "";
      const children = Array.from(container.childNodes);
      for (const c of children) {
        if (c === el || c === node) break; // 현재 노드 이전까지만
        priorText += (c.textContent || "");
      }

      // 동일 엘리먼트(el) 안에서도, 현재 텍스트 노드 이전 텍스트를 추가로 더해준다.
      if (el && el.childNodes && el.childNodes.length > 0) {
        let stop = false;
        for (const c of Array.from(el.childNodes)) {
          if (stop) break;
          if (c === node) { stop = true; break; }
          priorText += (c.textContent || "");
        }
      }

      const priorPacked = priorText.replace(/\s+/g, "");

      // 3) "최종정보수정일" 등 제외 키워드가 앞쪽에 있으면 현재 값(날짜/숫자) 컬러링 금지
      //    - 기존 EXCLUDE_RE는 공백/문장부호 변형 허용 정규식이므로 그대로 재사용
      if (EXCLUDE_RE.test(priorPacked)) {
        return true;
      }
    })();

    // ─────────────────────────────
    // 테이블 한 행(tr)에서 th 라벨이 제외 키워드면
    //같은 행 td 값 전부 컬러링 금지
    // ─────────────────────────────
    (function () {
      const tdOrTh = node.parentElement?.closest("td,th");
      if (!tdOrTh) return;

      const tr = tdOrTh.closest("tr");
      if (!tr) return;

      const th = tr.querySelector("th");
      const thText = (th?.textContent || "").replace(/\s+/g, "");
      if (thText && EXCLUDE_RE.test(thText)) {
        return true;
      }
    })();

    // ─────────────────────────────
    //  테이블 행(tr)에서 th(라벨)가 제외 키워드면
    //  같은 행의 td(값) 텍스트는 전부 컬러링 금지
    //  (A/S 책임자, 상품번호 등 라벨-값 구조 대응)
    // ─────────────────────────────
    const td = node.parentElement?.closest("td,th");
    if (td) {
      const tr = td.closest("tr");
      if (tr) {
        // 같은 행의 th 텍스트 수집
        const th = tr.querySelector("th");
        const thText = (th?.textContent || "").replace(/\s+/g, "");
        if (thText && EXCLUDE_RE.test(thText)) {
          return true;
        }
      }
    }

    return false;
  }


  // ===============================================================
  // 20. "대화형(인터랙티브) 영역"인지 확인
  // 버튼/입력창/접었다펼치는 영역 등은 건드리면 깨짐
  // → DOM 수정 금지 / CSS 하이라이트만 사용함
  // ===============================================================
  function isInteractive(node) {
    if (!node?.parentElement) return false;
    const p = node.parentElement;

    // a[href] = 상품명 링크 → 허용
    if (p.closest("a[href]")) return false;

    // 버튼/입력창/폼 등은 DOM 변경 금지
    if (
      p.closest("button, input, select, option, textarea, label, summary, details, form") ||
      p.closest("[contenteditable=''], [contenteditable='true']") ||
      p.closest("[role='button'], [role='tab'], [role='listbox'], [role='option']")
    ) return true;

    return false;
  }

  // ===============================================================
  // 21. CSS 하이라이트 스타일(한 번만 추가)
  // ===============================================================
  function ensureCSSHighlight() {
    if (document.getElementById("__ext_css_highlight__")) return;

    const st = document.createElement("style");
    st.id = "__ext_css_highlight__";
    st.textContent =
      "::highlight(__ext_future){background:#fbff00 !important;}" +
      "::highlight(__ext_past){background:#efefef !important;}";

    document.documentElement.appendChild(st);
  }

  // ===============================================================
  // 22. CSS 하이라이트 적용
  // ===============================================================
  function addCSSRange(node, start, end, isPast) {
    if (!window.CSS?.highlights) return false;
    try {
      const range = document.createRange();
      range.setStart(node, start);
      range.setEnd(node, end);

      const key = isPast ? "__ext_past" : "__ext_future";
      let set = CSS.highlights.get(key);

      if (!set) {
        set = new Highlight();
        CSS.highlights.set(key, set);
      }

      set.add(range);
      return true;
    } catch {
      return false;
    }
  }

  // ===============================================================
  // 23. 한 텍스트 노드에서 여러 개 컬러링 처리
  // ===============================================================
  function addCSSRanges(node, list) {
    if (!window.CSS?.highlights) return false;
    let ok = false;

    for (const r of list) {
      if (addCSSRange(node, r.s, r.e, r.past)) ok = true;
    }
    return ok;
  }


  // ===============================================================
  // 24. 인터랙티브 영역 전용 컬러링 방식
  // ===============================================================
  function highlightInteractive(node) {
    if (isInsideReviewContainer(node)) return;
    // ⭐ 블랙리스트 영역(예: 옥션 배송예측)에서는 인터랙티브 하이라이트도 금지
    if (isInsideBlockedZone(node)) return;

    const text = normalizeText(node.nodeValue);
    if (!text) return;
    // ===============================
    // [네이버 쇼핑하기] 프로모션 기간 문구 줄 전체 제외 (인터랙티브 경로)
    // ===============================
    if (location.hostname.includes("search.shopping.naver.com")) {
      const promoRangeRe = /\[[^\]]*(?:\d{1,2}\s*[./]\s*\d{1,2}\s*~\s*\d{1,2}\s*[./]\s*\d{1,2})[^\]]*\]/;
      if (promoRangeRe.test(text)) return;

      const el = node.parentElement;

    }
    const matches = [];

    const today = todayMidnight();

    // 키워드 컬러링
    keywordRe.lastIndex = 0;
    let km;
    while ((km = keywordRe.exec(text))) {
      const start = km.index;
      const end = start + km[0].length;

      // 컨텍스트: 매치 시작 앞 4글자부터 매치 끝까지 확인(띄어쓰기/잡공백 허용)
      const ctxStart = Math.max(0, start - 4);
      const ctx = text.slice(ctxStart, end);

      // 1) 공통 예외: "매진임박"은 하이라이트 금지
      if (/매\s*진\s*임\s*박/i.test(ctx)) {
        continue;
      }

      // 2) 쿠팡 전용 예외: "품절 임박"은 하이라이트 금지
      // 텍스트 컨텍스트로 1차 차단
      if (/품\s*절\s*임\s*박/i.test(ctx)) {
        continue;
      }
      // DOM 컨텍스트(쿠팡 배지/레드 라인)에서 "품절"+"임박" 같이 있으면 2차 차단
      const el = node.parentElement;
      const coupangOOSBadge =
        el?.closest(".top-badge") ||
        el?.closest(".twc-text-cou-red-700");
      if (coupangOOSBadge) {
        const line = (el.closest("div")?.textContent || text);
        if (/품\s*절/.test(line) && /임\s*박/.test(line)) {
          continue;
        }
      }

      // 예외가 아니면 하이라이트 후보로 추가
      matches.push({ s: start, e: end, past: false });
    }


    // 날짜 컬러링
    for (const re of dateRes) {
      re.lastIndex = 0;
      let m;
      while ((m = re.exec(text))) {
        const full = m[0];
        const core = m[1];

        const start = m.index + full.indexOf(core);
        const end = start + core.length;

        // ⭐ 숫자/날짜 바로 옆에 단위(kcal/cm/oz/kg)가 오면 그 매치만 스킵
        if (isUnitAdjacent(text, start, end)) continue;
        if (hasExcludedAround(text, start, end, node)) continue;

        const parsed = parseYMD(core);
        if (!parsed) continue;

        const d = toDate(parsed);
        const within = (d - today) >= 0 && (d - today) <= (1825 * 86400000);

        // ⭐ interactive에서는 "5년 이내 미래"만 노랑
        if (within) {
          matches.push({ s: start, e: end, past: false });
        }
        // 과거 / 5년 초과는 interactive에서 아예 처리 안 함
      }
    }

    // 실제 CSS 컬러링 적용
    if (matches.length) {
      ensureCSSHighlight();
      addCSSRanges(node, matches);
    }
  }

  // ===============================================================
  // 25. [신세계몰] 상품명(span.cdtl_info_tit_txt) 통합 처리
  // 상품명 안에 섞인 키워드/날짜 전부 기존 로직으로 처리
  // ===============================================================
  function highlightShinsegaeTitle(root) {

    //  네이버 계열 사이트에서는 실행 금지 (리뷰 카운트 깨짐)
    if (location.href.includes("naver.com")) return;

    root.querySelectorAll("span.cdtl_info_tit_txt").forEach(el => {

      // 이미 처리됐으면 스킵
      if (el.__ext_done__) return;
      el.__ext_done__ = true;

      const text = normalizeText(el.textContent || "");
      if (!text) return;

      // 통으로 하나의 TEXT_NODE로 재구성
      el.innerHTML = "";
      const textNode = document.createTextNode(text);
      el.appendChild(textNode);

      // 기존 검증된 로직 그대로 사용
      highlightTextNode(textNode);
    });
  }

  // ===============================================================
  // 26. 문서 안에 있는 "인터랙티브 영역"만 따로 스캔
  // ===============================================================
  function scanInteractive(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    let count = 0;

    while (walker.nextNode()) {
      const node = walker.currentNode;

      // 리뷰/문의 영역 스캔 제외
      if (isInsideReviewContainer(node)) continue;

      // ⭐ 블랙리스트 영역(예: 옥션 배송예측)도 인터랙티브 스캔 제외
      if (isInsideBlockedZone(node)) continue;

      nodes.push(node);
      if (++count > 3000) break;
    }


    for (const n of nodes) {
      if (isInteractive(n)) {
        highlightInteractive(n);
      }
    }
  }

  // ===============================================================
  // 27. HTML 문자 깨지지 않게 변환 (기존 코드에서 빠져있어서 오류남)
  // ===============================================================
  function escapeHtml(str) {
    if (!str) return "";
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }


  // ===============================================================
  // 28. 어떤 노드는 아예 건드리면 안 됨 (스킵 규칙)
  // ===============================================================
  function shouldSkip(node) {

    if (!node || node.nodeType !== Node.TEXT_NODE) return true;
    const p = node.parentElement;
    if (!p) return true;

    const tag = p.tagName;

    // SCRIPT / STYLE / CODE 등은 절대 손대면 안 됨
    if (["SCRIPT", "STYLE", "NOSCRIPT", "CODE"].includes(tag)) return true;

    // 숨김 요소 내부 텍스트는 전부 스킵 (네이버의 숨김 스팬 간섭 제거)
    try {
      const cs = window.getComputedStyle(p);
      if (cs.display === "none" || cs.visibility === "hidden") return true;
    } catch (_) { }

    // 매핑툴 매핑 버튼 / 기존매핑, 매핑하기버튼 스킵 (충돌방지)
    if (p.closest(".existingMappingTag button, .existingMappingTag a, .existingMappingTag [role='button']")) {
      return true;
    }

    // 이미 색칠된 mark 안쪽은 다시 컬러링 금지 (네이버 쿠폰영역 제외)
    if (p.closest("mark[data-ext-expiry]") && !isInsideBlockedZone(node)) {
      return true;
    }

    // 배너 안쪽은 건드리면 안 됨
    if (p.closest("#__ext_global_banner__")) return true;

    // 네이버 쿠폰영역(GTB)은 컬러링 금지
    if (isInsideBlockedZone(node)) return true;

    // ===============================
    // 11번가 옵션 영역 예외 허용 (리뷰/문의는 제외)
    // ===============================
    if (location.href.includes("11st.co.kr") && node.parentElement) {
      const cont = node.parentElement.closest("div.cont");
      if (cont && !is11stReviewZone(cont)) {
        return false; // shouldSkip 무시 → 컬러링 허용
      }
    }


    // 인터랙티브 영역은 DOM 수정 금지 → CSS 방식으로만 컬러링
    if (isInteractive(node)) {
      const parent = node.parentElement;

      // 상품명 링크는 다시 허용 (네이버, 스마트스토어 등 필요)
      if (
        parent.closest("a.adProduct_link__hNwpz") ||
        parent.closest("a.basicList_link__") ||
        parent.closest("a.basicList_title__")
      ) {
        // 허용
      } else {
        return true;
      }
    }


    return false;
  }


  // ===============================================================
  // 29. [제조일자 / 유효일자 span.cont 전용 날짜 컬러링]
  //      TEXT_NODE 방식 실패하는 구조 강제 처리
  // ===============================================================
  function highlightDateInContSpan(root) {

    const spans = root.querySelectorAll("span.cont");

    spans.forEach(span => {
      // 이미 처리된 경우 스킵
      if (span.querySelector("mark[data-ext-expiry]")) return;

      const text = normalizeText(span.textContent);
      if (!text) return;

      const re = /((?:19|20)?\d{2}\s*년\s*\d{1,2}\s*월\s*\d{1,2}\s*일)/g;
      let m;

      while ((m = re.exec(text))) {

        const walker = document.createTreeWalker(span, NodeFilter.SHOW_TEXT);
        let acc = 0;
        let startNode = null;
        let endNode = null;
        let startOffset = 0;
        let endOffset = 0;

        while (walker.nextNode()) {
          const node = walker.currentNode;
          const len = node.nodeValue.length;

          if (!startNode && acc + len >= m.index) {
            startNode = node;
            startOffset = m.index - acc;
          }

          if (startNode && acc + len >= m.index + m[1].length) {
            endNode = node;
            endOffset = m.index + m[1].length - acc;
            break;
          }

          acc += len;
        }

        if (!startNode || !endNode) return;

        const range = document.createRange();
        range.setStart(startNode, startOffset);
        range.setEnd(endNode, endOffset);

        const parsed = parseYMD(m[1]);
        if (!parsed) return;

        const d = toDate(parsed);
        const today = todayMidnight();
        const past = d < today;

        const mark = document.createElement("mark");
        mark.setAttribute("data-ext-expiry", "1");

        if (past) {
          mark.style.background = COLOR_OLD_BG;
          mark.style.color = COLOR_OLD_TEXT;
        } else {
          mark.style.background = COLOR_FUTURE;
        }


        range.surroundContents(mark);
      }
    });
  }

  // ===============================================================
  // 30. 일반 텍스트 노드 컬러링 (mark)
  // ===============================================================
  function highlightTextNode(node) {

    if (shouldSkip(node)) return;

    const text = normalizeText(node.nodeValue);
    if (!text) return;

    // [네이버 쇼핑하기] 상품명 앵커(a) 내부는 DOM 수정 금지 → CSS 하이라이트 경로로 우회
    if (location.hostname.includes("search.shopping.naver.com")) {
      const el = node.parentElement;
      if (
        el.closest("a.adProduct_link__hNwpz") || // 광고
        el.closest("a.product_link__aFnaq") || // 유기
        el.closest("a.basicList_link__") || // 구형 1
        el.closest("a.basicList_title__")        // 구형 2
      ) {
        highlightInteractive(node);
        return;
      }
    }

    // ===================================================
    // 31. [노드 병합] "YYYY년 MM월" + "DD일" 분리 방지
    // ===================================================
    if (
      node.nextSibling &&
      node.nextSibling.nodeType === Node.TEXT_NODE
    ) {
      const cur = node.nodeValue;
      const next = node.nextSibling.nodeValue;

      // "2026년 03월" + "08일"
      if (
        /\d{4}년\s*\d{1,2}월\s*$/.test(cur) &&
        /^\s*\d{1,2}일/.test(next)
      ) {
        node.nodeValue = cur + " " + next.trim();
        node.nextSibling.remove();
      }
    }


    let html = null;
    const today = todayMidnight();

    // =============================================
    // 32. br / &lt;br&gt; 때문에 텍스트가 쪼개져 날짜 못 찾는 문제
    //     같은 부모 안에서 "이어진 날짜 조각"을 하나로 합쳐서 검사
    // =============================================
    if (
      node.nextSibling &&
      node.nextSibling.nodeType === Node.TEXT_NODE &&
      /[0-9년월일.\-]/.test(node.nodeValue.slice(-4)) &&
      /^[0-9년월일.\-]/.test(node.nextSibling.nodeValue.slice(0, 4))
    ) {
      node.nodeValue = node.nodeValue + " " + node.nextSibling.nodeValue;
      node.nextSibling.remove();
    }

    const dateRes = [

      // ② YYYY년 MM월 DD일
      new RegExp(`\\b((?:19|20)?\\d{2}${PUNCT}년${PUNCT}\\d{1,2}${PUNCT}월${PUNCT}\\d{1,2}${PUNCT}일)`, "g"),

      // ① YYYY년 MM월 (노드 분리된 날짜 컬러링 불가문제로 순서변경)
      new RegExp(`\\b((?:19|20)?\\d{2}${PUNCT}년${PUNCT}\\d{1,2}${PUNCT}월)`, "g"),

      // ③ YYYY-MM-DD / YYYY.MM.DD / YYYY/MM/DD
      new RegExp(`\\b((?:19|20)?\\d{2}${PUNCT}\\d{1,2}${PUNCT}\\d{1,2})${TRAIL}`, "g"),

      // ④ 25.09.27 (두자리년도)
      new RegExp(`\\b(\\d{2}\\.\\d{2}\\.\\d{2})${TRAIL}`, "g"),

      //   [신규] MM.DD (월.일) → 올해로 간주 (예: 02.04 = 올해 2/4)
      //   - 첫 번째는 01~12 월만 허용
      //   - 두 번째는 01~31 일만 허용
      //   - 뒤에 .숫자(세번째 조각)가 오면 제외(이미 Y.M.D가 잡음)
      new RegExp(`\\b((?:0[1-9]|1[0-2])${PUNCT}(?:0[1-9]|[12]\\d|3[01]))(?!${PUNCT}\\d)`, "g"),

      // ⑤ 250927 / 20250927
      new RegExp(`(?<!\\d)(\\d{6}|\\d{8})`, "g"),

      // ⑥ YYYY.MM 또는 YY.MM
      new RegExp(`\\b((?:19|20)?\\d{2}\\.\\d{1,2})(?!\\.\\d)`, "g"),
      new RegExp(`\\b(\\d{2}\\.\\d{1,2})(?!\\.\\d)`, "g"),

      // ⑦ YYYY-MM
      new RegExp(`\\b((?:19|20)?\\d{2}[-/]\\d{1,2})(?![-/]\\d)`, "g")
    ];


    // =====================================================
    // 33. 11번가 리뷰/문의 영역만 정확히 차단
    // =====================================================
    if (is11stReviewZone(node)) {
      return;
    }


    // -----------------------------------------------------------
    // 34. 유통기한 관련 키워드(소비기한, 유통기한 등)
    // -----------------------------------------------------------
    keywordRe.lastIndex = 0;
    if (keywordRe.test(text)) {

      const el = node.parentElement;

      // 11번가 리뷰/문의/요약/판매자답글/썸네일 영역은 전부 키워드 컬러링 금지
      if (is11stReviewZone(el)) {
        // 아무 것도 하지 않음 (키워드 컬러링 차단)
      } else {

        html = (html ?? escapeHtml(text)).replace(
          keywordRe,
          (match, g1, offset) => {
            // [추가] 콜백 내부에서도 11번가 리뷰영역 이중 차단
            // (혹시 바깥 체크가 누락되거나, 동적 DOM 변동 시에도 방지)
            if (is11stReviewZone(node)) { // [추가]
              return escapeHtml(match);   // [추가]
            }                               // [추가]

            // 컨텍스트: 매치 시작점 앞 4글자부터 매치 끝까지 확인
            const ctxStart = Math.max(0, offset - 4);
            const ctxEnd = offset + g1.length;
            const ctx = text.slice(ctxStart, ctxEnd);

            // 1) 공통 예외: "매진임박"은 하이라이트 금지
            if (/매\s*진\s*임\s*박/i.test(ctx)) {
              return escapeHtml(match);
            }

            // 2) [전역 적용] "품절 임박"은 하이라이트 금지 (모든 사이트)
            //    - 텍스트 컨텍스트로 1차 차단
            if (/품\s*절\s*임\s*박/i.test(ctx)) {
              return escapeHtml(match);
            }
            //    - DOM 컨텍스트(쿠팡 배지/레드 라인)는 있는 경우에만 2차 차단
            //      (다른 사이트엔 해당 엘리먼트가 없어도 그냥 통과)
            const coupangOOSBadge =
              el?.closest(".top-badge") ||
              el?.closest(".twc-text-cou-red-700");
            if (coupangOOSBadge) {
              const line = (el.closest("div")?.textContent || text);
              if (/품\s*절/.test(line) && /임\s*박/.test(line)) {
                return escapeHtml(match);
              }
            }

            // 예외가 아니면 기존대로 컬러링
            return `<mark data-ext-expiry="1" style="background:${COLOR_FUTURE};">${escapeHtml(g1)}</mark>`;
          }
        );

      }

    }

    // -----------------------------------------------------------
    // 35. 날짜 컬러링
    // -----------------------------------------------------------
    for (const re of dateRes) {
      re.lastIndex = 0;

      if (re.test(text)) {

        const src = html ?? escapeHtml(text);

        html = src.replace(re, (full, core, offset) => {
          const start = offset + full.indexOf(core);
          const end = start + core.length;

          // 숫자/날짜 바로 옆에 단위(kcal/cm/oz/kg)가 오면 그 매치만 스킵
          if (isUnitAdjacent(text, start, end)) {
            return escapeHtml(full);
          }

          // 제외 단어 근접하면 색칠 금지
          if (hasExcludedAround(text, start, end, node)) {
            return escapeHtml(full);
          }

          const parsed = parseYMD(core);
          if (!parsed) return escapeHtml(full);

          const d = toDate(parsed);
          const past = d < today;
          const within = (d - today) <= (1825 * 86400000);

          // 5년 초과 날짜는 아예 컬러링 안 함
          if (!within) {
            return escapeHtml(full);
          }

          let bg = "";
          let fg = "inherit";

          // 과거 → 검정
          if (past) {
            bg = COLOR_OLD_BG;
            fg = COLOR_OLD_TEXT;
          }
          // 오늘~5년 이내 → 노랑
          else {
            bg = COLOR_FUTURE;
          }

          const before = escapeHtml(full.slice(0, full.indexOf(core)));
          const after = escapeHtml(full.slice(full.indexOf(core) + core.length));

          return `${before}<mark data-ext-expiry="1" style="
background:${bg};
color:${fg};
">${escapeHtml(core)}</mark>${after}`;

        });

        break;
      }
    }

    // -----------------------------------------------------------
    // 36. 실제 DOM 반영
    // -----------------------------------------------------------
    if (html !== null) {
      const span = document.createElement("span");
      span.innerHTML = html;
      node.replaceWith(...span.childNodes);
    }
  }

  // ===============================================================
  // 37. [신세계몰 전용] div.in 텍스트를 하나로
  // ===============================================================
  function highlightShinsegaeInDiv(root) {

    root.querySelectorAll("div.in").forEach(el => {

      // 이미 컬러링된 경우 스킵
      if (el.querySelector("mark[data-ext-expiry]")) return;

      const text = normalizeText(el.textContent || "");
      if (!text) return;

      // div.in 안의 모든 텍스트를 하나의 TEXT_NODE로 만들어
      // 기존 highlightTextNode 로직을 그대로 태운다
      const textNode = document.createTextNode(text);
      el.innerHTML = "";
      el.appendChild(textNode);

      highlightTextNode(textNode);
    });
  }

  // ===============================================================
  // 38.[지마켓 예외 처리]
  //    TEXT_NODE로 잡히지 않는 td 날짜 강제 컬러링
  // ===============================================================
  function highlightTableDates(root) {

    root.querySelectorAll("td").forEach(td => {
      // 지마켓 QNA 테이블 날짜 제외
      if (td.closest(".tb_qna")) return;

      if (td.querySelector("mark[data-ext-expiry]")) return;

      const text = normalizeText(td.textContent || "").trim();
      if (!text) return;

      // 날짜만 있는 td만 대상
      if (!/^(\d{8}|\d{4}\.\d{2}\.\d{2})$/.test(text)) return;

      const parsed = parseYMD(text);
      if (!parsed) return;

      const today = todayMidnight();
      const d = toDate(parsed);
      const past = d < today;

      const within = (d - today) <= (1825 * 86400000);

      // 정책: 과거(5년 이내) = 검정, 오늘~5년 이내 = 노랑, 그 외(5년 초과) = 컬러링 없음
      if (past) {
        // 과거(5년 이내) → 검정
        td.innerHTML =
          `<mark data-ext-expiry="1" style="background:${COLOR_OLD_BG}; color:${COLOR_OLD_TEXT};">
${escapeHtml(text)}
</mark>`;
      } else if (within) {
        // 미래(0~5년 이내) → 노랑
        td.innerHTML =
          `<mark data-ext-expiry="1" style="background:${COLOR_FUTURE}; color:inherit;">
${escapeHtml(text)}
</mark>`;
      } else {
        // 5년 초과 → 컬러링 하지 않음 (원문 그대로 유지)
        td.textContent = text;
      }

    });
  }

  // ===============================================================
  // 39. [지마켓 전용] th 라벨(KEYWORDS) 강제 컬러링
  // ===============================================================
  function highlightTableLabels(root) {

    root.querySelectorAll("tr.list-item--hide th").forEach(th => {

      if (th.querySelector("mark[data-ext-expiry]")) return;

      const text = normalizeText(th.textContent || "");
      if (!text) return;

      if (!keywordRe.test(text)) return;

      th.innerHTML = escapeHtml(text).replace(keywordRe, (m) =>
        `<mark data-ext-expiry="1" style="background:${COLOR_FUTURE};">${m}</mark>`
      );
    });
  }

  // ===============================================================
  // [옥션 전용] 상품정보 제공고시 span.cont 날짜 강제 컬러링
  // - 기존 스캔에서 안 잡히는 케이스 전용
  // ===============================================================
  function highlightAuctionOfficialLabels(root) {
    if (!location.href.includes("auction.co.kr")) return;

    root.querySelectorAll("#divOfficialNotice ul.prodnoti_lst .stit").forEach(st => {
      if (st.querySelector('mark[data-ext-expiry="1"]')) return;

      const text = normalizeText(st.textContent || "");
      if (!text) return;

      if (!keywordRe.test(text)) return;

      // 텍스트는 escape, 키워드는 실제 <mark> 태그로 감싸서 innerHTML로 삽입
      st.innerHTML = escapeHtml(text).replace(
        keywordRe,
        (m) => `<mark data-ext-expiry="1" style="background:${COLOR_FUTURE};">${escapeHtml(m)}</mark>`
      );
    });
  }

  function highlightAuctionOfficialDates(root) {

    // 옥션이 아니면 바로 종료
    if (!location.href.includes("auction.co.kr")) return;

    root.querySelectorAll("li.list-item--hide > span.cont").forEach(span => {

      // 이미 처리됐으면 스킵
      if (span.querySelector("mark[data-ext-expiry]")) return;

      const text = normalizeText(span.textContent || "").trim();
      if (!text) return;

      // 날짜 형식만 대상
      if (!/^(\d{4}[-./]\d{2}[-./]\d{2})$/.test(text)) return;

      const parsed = parseYMD(text);
      if (!parsed) return;

      const today = todayMidnight();
      const d = toDate(parsed);

      const past = d < today;
      const within = (d - today) <= (1825 * 86400000);

      let bg = "";
      let fg = "inherit";

      if (past) {
        bg = COLOR_OLD_BG;
        fg = COLOR_OLD_TEXT;
      } else if (within) {
        bg = COLOR_FUTURE;
      } else {
        bg = COLOR_PAST;
      }

      span.innerHTML = `
      <mark data-ext-expiry="1" style="background:${bg}; color:${fg};">
        ${escapeHtml(text)}
      </mark>
    `;
    });
  }

  // ===============================================================
  // 40. 전체 문서 스캔(일반 텍스트 전용)
  // ===============================================================
  function scanText(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    let count = 0;

    while (walker.nextNode()) {
      const node = walker.currentNode;

      //  리뷰 / 문의 영역이면 아예 스캔 대상에서 제외
      // → 날짜 + 키워드 전부 컬러링 안 됨
      if (isInsideReviewContainer(node)) continue;

      nodes.push(node);
      if (++count > 3000) break; // 브라우저 보호
    }

    for (const n of nodes) {
      highlightTextNode(n);
    }
    highlightTableDates(root); // 날짜(td)
    highlightTableLabels(root); // 키워드(th)
    highlightAuctionOfficialDates(root);

    highlightDateInContSpan(root);
    highlightShinsegaeInDiv(root);
    highlightShinsegaeTitle(root);

    /* [추가 호출] 옥션 공식고시 라벨(.stit) 강제 컬러링 */
    highlightAuctionOfficialLabels(root);
  }


  // ===============================================================
  // 41. 배너 드래그 + 위치 저장 기능  (개선판)
  //  - 최초 생성 시에는 숨겨둔 상태에서 저장 위치를 먼저 적용하고,
  //    적용이 끝나면 보이도록 전환합니다.
  //  - 동일 세션에서 재사용할 수 있게 메모리 캐시도 함께 사용합니다.
  // ===============================================================
  let __ext_banner_mem_pos = null; // ⭐ 동일 세션 메모리 캐시(깜빡임 추가 방지)

  function makeBannerDraggable(el) {

    let dragging = false;
    let offsetX = 0;
    let offsetY = 0;

    // 저장된 위치 불러오기 (있는 경우)
    chrome.storage.local.get(["__ext_banner_pos"], (res) => {
      const saved = res.__ext_banner_pos || __ext_banner_mem_pos;

      if (saved && Number.isFinite(saved.top) && Number.isFinite(saved.left)) {
        // 저장 위치가 있으면 transform 제거하고, top/left 먼저 적용
        el.style.top = saved.top + "px";
        el.style.left = saved.left + "px";
        el.style.transform = "";
      }
      // 여기서 보이도록 전환: 깜빡임 방지
      el.style.visibility = "visible";
      el.style.opacity = "1";
    });

    el.addEventListener("mousedown", (e) => {
      dragging = true;
      offsetX = e.clientX - el.offsetLeft;
      offsetY = e.clientY - el.offsetTop;
      el.style.transform = "";     // 이동 순간에는 중앙 정렬 transform 제거
      e.preventDefault();
    });

    document.addEventListener("mousemove", (e) => {
      if (!dragging) return;

      // 브라우저 밖으로 못 나가게 제한
      let newLeft = e.clientX - offsetX;
      let newTop = e.clientY - offsetY;

      newLeft = Math.max(0, Math.min(window.innerWidth - el.offsetWidth, newLeft));
      newTop = Math.max(0, Math.min(window.innerHeight - el.offsetHeight, newTop));

      el.style.left = newLeft + "px";
      el.style.top = newTop + "px";
    });

    document.addEventListener("mouseup", () => {
      if (!dragging) return;
      dragging = false;

      const pos = {
        top: el.offsetTop,
        left: el.offsetLeft
      };

      // 로컬 스토리지 저장
      chrome.storage.local.set({ "__ext_banner_pos": pos });

      // 메모리 캐시도 갱신 (동일 세션 깜빡임 제거)
      __ext_banner_mem_pos = pos;
    });
  }

  // ===============================================================
  // 42. 배너 만들기 ( 쿠팡 배너 비노출 )
  // ===============================================================

  function makeBanner(text) {
    // 쿠팡에서는 배너 비노출(컬러링은 그대로)
    if (location.hostname.endsWith("coupang.com")) {
      removeBanner();
      return;
    }

    // 텍스트 없으면 배너 지움
    if (!text) {
      removeBanner();
      return;
    }

    let el = document.getElementById("__ext_global_banner__");

    // 아직 배너 없으면 새로 만들기
    if (!el) {
      el = document.createElement("div");
      el.id = "__ext_global_banner__";

      // 디자인 — 기존과 100% 동일하게 유지
      el.style.background = "rgba(20, 20, 20, 0.75)";
      el.style.backdropFilter = "blur(6px)";
      el.style.color = "#ffffff";
      el.style.fontSize = "14px";
      el.style.fontWeight = "normal";
      el.style.padding = "10px 14px";
      el.style.textAlign = "left";
      el.style.lineHeight = "1.2";
      el.style.position = "fixed";

      // 기존 기본 위치는 유지하지만, 먼저 '숨김'으로 추가
      el.style.top = "0";
      el.style.left = "50%";
      el.style.transform = "translateX(-50%)";
      el.style.zIndex = "2147483647";
      el.style.whiteSpace = "pre-line";
      el.style.borderRadius = "15px";
      el.style.boxShadow = "0 4px 12px rgba(0,0,0,0.3)";

      // 깜빡임 방지: 초기엔 보이지 않게
      el.style.visibility = "hidden";
      el.style.opacity = "0";

      document.body.appendChild(el);

      // 배너 드래그 이동 (여기서 저장 위치 적용 후 보이도록 전환)
      makeBannerDraggable(el);
    }

    // 내용이 변경되면 업데이트
    if (el.textContent !== text) el.textContent = text;
  }

  // ===============================================================
  // 43. 배너 제거
  // ===============================================================
  function removeBanner() {
    const el = document.getElementById("__ext_global_banner__");
    if (el) el.remove();
  }


  // ===============================================================
  // 44. 날짜 계산 (배너에서 쓰는 날짜들)
  // ===============================================================
  function addDays(days) {
    const d = new Date();
    d.setDate(d.getDate() + days);

    const yy = String(d.getFullYear()).slice(2);
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");

    return `${yy}.${mm}.${dd}`;
  }


  // ===============================================================
  // 45. 유통기한 기능 작동하는 UNITNAME
  // ===============================================================
  function isValidUnit(unit) {
    if (!unit) return false;
    const u = unit.toLowerCase().trim();
    const rules = __expiry_banner_rules__ || [];
    return rules.some(r =>
      String(r.units || "").split(",").map(s => s.trim().toLowerCase()).includes(u)
    );
  }


  // ===============================================================
  // 46. UNITNAME에 따라 다른 내용의 배너 띄우기
  // ===============================================================
  // {days:숫자} 를 실제 날짜로 변환
  // 예: {days:365} → "26.03.01"
  function resolveDayTokens(text) {
    return text.replace(/\{days:(\d+)\}/g, (_, n) => addDays(Number(n)));
  }

  function updateBannerByUnit(unit) {
    if (!isValidUnit(unit)) {
      removeBanner();
      return false;
    }

    const u = unit.toLowerCase().trim();
    const rules = __expiry_banner_rules__ || [];

    // 시트에서 이 유닛에 해당하는 룰 찾기
    const matched = rules.find(r =>
      String(r.units || "").split(",").map(s => s.trim().toLowerCase()).includes(u)
    );

    if (!matched || !matched.banner) {
      removeBanner();
      return false;
    }

    // {days:숫자} 를 실제 날짜로 변환 후 배너 표시
    makeBanner(resolveDayTokens(matched.banner));
    return true;
  }

  // ===============================================================
  // [47] 기존 색칠 모두 제거 (토글 OFF 또는 사이트 벗어났을 때)
  // ===============================================================
  function clearHighlights() {

    // mark 지우기
    document.querySelectorAll('mark[data-ext-expiry="1"]').forEach(m => {
      const p = m.parentNode;
      while (m.firstChild) p.insertBefore(m.firstChild, m);
      p.removeChild(m);
    });

    // CSS highlights 지우기
    try {
      const keys = ["__ext_future", "__ext_past"];
      keys.forEach(k => {
        const s = CSS.highlights.get(k);
        if (s) s.clear();
      });
    } catch (e) { }
  }


  // ===============================================================
  // 48. runOnce — 핵심 실행
  // ===============================================================
  let __ext_blocked__ = false; // 토글 ON/OFF 시 잠시 막는 용도
  let __ext_running__ = false; // runOnce 중복 실행 방지
  let __ext_observer__ = null; // MutationObserver 보관

  function runOnce() {

    // 이미 실행 중이면 재실행 금지
    if (__ext_running__) return;

    if (__ext_blocked__) return;

    __ext_running__ = true;
    __ext_observer__?.disconnect(); // DOM 변경 중 observer 차단


    chrome.storage.local.get(
      ["__ext_last_unit", "__ext_expiry_enabled"],
      (res) => {

        const enabled = res.__ext_expiry_enabled === true; // ✅ 기본 false
        const unit = res.__ext_last_unit || "";

        // 토글 꺼짐 → 배너/컬러링 전부 즉시 종료
        if (!enabled || !isValidUnit(unit)) {
          makeBanner("");
          clearHighlights();
          __ext_running__ = false; // ✅ 즉시 running 해제
          return;
        }

        // 배너 업데이트
        updateBannerByUnit(unit);

        // 본문 스캔
        scanText(document.body);

        // 인터랙티브 영역은 CSS highlight 전용
        scanInteractive(document.body);

        // ⭐ 무신사: 문의/후기/별점 영역 안에 남아있는 mark 제거(안전 호출)
        if (location.hostname.includes("musinsa.com")) {
          try {
            if (typeof window.__ext_unmarkMusinsaZones === "function") {
              window.__ext_unmarkMusinsaZones(document.body);
            }
          } catch (_) { }
        }

        // iframe도 처리
        document.querySelectorAll("iframe").forEach(f => {
          try {
            const b = f.contentDocument?.body;
            if (b) {
              scanText(b);
              scanInteractive(b);
            }
          } catch (e) { }
        });
        __ext_running__ = false; // runOnce 종료
        __ext_observer__?.observe(document.body, {
          childList: true,
          subtree: true
        });
      }
    );
  }

  // ===============================================================
  // 48-1. 안전 스케줄러 (DOM/탭 안정 후 runOnce 실행)
  // ===============================================================
  let __ext_raf__ = null;
  let __ext_debounce__ = null;
  function scheduleSafeRun(delay = 0) {
    if (__ext_raf__) cancelAnimationFrame(__ext_raf__);
    clearTimeout(__ext_debounce__);

    __ext_raf__ = requestAnimationFrame(() => {
      __ext_debounce__ = setTimeout(() => {
        // 탭이 보이고, DOM이 충분히 올라온 상태에서만 실행
        const visible = document.visibilityState === 'visible';
        const ready =
          document.readyState === 'interactive' || document.readyState === 'complete';

        // scheduleSafeRun 내부
        if (!visible || !ready) {
          setTimeout(() => scheduleSafeRun(0), 150);
          return;
        }
        if (isBlacklistSite()) return;  // 🆕 블랙리스트 재확인(FYI: storage 로딩 이후에도 안전)
        runOnce();
      }, delay);
    });
  }

  // ===============================
  // 49. 사이트별 추가 로직
  // ===============================

  // ===============================
  // 49-1. GS SHOP
  // ===============================

  if (location.href.includes("gsshop.com")) {

    // 탭 클릭 시 패널 재스캔
    document.addEventListener("click", (e) => {
      const t = e.target;
      if (!t || !t.classList) return;

      if (t.classList.contains("tab")) {
        const href = t.getAttribute("href") || "";

        setTimeout(() => {
          if (href.startsWith("#")) {
            let pane = document.querySelector(href);

            // GS SHOP: ProTabN04 → ProTab04 보정
            if (!pane && href.includes("ProTabN")) {
              const fixedId = href.replace("ProTabN", "ProTab");
              pane = document.querySelector(fixedId);
            }

            if (pane) {
              scanText(pane);
              scanInteractive(pane);
              return;
            }
          }

          // 패널 못 찾으면 전체 스캔
          scanText(document.body);
          scanInteractive(document.body);

        }, 300);
      }
    }, true);

    // hashchange로 전환되는 경우
    window.addEventListener("hashchange", () => {
      setTimeout(() => {
        let pane = document.querySelector(location.hash);

        if (!pane && location.hash.includes("ProTabN")) {
          const fixedId = location.hash.replace("ProTabN", "ProTab");
          pane = document.querySelector(fixedId);
        }

        if (pane) {
          scanText(pane);
          scanInteractive(pane);
        } else {
          scanText(document.body);
          scanInteractive(document.body);
        }
      }, 350);
    });
  }

  // ===============================
  // 49-1-1. OASIS (오아시스) 전용
  // - "상품상세정보" 탭 클릭 후에만 테이블이 생성됨
  // - GS SHOP과 동일한 구조 → 클릭 후 재스캔
  // ===============================

  if (location.hostname.includes("oasis.co.kr")) {

    document.addEventListener("click", (e) => {
      const t = e.target;
      if (!t) return;

      // "상품상세정보" 탭
      if (
        t.closest("span.udLine") &&
        t.textContent.includes("상품상세정보")
      ) {
        setTimeout(() => {

          // oasis 상품상세 테이블 (width=840 고정)
          const table = document.querySelector("table[width='840']");
          if (table) {
            scanText(table);
            scanInteractive(table);
          }

        }, 350); // oasis DOM 렌더 지연 고려
      }
    }, true);
  }

  // ===============================
  // 49-2. 11번가
  // ===============================
  if (location.href.includes("11st.co.kr")) {

    // 11번가 추천상품 캐러셀: 스캔 금지
    function skip11stCarousel(node) {
      return node?.parentElement?.closest(".carousel") ||
        node?.parentElement?.closest("[data-log-actionlabel='product']");
    }

    // 리뷰/문의/요약/썸네일/판매자답글 영역 안에 남아있는 mark 제거
    function unmarkIn11stReviewZones(root) {
      if (!location.href.includes("11st.co.kr")) return;
      root.querySelectorAll("mark[data-ext-expiry='1']").forEach(m => {
        if (is11stReviewZone(m)) {
          const p = m.parentNode;
          while (m.firstChild) p.insertBefore(m.firstChild, m);
          p.removeChild(m);
        }
      });
    }

    // 상품정보 제공고시 테이블만 스캔
    function scan11stProductInfo() {
      // 기존 테이블 스캔
      document.querySelectorAll("table").forEach(tbl => {
        if (tbl.textContent.includes("소비기한") ||
          tbl.textContent.includes("제조연월일") ||
          tbl.textContent.includes("사용기한") ||
          tbl.textContent.includes("사용기간") ||
          tbl.textContent.includes("품질유지기한")) {

          scanText(tbl);
          scanInteractive(tbl);
        }

        // 스캔 후, 리뷰 영역 내부에 남아있는 mark 제거
        unmarkIn11stReviewZones(document.body);

      });

      // 옵션 영역(상품요약)도 함께 스캔 (리뷰/문의 내부는 제외)
      document.querySelectorAll("div.cont").forEach(box => {
        if (is11stReviewZone(box)) return;

        const t = (box.textContent || "");
        if (
          /소비기한|유통기한|유효기간|사용기간|제조연월일|품질유지기한/.test(t)
        ) {
          scanText(box);
          scanInteractive(box);
        }
      });
    }


    // shouldSkip 보완: 캐러셀 영역은 무조건 스킵
    const __orig_shouldSkip = shouldSkip;
    shouldSkip = function (node) {
      if (skip11stCarousel(node)) return true;
      return __orig_shouldSkip(node);
    };

    // 로딩 후 적용
    setTimeout(scan11stProductInfo, 1200);

    // 페이지 내 이동 / 탭 전환 시 다시 스캔
    document.addEventListener("click", () => {
      setTimeout(scan11stProductInfo, 800);
    });
  }

  // ===============================
  // 49-3. MUSINSA (무신사 전용 정리)
  // ===============================
  if (location.href.includes("musinsa.com")) {

    // 전역에 노출(다른 곳에서 호출 가능)
    window.__ext_unmarkMusinsaZones = function (root) {
      try {
        if (!root || !root.querySelectorAll) return;

        const SELS = [
          "section[data-section-name='prd_inquire']",
          ".UIList__Wrap-sc-1ogtw3x-0[data-section-name='prd_inquire']",
          ".UIList__List-sc-1ogtw3x-1",
          ".UIList__Box-sc-1ogtw3x-4",
          ".UIList__Question-sc-1ogtw3x-6",
          ".ReviewSummary__Wrap-sc-p64drh-1",
          ".ReviewStarScore__Container-sc-1ba4cma-0",
          ".GoodsReviewTitle__Container-sc-wp7nul-0",
          ".GoodsReviewTitle__TitleContainer-sc-wp7nul-1"
        ];

        const marks = root.querySelectorAll('mark[data-ext-expiry="1"]');
        if (!marks || marks.length === 0) return;

        marks.forEach((m) => {
          // 노드가 분리되는 타이밍 보호
          if (!m || !m.parentNode) return;
          const p = m.parentElement;
          if (!p) return;

          // p가 이미 DOM에서 제거되었을 수 있음
          let insideBlocked = false;
          for (const sel of SELS) {
            try {
              if (p.closest && p.closest(sel)) { insideBlocked = true; break; }
            } catch (_) {
              // 잘못된 셀렉터/DOM 변화로 인한 예외 무시
            }
          }

          if (!insideBlocked) return;

          // m의 자식 이동 중에도 DOM 파괴 타이밍 보호
          const parent = m.parentNode;
          if (!parent) return;

          while (m.firstChild) {
            try { parent.insertBefore(m.firstChild, m); }
            catch (_) { break; } // 중간에 DOM이 날아가면 정지
          }
          try { parent.removeChild(m); } catch (_) { }
        });

      } catch (_) {
        // 무신사 전용 정리 로직은 에러 삼켜서 메인 플로우 절대 막지 않음
      }
    };

    let __musinsa_raf__ = null;

    // 최초 로딩 후 한 번 정리
    setTimeout(() => window.__ext_unmarkMusinsaZones(document.body), 800);

    // 클릭/탭/더보기 등 이후에도 다시 정리
    document.addEventListener("click", () => {
      setTimeout(() => window.__ext_unmarkMusinsaZones(document.body), 600);
    });

    // 스크롤/동적 로딩 대응
    let __musinsa_observer__ = null;
    try {
      __musinsa_observer__ = new MutationObserver(() => {
        try {
          if (__musinsa_raf__) cancelAnimationFrame(__musinsa_raf__);
          __musinsa_raf__ = requestAnimationFrame(() => {
            try { window.__ext_unmarkMusinsaZones?.(document.body); } catch (_) { }
          });
        } catch (_) { }
      });
      __musinsa_observer__?.observe(document.body, { childList: true, subtree: true });
    } catch (_) {
      // 옵저버 생성/observe 실패 시에도 메인 플로우 유지
    }
  }

  // ===============================================================
  // 50. 토글 ON/OFF 시 즉시 적용
  // ===============================================================
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.action === "expiry_refresh") {
      if (__ext_running__) return; // 중복 실행 방지
      scheduleSafeRun();           // 즉시 실행 대신 안전 스케줄러
    }
  });

  // ===============================================================
  // 51. MAIN — MutationObserver로 자동 감시
  // ===============================================================
  function main() {

    // 즉시 1회 실행 → 안전 스케줄러로
    scheduleSafeRun();

    let raf = null;

    __ext_observer__ = new MutationObserver(() => {
      if (raf) cancelAnimationFrame(raf);
      // DOM 변화 시에도 안전 스케줄러 사용
      raf = requestAnimationFrame(() => scheduleSafeRun());
    });

    // body가 없을 타이밍을 피하기 위해 document 전체 관측
    __ext_observer__.observe(document, {
      childList: true,
      subtree: true
    });

    // URL hash 변경 시 다시 적용 → 안전 스케줄러로
    window.addEventListener("hashchange", () => {
      scheduleSafeRun(350);
    });

    // BFCache 복원/뒤로가기 등에서 즉시 재평가
    window.addEventListener('pageshow', () => {
      scheduleSafeRun();
    });

    // 탭이 다시 보일 때 즉시 재평가
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        scheduleSafeRun();
      }
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", main);
  } else {
    main();
  }


})();

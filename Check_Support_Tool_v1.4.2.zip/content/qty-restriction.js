// ============================================================
// qty-restriction.js
// 최소 구매 수량 제한
// ============================================================

(function () {
// === 공통: 배너 호스트(스택 컨테이너) ===
const HOST_ID = "__ext_banner_host__";
function ensureBannerHost() {
let host = document.getElementById(HOST_ID);
if (!host) {
host = document.createElement("div");
host.id = HOST_ID;
host.setAttribute("data-ext-banner-host", "1");
Object.assign(host.style, {
all: "initial",
position: "fixed",
top: "20px",
left: "50vw",
transform: "translateX(-50%)",
zIndex: "2147483647",
display: "flex",
flexDirection: "column",
alignItems: "center",
gap: "8px", // 배너 간격
pointerEvents: "none", // 클릭 방해 금지
contain: "layout style paint",
willChange: "transform",
});
(document.documentElement || document.body).appendChild(host);
}
return host;
}
// 호스트가 비면 삭제
function cleanupEmptyHost() {
const host = document.getElementById(HOST_ID);
if (host && host.children.length === 0) host.remove();
}
// ------------------------------------------------------------
// 0. 공통 상태 / 공통 UI
const FADE_INTERVAL_MS = 500; // 숫자↑ = 더 느림
const FADE_TOGGLES = 10; // 10 토글 = 5회
// ------------------------------------------------------------
// ★ 전역(창) 공유 에폭: 모든 배너가 같은 기준 시계를 사용 → 위상 완전 일치
const FADE_EPOCH_KEY = "__ext_fade_epoch__";
if (!window[FADE_EPOCH_KEY]) window[FADE_EPOCH_KEY] = Date.now();

let bannerEl = null;
let fadeTimer = null;
let fadeToggles = 0;
// ★ 경계 정렬을 위한 1회성 setTimeout 핸들
let fadeAlignTimer = null;

// ------------------------------------------------------------
// 1. 공통 배너
// ------------------------------------------------------------
function showWarningBanner(text) {
if (bannerEl) return;

bannerEl = document.createElement("div");
bannerEl.textContent = text;
bannerEl.setAttribute("data-ext-banner", "qty");

Object.assign(bannerEl.style, {
color: "#ffffffff",
fontSize: "20px",
fontWeight: "700",
background: "rgba(233, 34, 34, 0.91)",
padding: "12px 22px",
borderRadius: "16px",
opacity: "1",
transition: "opacity 0.6s ease-in-out", // ← 페이드
boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
pointerEvents: "none",

// ← 겹침 방지 & 중앙 정렬 (flex 스택 안정화)
display: "block",
flex: "0 0 auto",
alignSelf: "center"
});

ensureBannerHost().appendChild(bannerEl);
startFade(); // ← 변경
}

function removeWarningBanner() {
if (!bannerEl) return;

try { clearInterval(fadeTimer); } catch { }
try { clearTimeout(fadeAlignTimer); } catch { }
bannerEl.remove();
bannerEl = null;
cleanupEmptyHost();
}

// ------------------------------------------------------------
// 3. 깜빡임 (5회 후 고정)
// ------------------------------------------------------------
function startFade() {
fadeToggles = 0;
try { clearInterval(fadeTimer); } catch { }
try { clearTimeout(fadeAlignTimer); } catch { }
if (!bannerEl) return;

// ★ 창 전체에서 공유되는 에폭(같은 시계)을 기준으로 위상 계산
const epoch = window[FADE_EPOCH_KEY];
const now = Date.now();
const elapsed = now - epoch;

// 다음 토글 경계까지 남은 시간(정렬용)
const remainder = elapsed % FADE_INTERVAL_MS;
const delayToBoundary = FADE_INTERVAL_MS - remainder;

// 현재 구간의 짝/홀(0=짝수 구간, 1=홀수 구간)
const parity = Math.floor(elapsed / FADE_INTERVAL_MS) % 2;

// ★ 초기 표시 상태를 parity에 맞춰 설정 (모두 같은 구간에서 같은 상태)
// 짝수 구간→"1"(켜짐), 홀수 구간→"0"(꺼짐)
bannerEl.style.opacity = (parity === 0 ? "1" : "0");

// 경계 시각에 첫 토글을 정확히 수행 → 이후 동일 간격으로 완전 동기화
const tick = () => {
if (!bannerEl) { clearInterval(fadeTimer); return; }
bannerEl.style.opacity = (bannerEl.style.opacity === "1" ? "0" : "1");
fadeToggles++;
if (fadeToggles >= FADE_TOGGLES) {
clearInterval(fadeTimer);
bannerEl.style.opacity = "1";
}
};

// ★ 경계까지 대기 후 첫 토글 → setInterval로 고정 주기 실행
fadeAlignTimer = setTimeout(() => {
tick(); // 첫 토글(경계에서)
fadeTimer = setInterval(tick, FADE_INTERVAL_MS);
}, delayToBoundary);
}

// ============================================================
// 4. 사이트 분기 진입점
// ============================================================

const host = location.host;

// ------------------------------------------------------------
// 5-1. 네이버 스마트스토어
// ------------------------------------------------------------
if (host.includes("smartstore.naver.com")) {
runSmartStoreObserver();
return;
}

// ============================================================
// 5-1. 네이버 스마트스토어 전용 로직
// ============================================================

// ------------------------------------------------------------
// 5-1. 구매 영역 컨테이너
// ------------------------------------------------------------
function getNaverPurchaseContainer() {
return document.querySelector("fieldset.zFcPceRwDS");
}

// ------------------------------------------------------------
// 5-1. 최소구매 문구 체크
// ------------------------------------------------------------
function hasNaverMinBuyText(container) {
if (!container) return false;

const p = container.querySelector("p.S_ixevsgwu");
if (!p) return false;

const txt = p.textContent || "";
const m = txt.match(/최소구매\s*(\d+)/);
return m && Number(m[1]) > 1;
}

// ------------------------------------------------------------
// 5-1. 최소구매 문구 컬러링
// ------------------------------------------------------------
function highlightNaverMinBuyText(container) {
const p = container.querySelector("p.S_ixevsgwu");
if (!p) return;

Object.assign(p.style, {
display: "inline-block",
padding: "4px 8px",
border: "2px solid #d32f2f",
backgroundColor: "#fff5f5",
borderRadius: "4px",
fontWeight: "700"
});
}

// ------------------------------------------------------------
// 5-1. 최소구매 문구 하이라이트 제거
// ------------------------------------------------------------
function resetNaverMinBuyText(container) {
const p = container.querySelector("p.S_ixevsgwu");
if (!p) return;

p.style.display = "";
p.style.padding = "";
p.style.border = "";
p.style.backgroundColor = "";
p.style.borderRadius = "";
p.style.fontWeight = "";
}

// ------------------------------------------------------------
// 5-1. 수량 input 강조
// ------------------------------------------------------------
function highlightNaverQtyInput(container) {
const input = container.querySelector("input.WdVaW2Rsa0");
if (!input) return;

input.style.border = "2px solid #d32f2f";
input.style.background = "#fff5f5";
input.style.color = "#d32f2f";
input.style.fontWeight = "700";
}

// ------------------------------------------------------------
// 5-1. 수량 input 원복
// ------------------------------------------------------------
function resetNaverQtyInput(container) {
const input = container.querySelector("input.WdVaW2Rsa0");
if (!input) return;

input.style.border = "";
input.style.background = "";
input.style.color = "";
input.style.fontWeight = "";
}


// ------------------------------------------------------------
// 5-1. 수량 input value > 1 체크
// ------------------------------------------------------------
function hasNaverQtyOverOne(container) {
if (!container) return false;

const input = container.querySelector('input.WdVaW2Rsa0');
if (!input) return false;

const v = Number(input.value);
return !isNaN(v) && v > 1;
}

// ------------------------------------------------------------
// 5-1.상태 판단
// ------------------------------------------------------------
function checkNaverRestriction() {
const container = getNaverPurchaseContainer();
if (!container) return false;

return (
hasNaverMinBuyText(container) ||
hasNaverQtyOverOne(container)
);
}

// ------------------------------------------------------------
// 5-1. 상태 갱신
// ------------------------------------------------------------
function refreshNaver() {
if (checkNaverRestriction()) {
showWarningBanner("최소 구매 수량 확인 필요");
} else {
removeWarningBanner();
}
}

function refreshNaver() {
const container = getNaverPurchaseContainer();
if (!container) return;

const hasMinBuy = hasNaverMinBuyText(container);
const hasQtyOver = hasNaverQtyOverOne(container);

// ---- 최소구매 문구 컬러링 ----
if (hasMinBuy) {
highlightNaverMinBuyText(container);
} else {
resetNaverMinBuyText(container);
}


// ---- 수량 input 컬러링 ----
if (hasQtyOver) {
highlightNaverQtyInput(container);
} else {
resetNaverQtyInput(container);
}

// ---- 경고 문구 ----
if (hasMinBuy || hasQtyOver) {
showWarningBanner("최소 구매 수량 확인 필요");
} else {
removeWarningBanner();
}
}



// ------------------------------------------------------------
// 6. SPA 대응 Observer
// ------------------------------------------------------------
function runSmartStoreObserver() {
let raf;

const mo = new MutationObserver(() => {
if (raf) cancelAnimationFrame(raf);
raf = requestAnimationFrame(refreshNaver);
});

mo.observe(document.body, {
childList: true,
subtree: true,
attributes: true
});

// 최초 1회 실행
refreshNaver();
}

})();

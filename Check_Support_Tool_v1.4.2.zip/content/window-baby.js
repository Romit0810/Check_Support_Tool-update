// =============================================================
// window-baby.js
// baby 칸아이디 + 네이버윈도우 + 1+1 행사중일때 실행됨
// =============================================================

(function () {
// 탑 프레임에서만 동작(중복/iframe 주입 방지)
if (window.self !== window.top) return;

// === 공통: 배너 호스트(스택 컨테이너) ===
const HOST_ID = "__ext_banner_host__";
function ensureBannerHost() {
let host = document.getElementById(HOST_ID);
if (!host) {
host = document.createElement("div");
host.id = HOST_ID;
host.setAttribute("data-ext-banner-host", "1");
Object.assign(host.style, {
all: "initial",
position: "fixed",
top: "20px",
left: "50vw",
transform: "translateX(-50%)",
zIndex: "2147483647",
display: "flex",
flexDirection: "column",
alignItems: "center",
gap: "8px", // 배너 간격
pointerEvents: "none",
contain: "layout style paint",
willChange: "transform",
});
(document.documentElement || document.body).appendChild(host);
}
return host;
}
function cleanupEmptyHost() {
const host = document.getElementById(HOST_ID);
if (host && host.children.length === 0) host.remove();
}

// -------------------------------------------------------------
// 1) 네이버 window 페이지만 동작
// -------------------------------------------------------------
function isNaverWindowPage() {
return /^https?:\/\/shopping\.naver\.com\/window/i.test(location.href);
}
if (!isNaverWindowPage()) return;

// -------------------------------------------------------------
// 2) 대상 KAN 목록 (시트연동)
// -------------------------------------------------------------
let __window_baby_kans__ = null;

function __loadWindowBabyKans(cb) {
chrome.storage.local.get(["window_baby_kans"], (res) => {
__window_baby_kans__ = Array.isArray(res.window_baby_kans)
? res.window_baby_kans : [];
if (typeof cb === "function") cb();
});
}

chrome.storage.onChanged.addListener((changes, area) => {
if (area === "local" && changes.window_baby_kans) {
__window_baby_kans__ = Array.isArray(changes.window_baby_kans.newValue)
? changes.window_baby_kans.newValue : [];
}
});

const isEligibleKanValue = (v) =>
(__window_baby_kans__ || []).includes((v ?? "").toString().trim());

// -------------------------------------------------------------
// 3) 상태/배너 UI
// -------------------------------------------------------------
// ▼▼ 페이드 설정 (etx_banner.js와 동일) ▼▼
const FADE_INTERVAL_MS = 500; // 숫자↑ = 더 느림
const FADE_TOGGLES = 10; // 10 토글 = 5회

// ★ 전역(창) 공유 에폭: 모든 배너가 같은 기준 시계를 사용 → 위상 완전 일치
const FADE_EPOCH_KEY = "__ext_fade_epoch__";
if (!window[FADE_EPOCH_KEY]) window[FADE_EPOCH_KEY] = Date.now();

let bannerEl = null;
// let blinkTimer = null; // ← 사용 안 함(페이드로 대체)
let fadeTimer = null;
let fadeToggles = 0;
// ★ 경계 정렬용 1회성 타이머
let fadeAlignTimer = null;

let blueBlockObserver = null;
let eligibleKan = false;
let safetyTimer = null;

function showWarningBanner(text) {
if (bannerEl) return;
bannerEl = document.createElement("div");
bannerEl.setAttribute("data-ext-banner", "baby");
bannerEl.textContent = text;
Object.assign(bannerEl.style, {
color: "#ffffffff",
fontSize: "20px",
fontWeight: "700",
background: "rgba(233, 34, 34, 0.91)",
padding: "12px 22px",
borderRadius: "16px",
opacity: "0", // ★ 1 → 0 (처음엔 꺼진 상태)
transition: "opacity 0.6s ease-in-out",
boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
pointerEvents: "none",

// ← 겹침 방지 & 중앙 정렬
display: "block",
flex: "0 0 auto",
alignSelf: "center"
});
ensureBannerHost().appendChild(bannerEl);
startFade(); // ← 변경
}

function removeWarningBanner() {
if (bannerEl) {
try { clearInterval(fadeTimer); } catch { }
try { clearTimeout(fadeAlignTimer); } catch { }
try { bannerEl.remove(); } catch { }
bannerEl = null;
}
cleanupEmptyHost();
}

// 원래 깜빡임(5회) 복구
function startFade() {
fadeToggles = 0;
try { clearInterval(fadeTimer); } catch { }
try { clearTimeout(fadeAlignTimer); } catch { }
if (!bannerEl) return;

// ★ 창 전체에서 공유되는 에폭(같은 시계)을 기준으로 위상 계산
const epoch = window[FADE_EPOCH_KEY];
const now = Date.now();
const elapsed = now - epoch;

// 다음 토글 경계까지 남은 시간(정렬용)
const remainder = elapsed % FADE_INTERVAL_MS;
const delayToBoundary = FADE_INTERVAL_MS - remainder;

// 현재 구간의 짝/홀(0=짝수 구간, 1=홀수 구간)
const parity = Math.floor(elapsed / FADE_INTERVAL_MS) % 2;

// ★ 초기 표시 상태를 parity에 맞춰 설정 (모두 같은 구간에서 같은 상태)
// 짝수 구간→"1"(켜짐), 홀수 구간→"0"(꺼짐)
bannerEl.style.opacity = (parity === 0 ? "1" : "0");

// 경계 시각에 첫 토글을 정확히 수행 → 이후 동일 간격으로 완전 동기화
const tick = () => {
if (!bannerEl) { clearInterval(fadeTimer); return; }
bannerEl.style.opacity = (bannerEl.style.opacity === "1" ? "0" : "1");
fadeToggles++;
if (fadeToggles >= FADE_TOGGLES) {
clearInterval(fadeTimer);
bannerEl.style.opacity = "1";
}
};

// ★ 경계까지 대기 후 첫 토글 → setInterval로 고정 주기 실행
fadeAlignTimer = setTimeout(() => {
tick(); // 첫 토글(경계에서)
fadeTimer = setInterval(tick, FADE_INTERVAL_MS);
}, delayToBoundary);
}

// -------------------------------------------------------------
// 4) 블루박스/문구
// -------------------------------------------------------------
function getBlueBlock() {
return document.querySelector("div.RUSA6W3qmn");
}
function hasOnePlusOneText(block) {
if (!block) return false;
try { return /1\s*\+\s*1/.test(block.innerText); } catch { return false; }
}

// 하이라이트 원복
function resetOnePlusOne(root) {
const block = root || getBlueBlock();
if (!block) return;
block.querySelectorAll('span[data-ext-baby="1"]').forEach(span => {
const parent = span.parentNode;
while (span.firstChild) parent.insertBefore(span.firstChild, span);
parent.removeChild(span);
});
}

// "1+1"만 정확히 감싸기 (중복/에러 유발 버전 제거됨)
function highlightOnePlusOne(block) {
if (!block) return;
resetOnePlusOne(block);

const walker = document.createTreeWalker(block, NodeFilter.SHOW_TEXT, null);
const nodes = [];
while (walker.nextNode()) nodes.push(walker.currentNode);

const regex = /1\s*\+\s*1/g;

for (const node of nodes) {
const text = node.nodeValue;
if (!regex.test(text)) continue;

const ranges = [];
regex.lastIndex = 0;
let match;
while ((match = regex.exec(text))) {
const r = document.createRange();
r.setStart(node, match.index);
r.setEnd(node, match.index + match[0].length);
ranges.push(r);
}

for (let i = ranges.length - 1; i >= 0; i--) {
const r = ranges[i];
const span = document.createElement("span");
span.setAttribute("data-ext-baby", "1");
Object.assign(span.style, {
display: "inline-block",
padding: "4px 8px",
border: "3px solid #ff0000ff",
backgroundColor: "#fff5f5",
borderRadius: "4px",
fontWeight: "700",
});
try {
r.surroundContents(span);
} catch {
const before = text.slice(0, r.startOffset);
const mid = text.slice(r.startOffset, r.endOffset);
const after = text.slice(r.endOffset);
const wrapper = document.createElement("span");
wrapper.innerHTML =
(before || "") +
'<span data-ext-baby="1" style="display:inline-block;padding:4px 8px;border:3px solid #d32f2f;background:#fff5f5;border-radius:4px;font-weight:700;">' +
mid +
'</span>' +
(after || "");
node.replaceWith(wrapper);
break;
}
}
}
}

// -------------------------------------------------------------
// 5) 옵저버 (SPA 재평가)
// -------------------------------------------------------------
function observeBlueBlock() {
const parent = document.querySelector("fieldset.zFcPceRwDS") || document.body;
if (!parent) return;

let rafId = null;
function recheck() {
if (rafId) cancelAnimationFrame(rafId);
rafId = requestAnimationFrame(() => {
if (!eligibleKan) {
resetOnePlusOne();
removeWarningBanner();
return;
}
const block = getBlueBlock();
if (!block) {
removeWarningBanner();
return;
}
if (hasOnePlusOneText(block)) {
highlightOnePlusOne(block);
showWarningBanner("Baby 1+1 ㅣ 행사 수량이 아닌 기본 수량으로 대응");
} else {
resetOnePlusOne(block);
removeWarningBanner();
}
});
}

if (!blueBlockObserver) {
blueBlockObserver = new MutationObserver(recheck);
blueBlockObserver.observe(parent, { childList: true, subtree: true });
}
recheck();
}

// -------------------------------------------------------------
// 6) 전체 정리 (배너/하이라이트/옵저버 + 중복 배너까지 강제 제거)
// -------------------------------------------------------------
function hardKillBabyBanners() {
const host = document.getElementById(HOST_ID);
if (!host) return;
host.querySelectorAll('[data-ext-banner="baby"]').forEach(el => {
try { el.remove(); } catch { }
});
cleanupEmptyHost();
}
function stopAll() {
removeWarningBanner();
resetOnePlusOne();
if (blueBlockObserver) { try { blueBlockObserver.disconnect(); } catch { } blueBlockObserver = null; }
hardKillBabyBanners();
}

// -------------------------------------------------------------
// 7) 첫 실행 (현재 KAN 평가)
// -------------------------------------------------------------
function tryRun() {
chrome.storage.local.get("__ext_last_kan", (res) => {
const raw = res && res.__ext_last_kan;
const kan = (raw === undefined || raw === null) ? "" : String(raw).trim();
eligibleKan = isEligibleKanValue(kan);

if (!eligibleKan) { stopAll(); return; }

observeBlueBlock();

const block = getBlueBlock();
if (block && hasOnePlusOneText(block)) {
highlightOnePlusOne(block);
showWarningBanner("Baby 1+1 ㅣ 행사 수량이 아닌 기본 수량으로 대응");
} else {
removeWarningBanner();
}
});
}

// -------------------------------------------------------------
// 8) KAN 변경 즉시 반응 + 폴백 폴링(안정화)
// -------------------------------------------------------------
chrome.storage.onChanged.addListener((changes, area) => {
if (area !== "local") return;
if (!changes.__ext_last_kan) return;

const raw = changes.__ext_last_kan.newValue;
const kan = (raw === undefined || raw === null) ? "" : String(raw).trim();
eligibleKan = isEligibleKanValue(kan);

if (!eligibleKan) { stopAll(); return; }

observeBlueBlock();
const block = getBlueBlock();
if (block && hasOnePlusOneText(block)) {
highlightOnePlusOne(block);
showWarningBanner("Baby 1+1 ㅣ 행사 수량이 아닌 기본 수량으로 대응");
} else {
removeWarningBanner();
}
});

// 폴백: 0.8초마다 저장 KAN 재확인 (onChanged 미발화/지연 대비)
if (!safetyTimer) {
safetyTimer = setInterval(() => {
chrome.storage.local.get("__ext_last_kan", (res) => {
const raw = res && res.__ext_last_kan;
const kan = (raw === undefined || raw === null) ? "" : String(raw).trim();
const nowEligible = isEligibleKanValue(kan);

if (nowEligible !== eligibleKan) {
eligibleKan = nowEligible;
if (!eligibleKan) { stopAll(); return; }
observeBlueBlock();
}

if (!eligibleKan) {
// 대상이 아닌 상태에서 혹시 남아있으면 강제 정리
stopAll();
}
});
}, 800);
}

// -------------------------------------------------------------
// 9) 부트
// -------------------------------------------------------------
__loadWindowBabyKans(() => {
if (document.readyState === "loading") {
document.addEventListener("DOMContentLoaded", () => setTimeout(tryRun, 150));
} else {
setTimeout(tryRun, 0);
}
});

})();

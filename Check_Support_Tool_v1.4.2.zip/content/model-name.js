// ============================================================
// model-name.js
// 어드민의 모델명 -> 외부사이트에 컬러링 (겹침 구간 Range 스왑 포함)
// ============================================================

(function () {
"use strict";

/* ============================================================
* 0. 스타일
* ============================================================ */
const TEXT_MARK_CLASS = "__ext-model-mark";
const TEXT_MARK_MISMATCH_CLASS = "__ext-model-mark-mismatch";
const STYLE_ID = "__ext-model-style";
const COLOR_HIT = "#ffd3c4ff"; // 모델 일치 분홍
const COLOR_MISMATCH = "#ffa181ff"; // 허용 불일치 진분홍
const STORAGE_KEY_MODELS = "__ext_model_names_norm";
// [추가]
const SNAPSHOT_KEY = "__ext_models_snapshot";
const SNAPSHOT_AT_KEY = "__ext_models_snapshot_at";
const SNAPSHOT_TTL_MS = 5 * 60 * 1000; // 5분

if (!document.getElementById(STYLE_ID)) {
const style = document.createElement("style");
style.id = STYLE_ID;
style.textContent = `
.${TEXT_MARK_CLASS}{
background:${COLOR_HIT} !important;
pointer-events:none !important;
font-size: inherit !important; /* ★ [PATCH-FONT] */
line-height: inherit !important; /* ★ [PATCH-FONT] */
}
.${TEXT_MARK_MISMATCH_CLASS}{
background:${COLOR_MISMATCH} !important;
pointer-events:none !important;
font-size: inherit !important; /* ★ [PATCH-FONT] */
line-height: inherit !important; /* ★ [PATCH-FONT] */
}
`;
(document.head || document.documentElement).appendChild(style);
}

function unpaintAll() {
const all = document.querySelectorAll(`.${TEXT_MARK_CLASS}, .${TEXT_MARK_MISMATCH_CLASS}`);
for (const span of all) {
const parent = span.parentNode;
if (!parent) continue;
const text = document.createTextNode(span.textContent || "");
parent.replaceChild(text, span);
if (typeof parent.normalize === "function") parent.normalize();
}
}

// ============================================================
// 블랙리스트 (시트연동)
// ============================================================
let __blacklist_site = null;
let __bl_loaded__ = false; // 로드 완료 플래그

function __ext_loadBlacklistSite(cb) {
try {
chrome.storage.local.get(["BlacklistSite"], (res) => {
__blacklist_site = (res.BlacklistSite || []).map(s => String(s || "").trim());
__bl_loaded__ = true;
if (typeof cb === "function") cb();
});
} catch {
__blacklist_site = [];
__bl_loaded__ = true;
if (typeof cb === "function") cb();
}
}
// 최초 1회 로드
__ext_loadBlacklistSite();

const isBlacklistedSite = () => {
try {
const href = location.href;
const list = Array.isArray(__blacklist_site) ? __blacklist_site : [];
return list.some(u => href.startsWith(u));
} catch { return false; }
};

// 블랙리스트 변경 즉시 반영 + 현재 페이지면 즉시 언페인트
chrome.storage.onChanged.addListener((changes, area) => {
if (area !== "local" || !changes.BlacklistSite) return;

__blacklist_site = (changes.BlacklistSite.newValue || []).map(s => String(s || "").trim());

if (isBlacklistedSite()) {
try { unpaintAll(); } catch (_) { }
return;
}
});

// 컬러허용
const MISMATCH_ALLOWED_CHARS =
["CY", "W", "I", "B", "Y", "P", "M", "C", "G", "N", "Q", "R", "v",
"BK", "BLACK", "WH", "RD", "BL", "BL",
"GREEN", "GR", "GRY", "SL", "SV",
"GD", "GD", "PK", "OR", "ORANGE", "PP", "PURPLE",
"BR", "BROWN", "BG", "BE", "NV", "NAVY", "IV", "IVORY",
"CH", "CR", "KH", "MR", "OL", "WH", "KR"];

// 실행 제외 KANID
const KANID_BLOCKLIST = new Set([
//Electronics
"9130",
//Computer & Digital
"9047", "8893", "5341", "5340", "8732", "9117", "9051", "2266", "2480", "2276", "2476", "2267", "2477", "2478", "5329", "2273", "5330", "2275", "9053", "2479", "5328", "2272", "5332", "9055", "9058", "5336", "5335", "4221", "8642", "9071", "8816", "5752", "8640", "8641", "8598", "5477", "5342", "2296", "8078", "8649", "8639", "9120", "8966", "8967", "8971", "8975", "5311", "7377", "2289", "5305", "5304", "5302", "2251", "5268", "5269", "5267", "5271", "8993", "5290", "5274", "5272", "8996", "5279", "2249", "5273", "2250", "8998", "8999", "5247", "5282", "5256", "5070"
]);

/* ============================================================
* 2. 유틸
* ============================================================ */
const normalizeModel = (s) => {
if (!s) return "";
return s.replace(/[^0-9A-Za-z\-\s]/g, "").replace(/\s+/g, " ").toUpperCase();
};
const normalizeForMatching = (s) => {
if (!s) return "";
return s.replace(/[^0-9A-Za-z]/g, "").toUpperCase();
};
const isAdminPage = () => location.host.includes("price.coupang.com");

function isStopwordLike(norm) {
if (!norm) return false;

// 1) 단위·규격·수량 관련 stopword 강화
const exact = new Set([
// 기존
"WIFI", "WIFI6", "WIFI6E", "WIFI7",
"WIN11", "WIN10", "WINDOWS11", "WINDOWS10",
"HOME", "PRO", "EDU",
"LTE", "5G", "4G", "BLUETOOTH", "BT", "CELLULAR",
"CM", "MM", "INCH", "IN",
"GB", "TB", "MB",
"HZ", "KHZ", "MHZ", "GHZ",
"W", "WH",
"HDR", "HDR10", "HDR10PLUS", "IPS", "VA", "OLED", "QLED",
"APPLE", "PS4", "L", "ML", "LITER", "LITRE",

// 추가: 단위·치수(무게/길이/수량)
"G", "KG", "M", "KM",
"CM2", "M2", "M3",
"PCS", "PC", "EA",

// ★ [PATCH-CORE] 코어/CORE 류 — 스펙 표기: 모델명 아님
"CORE", "CORES", "CPUCORE", "CPUCORES", "코어"
]);
if (exact.has(norm)) return true;

// 2) OS 묶음
if (/^WIN(10|11)(HOME|PRO|EDU)?$/.test(norm)) return true;
if (/^WINDOWS(10|11)(HOME|PRO|EDU)?$/.test(norm)) return true;

// 3) 연도 묶음
if (/^APPLE(19|20)\d{2}$/.test(norm)) return true;

// 4) 단위/규격 숫자 패턴 (확장)
if (/^\d+(\.\d+)?(GB|TB|MB|HZ|KHZ|MHZ|GHZ|W|WH|CM|MM|IN|L|ML|G|KG|M|KM)$/i.test(norm)) return true;

// 5) 해상도·규격
if (/^\d+K$/.test(norm)) return true;
if (/^\d{3,4}P$/.test(norm)) return true;
if (/^\d+X\d+$/.test(norm)) return true;

// 6) in1 (다기능 숫자 패턴)
if (norm === "IN1" || /^\d+IN1$/.test(norm)) return true;

// 7) 단위가 뒤에 오는 표기 (스페이스 포함)
if (/^\d+(\.\d+)?\s*(G|KG|M|KM|CM|MM|IN|L|ML)$/i.test(norm)) return true;

// ★ [PATCH-CORE] 숫자+CORE (정규화 상태: 영문/숫자만) → ex) "10CORE", "8CORES"
if (/^\d+CORES?$/i.test(norm)) return true;

// ★ [PATCH-CORE] 너무 짧은 접두형(예: "M4")은 단독일 때 오인 가능 → 일반적으로 제외
// - 단, 뒤에 하이픈/버전/서브코드가 붙은 '진짜 모델'은 다른 곳에서 매칭됨
if (/^[A-Z]\d{1,2}$/.test(norm)) return true;

return false;
}

function isDimensionLikeText(raw) {
if (!raw) return false;
const s = raw.trim();
if (/^[xX×]\s*\d+(\.\d+)?\s*(CM|MM|IN|INCH|M)?$/i.test(s)) return true;
if (/^\d+(\.\d+)?\s*[xX×]\s*\d+(\.\d+)?\s*(CM|MM|IN|INCH|M)?$/i.test(s)) return true;
return false;
}
function stripTrailingUnitSuffix(s) {
if (!s) return s;
const unitPattern = '(?:KG|G|LB|OZ|L|ML|CM|MM|M|IN|INCH)';
return s.replace(
new RegExp(
// ✅ 선행 공백을 '필수'로 변경: \s+ (모델 내부 숫자+단위는 절대 제거하지 않음)
// 예) "FH25VA 25kg" → 공백 + 25kg 꼬리만 제거
// "NR-SN100L" → 공백이 없으므로 미제거 (정상 보존)
String.raw`\s+(?:[+xX]\s*)?\d+(?:\.\d+)?\s*${unitPattern}\b.*$`,
'i'
),
''
).trim();
}
function splitAllowedSuffix(modelNorm) {
const allowed = MISMATCH_ALLOWED_CHARS.map(c => c.toUpperCase())
.sort((a, b) => b.length - a.length);
for (const suf of allowed) {
if (modelNorm.endsWith(suf)) {
return { base: modelNorm.slice(0, -suf.length), suffix: suf, allowed };
}
}
return { base: modelNorm, suffix: "", allowed };
}

function hasSafeLeftBoundary(text, startIdx) {
if (startIdx <= 0) return true;
const prevChar = text[startIdx - 1] || "";
return !(/[A-Za-z0-9]/.test(prevChar));
}

function createTextWalker(rootEl, { blockInside = [], maxLen = 600 } = {}) {
return document.createTreeWalker(
rootEl,
NodeFilter.SHOW_TEXT,
{
acceptNode(node) {
const p = node.parentElement;
if (!p) return NodeFilter.FILTER_REJECT;
for (const sel of blockInside) {
if (p.closest(sel)) return NodeFilter.FILTER_REJECT;
}
const v = node.nodeValue || "";
if (!v || v.length > maxLen) return NodeFilter.FILTER_REJECT;
return NodeFilter.FILTER_ACCEPT;
}
}
);
}

/* ============================================================
* 3. 모델명 판별
* ============================================================ */
function isLikelyModelToken(raw) {
if (!raw) return false;
const text = raw.trim();
if (!text) return false;

let check = text.split("(")[0].split("+")[0].trim();
if (!check) return false;

check = check.replace(/[‐-‒–—−]/g, "-");
if (/[가-힣]/.test(check)) return false;
if (!/^[0-9A-Za-z\-\/._ ]+$/.test(check)) return false;

const normNoSymbol = normalizeForMatching(check);
if (normNoSymbol.length < 3 || normNoSymbol.length > 30) return false;
if (isStopwordLike(normNoSymbol)) return false;

if (/^[A-Za-z]\d{1,3}\s+[A-Za-z0-9]{2,}(?:[-\/._·‐‑–—−])[A-Za-z0-9]{2,}$/.test(check)) {
return true;
}

if (/\s/.test(check)) {
const parts = check.split(/\s+/).filter(Boolean);
const subtokenOK = parts.some(p => {
const pNorm = normalizeForMatching(p);
if (!pNorm) return false;
if (isStopwordLike(pNorm)) return false;
const pHasLetter = /[A-Za-z]/.test(pNorm);
const pHasDigit = /\d/.test(pNorm);
const pHasSymbol = /[-\/._]/.test(p);
return (pHasLetter && pHasDigit) || pHasSymbol;
});
if (!subtokenOK) return false;
}

const hasLetter = /[A-Za-z]/.test(normNoSymbol);
const hasDigit = /\d/.test(normNoSymbol);
const hasHyphenOrSlashOrUnder = /[-\/_]/.test(check);

if (hasLetter && hasDigit) {
// ok
} else if (hasHyphenOrSlashOrUnder && normNoSymbol.length >= 6) {
// ok
} else if (/^[A-Za-z]{10,}$/.test(normNoSymbol)) {
// ok
} else {
return false;
}

if (/^\d+(GB|TB|MB|HZ|KHZ|MHZ|GHZ|W|WH|CM|G)$/i.test(normNoSymbol)) return false;
return true;
}

/* ============================================================
* 4. Admin 모델명 추출 (요약)
* ============================================================ */
function getAdminHeaderEl() {
return document.querySelector("div.Heading3[data-elm-id='Name__CoupangItem']");
}
function getAdminAlertItems() {
return document.querySelectorAll('li[data-elm-id="Alert__OperationNotification__item"]');
}
function getKanIdFromAdmin() {
try {
const labelSpans = Array.from(document.querySelectorAll('[data-elm-id="text"] span, [data-elm-id="text"]'));
for (const label of labelSpans) {
const t = (label.textContent || "").trim().toUpperCase();
if (t === "KAN ID") {
const container = label.closest("div");
const valueDiv = container && container.nextElementSibling ? container.nextElementSibling : null;
const raw = valueDiv ? (valueDiv.textContent || "") : "";
const m = raw.match(/\d+/);
if (m && m[0]) return m[0];
}
}
} catch (_) { }
return null;
}

function extractModelsFromAlert() {
const out = new Set();
const items = getAdminAlertItems();

items.forEach(li => {
const clone = li.cloneNode(true);
clone.querySelectorAll(`.${TEXT_MARK_CLASS}, .${TEXT_MARK_MISMATCH_CLASS}`)
.forEach(el => el.replaceWith(document.createTextNode(el.textContent || "")));
const txt = clone.textContent || "";
const lower = txt.toLowerCase();
if (!lower.includes("[model name]")) return;

const startMarker = "[model name]_";

const groupBlockAfterRegex = /\[Group\s+number\s*:\s*\d+\]\s*_/i;

const endBoundaryRegex = /_모델명\s*상관\s*없[이이]\s*대응\s*가능/i;

let startIdx = lower.indexOf(startMarker);
if (startIdx === -1) startIdx = lower.indexOf("[model name]");
if (startIdx === -1) return;

const tailFromModel = txt.slice(startIdx + startMarker.length);
const groupTailMatch = groupBlockAfterRegex.exec(tailFromModel);
if (!groupTailMatch) return; // 그룹 넘버 블록이 없으면 스킵

const segStart = startIdx + startMarker.length + groupTailMatch.index + groupTailMatch[0].length;

const tailFromSegStart = txt.slice(segStart);
const endMatch = endBoundaryRegex.exec(tailFromSegStart);
if (!endMatch) return;

const segEnd = segStart + endMatch.index;

const segment = txt.slice(segStart, segEnd);

const blocks = [...(segment.matchAll(/\[([^\]]+)\]/g))].map(m => m[1]).filter(Boolean);
if (blocks.length === 0) return;

const splitter = /\s*(?:,|\/|에|and|&|to)\s*/i;
blocks.forEach(blockStr => {
const pieces = blockStr.split(splitter).map(p => p.trim()).filter(Boolean);
pieces.forEach(piece => {
let cleaned = piece.replace(/^\[+|\]+$/g, "").trim();
if (!cleaned) return;
cleaned = cleaned.replace(/\s+/g, " ");
if (isLikelyModelToken(cleaned)) out.add(normalizeModel(cleaned));
});
});

// === [수정 끝] ===


if (out.size === 0) {
const candidates = [...(txt.matchAll(/\[([^\]]+)\]/g))].map(m => m[1]);
candidates.forEach(block => {
const blockTrim = (block || "").trim();
const bLower = blockTrim.toLowerCase();
if (!blockTrim) return;
if (bLower.startsWith("pbs-")) return;
if (bLower.startsWith("brand_")) return;
if (bLower.startsWith("group number")) return;
if (bLower === "ca" || bLower === "ce" || bLower === "al") return;

let added = false;
const tokens = blockTrim.match(/[A-Za-z0-9][A-Za-z0-9\-\/._ ]{1,}/g) || [];
tokens.forEach(token => {
const t = token.trim();
if (!t) return;
if (isLikelyModelToken(t)) { out.add(normalizeModel(t)); added = true; }
});

if (!added) {
const phrase = blockTrim.replace(/\s+/g, " ");
if (/^[A-Z0-9 ]{3,}$/.test(phrase) && /[A-Z]/.test(phrase)) {
if (!/^(GROUP NUMBER|BRAND_|PBS|CE|AL)(\b|_)/i.test(phrase)) {
out.add(normalizeModel(phrase));
}
}
}
});
}
});
return preferLongestModels([...out]);
}

/* ============================================================
* 4. Admin 모델명 추출 (개선: 헤더에서 여러 모델 동시 수집)
* ============================================================ */
function extractAdminModels() {
const models = new Set();
const alertModels = [];
const headerFoundList = []; // 순서 보존

// 1) 헤더에서 '모든' 모델 후보를 수집(단, 최종 채택은 마지막 1개)
const headerEl = getAdminHeaderEl();
if (headerEl) {
const clone = headerEl.cloneNode(true);
clone.querySelectorAll('[data-elm-id="Link__CopyVI"], [data-elm-id="CoupangItem__VendorItemId"]').forEach(el => el.remove());

const headerTextRaw = clone.textContent || "";
const headerText = headerTextRaw.replace(/\s+/g, " ").trim();

const sections = headerText.split("::").map(s => s.trim()).filter(Boolean);

for (const section of sections) {
if (!section) continue;

const candidates = section.match(/[A-Za-z0-9][A-Za-z0-9\-\/._ ]{1,}/g) || [];

for (let cand of candidates) {
if (!cand) continue;

// 1) 괄호 이후 제거
cand = (cand.split("(")[0] || "").trim();

// 2) 다중 공백 정규화
cand = cand.replace(/\s+/g, " ").trim();

// 3) 모델 뒤에 붙은 "수량/단위 꼬리(예: 25kg, + 15kg 등)" 제거
// — 헤더에서 "FH25VA 25kg" 같은 케이스를 원천 차단
cand = stripTrailingUnitSuffix(cand);

if (!cand) continue;

if (isLikelyModelToken(cand)) {
const fixed = normalizeModel(cand);
headerFoundList.push(fixed); // 순서대로 쌓기만 한다
// models.add(fixed) 하지 않음 (여러 개 중 마지막만 채택할 것이므로)
}
}

}

// 헤더에서는 여러 후보가 있으면 '가장 뒤의 1개'만 채택
if (headerFoundList.length > 0) {
const last = headerFoundList[headerFoundList.length - 1];
models.add(last);
}
}

// 2) Alert(배너)에서는 다수라도 그대로 추가 (기존 정책 유지)
extractModelsFromAlert().forEach(m => { alertModels.push(m); models.add(m); });

// 3) 디버깅 로그
console.log("✅ model name");
console.log("헤더 후보 :", headerFoundList.length ? headerFoundList.join(", ") : "(없음)");
if (headerFoundList.length > 0) {
console.log("헤더 모델명 :", headerFoundList[headerFoundList.length - 1]);
}
console.log("배너 모델명 :", alertModels.length ? alertModels.join(", ") : "(없음)");

return preferLongestModels([...models]);
}


/* ============================================================
* 5. 컬러링 공통
* ============================================================ */
function canAllowMismatch(adminModel, externalText) {
const adminNorm = normalizeForMatching(adminModel);
const externalNorm = normalizeForMatching(externalText);
const { base: adminBase, suffix: adminSuffix, allowed } = splitAllowedSuffix(adminNorm);

// 외부가 최소한 어드민 '기본'과 동일하게 시작해야 함
if (!externalNorm.startsWith(adminBase)) return null;

// 외부 기준으로 어드민 '기본' 뒤쪽 문자열(=접미사 후보) 추출
const externalSuffix = externalNorm.slice(adminBase.length);

// 외부에 접미사가 아예 없으면 불일치 아님
if (!externalSuffix) return null;

// 외부 접미사가 허용 리스트인지 확인 (예: BK, WH, SV, ... )
if (!allowed.includes(externalSuffix)) return null;

// 정책 변경 포인트:
// - 어드민에 접미사가 없어도(=adminSuffix === "") 외부의 허용 접미사가 있으면 '불일치'로 인정
// → (정책 변경) 어드민에 접미사가 없는 경우에는 불일치(빨간컬러링) 적용 금지
if (!adminSuffix) {
return null;
}

// - 어드민에 접미사가 있으면, 서로 다를 때만 '불일치'
if (adminSuffix && externalSuffix === adminSuffix) {
// 어드민과 동일한 접미사면 불일치가 아님
return null;
}

// 실제 시각적 분리는 호출부에서 처리하므로, 매칭 성공 신호만 반환
const baseLen = adminBase.length; // 주의: 정규화 길이 기준이지만 호출부에서 직접 prefix/suffix를 다시 계산함
const matchPart = externalText.slice(0, baseLen);
const mismatchPart = externalText.slice(baseLen);
return { matchPart, mismatchPart };
}


function buildLooseRegexAdmin(model) {
const normalized = normalizeForMatching(model);
const core = normalized.split("").map((ch, i) => i === normalized.length - 1 ? `${ch}` : `${ch}[-\\/_\\s]*`).join("");
const rightBoundary = `(?=$|[^A-Za-z0-9])`;
return new RegExp(`${core}${rightBoundary}`, "i");
}

function buildLooseRegexExternal(model) {
const normalized = normalizeForMatching(model);
const core = normalized.split("").map((ch, i) => i === normalized.length - 1 ? `${ch}` : `${ch}[-\\/_\\s]*`).join("");
const rightBoundary = `(?=$|[^A-Za-z0-9])`;
return new RegExp(`${core}${rightBoundary}`, "i");
}

function buildMismatchRegex(model) {
const adminNorm = normalizeForMatching(model);
const { base: adminBase, allowed } = splitAllowedSuffix(adminNorm);
const allowedPattern = allowed.join("|");
const SEP = `[\\-\\/._\\s·‐‑–—−]*`;
return new RegExp(
adminBase.split("").map(ch => ch + SEP).join("") +
`(${allowedPattern})` +
`(?=${SEP}|$)`,
"iu"
);
}

// === [ADD] 긴 모델 우선: 프리픽스(접두) 관계일 때 긴 모델만 유지 ===
function preferLongestModels(list) {
const norm = (s) => normalizeForMatching(s);
// 길이 기준 내림차순으로 정렬 (긴 것 우선)
const sorted = [...list].sort((a, b) => norm(b).length - norm(a).length);

const picked = [];
for (const cand of sorted) {
const c = norm(cand);
let covered = false;
for (const p of picked) {
const n = norm(p);
// cand가 이미 선택된 p의 접두이면 cand는 버림
if (n.startsWith(c)) { covered = true; break; }
}
if (!covered) picked.push(cand);
}
return picked;
}

// === [ADD] 허용컬러가 붙은 어드민 모델의 '기본(Base)'만 느슨 매칭하는 정규식 ===
// 예) model: "KPT02KR-BK" -> 외부에서 "KPT02KR"만 있어도 매칭(우측 경계 보장)
function buildBaseRegexWhenAllowed(model) {
const adminNorm = normalizeForMatching(model);
const { base: adminBase, suffix: adminSuffix } = splitAllowedSuffix(adminNorm);

// 어드민에 허용 컬러 접미사가 '있는' 경우에만 동작
if (!adminSuffix) return null;

// 기본(Base)만으로 느슨하게 매칭 (중간 구분자 허용), 우측 경계 보장
const core = adminBase
.split("")
.map((ch, i) => (i === adminBase.length - 1 ? `${ch}` : `${ch}[-\\/_\\s]*`))
.join("");
const rightBoundary = `(?=$|[^A-Za-z0-9])`;
return new RegExp(`${core}${rightBoundary}`, "i");
}

function unpaintInside(root) {
if (!root) return;
const all = root.querySelectorAll(`.${TEXT_MARK_CLASS}, .${TEXT_MARK_MISMATCH_CLASS}`);
for (const span of all) {
const parent = span.parentNode;
if (!parent) continue;
const text = document.createTextNode(span.textContent || "");
parent.replaceChild(text, span);
if (typeof parent.normalize === "function") parent.normalize();
}
}

/* ==================== 어드민 컬러링 ==================== */
function highlightInElementAdmin(el, models) {
if (!el || !models.length) return;

// ★ [PATCH-HEADER-ONE] 헤더 엘리먼트 여부 판단
const headerEl = getAdminHeaderEl && getAdminHeaderEl();
const isHeader = headerEl && el === headerEl;

// ★ [PATCH-HEADER-ONE] 헤더일 때는 "마지막(우측) 1회"만 칠하고 즉시 종료
if (isHeader) {
// 헤더에 이미 모델 하이라이트가 하나라도 있으면 '추가 칠하기' 방지(재호출 대비)
if (el.querySelector(`.${TEXT_MARK_CLASS}, .${TEXT_MARK_MISMATCH_CLASS}`)) {
return;
}

// extractAdminModels()가 최종 채택한 모델(마지막 1개)
const model = models[models.length - 1];
if (!model) return;

// 헤더 영역에서 "가장 뒤"의 미표시 매칭 위치만 찾기
const walker = createTextWalker(el, { blockInside: [`.${TEXT_MARK_CLASS}`, `.${TEXT_MARK_MISMATCH_CLASS}`], maxLen: 600 });
const baseRe = buildLooseRegexAdmin(model);
// 노드 하나에 동일 모델이 여러 번 있을 수 있으므로 g 플래그로 전체 탐색
const baseReSource = baseRe.source;
const baseReFlags = baseRe.flags.includes('g') ? baseRe.flags : (baseRe.flags + 'g');

let best = { order: -1, idx: -1, len: 0, node: null };
const nodes = [];
let n;
while ((n = walker.nextNode())) nodes.push(n);

nodes.forEach((node, order) => {
const txt = node.nodeValue || "";
if (!txt) return;
const reAll = new RegExp(baseReSource, baseReFlags);
let m, localIdx = -1, localLen = 0;

while ((m = reAll.exec(txt)) !== null) {
const sIdx = m.index;
if (!hasSafeLeftBoundary(txt, sIdx)) continue;
localIdx = sIdx;
localLen = m[0].length; // 노드 내에서 '가장 뒤' 매칭으로 계속 갱신
}

if (localIdx >= 0) {
// 문서 순서가 더 뒤이거나, 같은 노드면 인덱스가 더 뒤인 것을 채택
if (order > best.order || (order === best.order && localIdx > best.idx)) {
best = { order, idx: localIdx, len: localLen, node };
}
}
});

if (best.node) {
// 마지막 1곳만 칠하고 즉시 종료(배너 로직 실행 금지)
applyHeaderHighlight(best.node, best.idx, best.len);
}
return;
}

// =======================
// 헤더가 아닐 때(배너 등): 기존 로직 그대로
// =======================
const regexes = models.map(buildLooseRegexAdmin);
const walker = createTextWalker(el, { blockInside: [`.${TEXT_MARK_CLASS}`], maxLen: 600 });
const paintedOnce = new Set();

let node;
while ((node = walker.nextNode())) {
for (let i = 0; i < regexes.length; i++) {
const re = regexes[i];
const modelKey = models[i];
if (paintedOnce.has(modelKey)) continue;

const m = re.exec(node.nodeValue);
if (!m) continue;

const startIdx = m.index;
if (!hasSafeLeftBoundary(node.nodeValue, startIdx)) continue;

const full = m[0];
const trimmed = full.replace(/[-\/_\s]+$/, "");
if (!trimmed) continue;

paintedOnce.add(modelKey);

const suffix = full.slice(trimmed.length);
const span = document.createElement("span");
span.className = TEXT_MARK_CLASS;
span.textContent = trimmed;

const before = document.createTextNode(node.nodeValue.slice(0, startIdx));
const suffixNode = document.createTextNode(suffix);
const after = document.createTextNode(node.nodeValue.slice(startIdx + full.length));

const parent = node.parentNode;
parent.insertBefore(before, node);
parent.insertBefore(span, node);
parent.insertBefore(suffixNode, node);
parent.insertBefore(after, node);
parent.removeChild(node);
break;
}
}

// === [PATCH-HEADER-ONE] 헤더 단일 칠하기 전용 유틸 ===
function applyHeaderHighlight(node, idx, len) {
const text = node.nodeValue;
const parent = node.parentNode;
if (!parent) return;

const before = document.createTextNode(text.slice(0, idx));
const full = text.slice(idx, idx + len);
const after = document.createTextNode(text.slice(idx + len));

const trimmed = full.replace(/[-\/_\s]+$/, "");
const suffix = full.slice(trimmed.length);

const span = document.createElement("span");
span.className = TEXT_MARK_CLASS;
span.textContent = trimmed;

const suffixNode = document.createTextNode(suffix);

parent.insertBefore(before, node);
parent.insertBefore(span, node);
parent.insertBefore(suffixNode, node);
parent.insertBefore(after, node);
parent.removeChild(node);
}
}
/* ==================== 어드민 컬러링 끝 ==================== */


/* ============================================================
* 5-β. 외부 컬러링(스냅샷 순회) — 중간 멈춤 방지
* ============================================================ */
function highlightInElementExternal(el, models) {
if (!el || !models.length) return;

const walker = createTextWalker(el, { blockInside: [`.${TEXT_MARK_CLASS}`, `.${TEXT_MARK_MISMATCH_CLASS}`], maxLen: 600 });
// 1) 텍스트 노드 스냅샷 수집(변형 중 건너뛰기 방지)
const nodes = [];
let n; while ((n = walker.nextNode())) nodes.push(n);

const isHighlightWorthy = (text) => {
const norm = normalizeForMatching(text);
if (!norm) return false;
if (isDimensionLikeText(text)) return false;
if (isStopwordLike(norm)) return false;
if (/\b\d+(\.\d+)?\s*(G|KG|M|KM|CM|MM|IN|L|ML)\b/i.test(text)) return false;
if (/\d/.test(norm)) return true;
if (/[-\/_]/.test(text) && norm.length >= 6) return true;
if (/^[A-Z]{10,}$/.test(norm)) return true;
return false;
};

// ★ [PATCH-SUFFIX-INFER] ─────────────────────────────────────────────
// 모델에서 "영문-only prefix + (영+숫자) suffix token" 구조를 찾아
// 외부 컬러링용으로 suffix token을 추가(단, 숫자 포함 prefix 사례가 존재하면 해당 token은 차단)
const __norm = (s) => normalizeForMatching(s || "");

function __splitPrefixSuffixToken(modelRaw) {
const raw = String(modelRaw || "").trim();
if (!raw) return null;
const parts = raw.split(/\s+/);
let suffixIdx = -1;
for (let i = parts.length - 1; i >= 0; i--) {
if (/\d/.test(parts[i])) { suffixIdx = i; break; } // 숫자 포함 토큰
}
if (suffixIdx === -1) return null; // 숫자 포함 토큰이 없다면 코드형 모델로 보기 어려움
const prefix = parts.slice(0, suffixIdx).join(" ").trim();
const token = parts[suffixIdx];
const englishOnlyPrefix = !!prefix && /^[A-Za-z\s]+$/.test(prefix) && !/\d/.test(prefix);
const digitInPrefix = /\d/.test(prefix);
return { prefix, token, englishOnlyPrefix, digitInPrefix };
}

// 1) 차단 목록(숫자 포함 prefix를 가진 복합 모델의 suffix token)
const blockedSuffixSet = new Set();
// 2) 안전한 suffix token 후보
const safeSuffixTokens = new Set();

for (const m of models) {
const info = __splitPrefixSuffixToken(m);
if (!info || !info.token) continue;
const tokNorm = __norm(info.token);
if (info.digitInPrefix) {
blockedSuffixSet.add(tokNorm);
}
}
for (const m of models) {
const info = __splitPrefixSuffixToken(m);
if (!info || !info.token) continue;
const tokNorm = __norm(info.token);
if (info.englishOnlyPrefix && !blockedSuffixSet.has(tokNorm)) {
safeSuffixTokens.add(info.token); // 예: "Magic Mouse MXK53KH/A" → "MXK53KH/A" 추가
}
}

// 외부 컬러링용 모델 목록 = 원래 models + 안전한 suffix token들
const modelsExtended = Array.from(new Set([...models, ...safeSuffixTokens]));
// ★ [PATCH-SUFFIX-INFER] ─────────────────────────────────────────────

// 2) 노드 배열을 돌며 적용
for (const node of nodes) {
if (!node || !node.parentNode) continue;

let applied = false;
// ★ [PATCH-SUFFIX-INFER] 여기서부터 models 대신 modelsExtended 사용
for (let i = 0; i < modelsExtended.length; i++) {
const model = modelsExtended[i];

// (a) 허용 불일치 먼저: ex) admin KPT02KR-BK, external KPT02KR-RD => RD만 진한 주황
const { suffix: adminSuffixForGuard } = splitAllowedSuffix(normalizeForMatching(model));
if (adminSuffixForGuard) {
const mmRe = buildMismatchRegex(model);
const mm = mmRe.exec(node.nodeValue);
if (mm) {
if (hasSafeLeftBoundary(node.nodeValue, mm.index)) {
const info = canAllowMismatch(model, mm[0]);
if (info) {
const full = mm[0];
if (isHighlightWorthy(full)) {
const allowed = MISMATCH_ALLOWED_CHARS.map(c => c.toUpperCase()).sort((a, b) => b.length - a.length);
let suffix = "";
for (const a of allowed) {
if (full.toUpperCase().endsWith(a)) { suffix = full.slice(-a.length); break; }
}
const prefix = full.slice(0, full.length - suffix.length);

const before = document.createTextNode(node.nodeValue.slice(0, mm.index));
const matchSpan = document.createElement("span"); matchSpan.className = TEXT_MARK_CLASS; matchSpan.textContent = prefix;
const mismatchSpan = document.createElement("span"); mismatchSpan.className = TEXT_MARK_MISMATCH_CLASS; mismatchSpan.textContent = suffix;
const after = document.createTextNode(node.nodeValue.slice(mm.index + full.length));

const parent = node.parentNode;
parent.insertBefore(before, node);
parent.insertBefore(matchSpan, node);
parent.insertBefore(mismatchSpan, node);
parent.insertBefore(after, node);
parent.removeChild(node);

applied = true;
break;
}
}
}
}
}

// === (c) 기본형(색상 생략) 완전 일치 ===
if (!applied) {
const baseRe = buildBaseRegexWhenAllowed(model);
if (baseRe) {
const bm = baseRe.exec(node.nodeValue);
if (bm) {
const startIdx = bm.index;
if (hasSafeLeftBoundary(node.nodeValue, startIdx)) {
const full = bm[0];
const trimmed = full.replace(/[-\/_\s]+$/, "");
if (trimmed && isHighlightWorthy(trimmed)) {
const afterStr = node.nodeValue.slice(startIdx + bm[0].length);
const allowedPattern = MISMATCH_ALLOWED_CHARS
.map(c => c.toUpperCase())
.sort((a, b) => b.length - a.length)
.join("|");
const SEP = `[-\\/_\\.\\s·‐‑–—−]*`;
const allowedSuffixAhead = new RegExp(`^${SEP}(?:${allowedPattern})\\b`, "i").test(afterStr);

if (!allowedSuffixAhead) {
const hasAnySuffixToken = new RegExp(`^${SEP}[A-Za-z0-9]+`).test(afterStr);
if (!hasAnySuffixToken) {
const before = document.createTextNode(node.nodeValue.slice(0, startIdx));
const span = document.createElement("span"); span.className = TEXT_MARK_CLASS; span.textContent = trimmed;
const suffixNode = document.createTextNode(full.slice(trimmed.length));
const after = document.createTextNode(node.nodeValue.slice(startIdx + bm[0].length));

const parent = node.parentNode;
parent.insertBefore(before, node);
parent.insertBefore(span, node);
parent.insertBefore(suffixNode, node);
parent.insertBefore(after, node);
parent.removeChild(node);

applied = true;
break;
}
}
}
}
}
}
}
// === (c) 끝 ===

// (b) 일반 느슨 매칭(모델/추가된 suffix token 모두 이 경로로 매칭 가능)
if (!applied) {
const re = buildLooseRegexExternal(model);
const m = re.exec(node.nodeValue);
if (m) {
const startIdx = m.index;
const prevChar = startIdx > 0 ? node.nodeValue[startIdx - 1] : "";
if (prevChar && /[A-Za-z0-9]/.test(prevChar)) {
continue;
}
const full = m[0];
const trimmed = full.replace(/[-\/_\s]+$/, "");
if (!trimmed) continue;
if (!isHighlightWorthy(trimmed)) continue;

const suffix = full.slice(trimmed.length);

const before = document.createTextNode(node.nodeValue.slice(0, startIdx));
const span = document.createElement("span"); span.className = TEXT_MARK_CLASS; span.textContent = trimmed;
const suffixNode = document.createTextNode(suffix);
const after = document.createTextNode(node.nodeValue.slice(startIdx + full.length));

const parent = node.parentNode;
parent.insertBefore(before, node);
parent.insertBefore(span, node);
parent.insertBefore(suffixNode, node);
parent.insertBefore(after, node);
parent.removeChild(node);

applied = true;
break;
}
}
}
if (!applied) continue;
}
}

/* ============================================================
* 6. 실행
* ============================================================ */
function runAdmin() {
// 토글 꺼져있으면 즉시 종료
chrome.storage.local.get(["__ext_model_enabled", "__ext_last_unit"], (res) => {
if (res.__ext_model_enabled !== true) {
unpaintAll();
return;
}

const unit = res.__ext_last_unit; // [추가]
const kanId = getKanIdFromAdmin(); // [추가]

if (unit !== "Electronics" && unit !== "Computer & Digital") {
// [변경] 전역 모델을 비우지 않음 (외부 컬러링 유지)
return;
}

if (kanId && KANID_BLOCKLIST.has(String(kanId))) {
// [변경] 전역 모델을 비우지 않음 (외부 컬러링 유지)
return;
}

const models = extractAdminModels();
if (!models.length) {
// [변경] 전역 모델을 비우지 않음 (외부 컬러링 유지)
return;
}

chrome.storage.local.set({ [STORAGE_KEY_MODELS]: models });

// [추가] 최근 성공 모델 스냅샷 + 저장 시각
chrome.storage.local.set({
[SNAPSHOT_KEY]: models,
[SNAPSHOT_AT_KEY]: Date.now()
});

// 테스트 칠하기
highlightInElementAdmin(getAdminHeaderEl(), models);
document.querySelectorAll('.ant-alert-content').forEach(el => highlightInElementAdmin(el, models));
});
}

// [추가] 외부 탭이 먼저 열려 모델이 아직 없을 때를 위한 '빠른 재조회' 루프
let __ext_model_retry_t = null;
function quickRefetchModels() {
if (__ext_model_retry_t) return; // 중복 방지
const delays = [100, 250, 500, 900];
let i = 0;

const tick = () => {
if (i >= delays.length) { __ext_model_retry_t = null; return; }
chrome.storage.local.get(["__ext_model_enabled", STORAGE_KEY_MODELS], (res) => {
if (res.__ext_model_enabled !== true) { __ext_model_retry_t = null; return; }
const models = res[STORAGE_KEY_MODELS] || [];
if (Array.isArray(models) && models.length) {
try { highlightInElementExternal(document.body, models); } catch (_) { }
__ext_model_retry_t = null;
return;
}
__ext_model_retry_t = setTimeout(tick, delays[i++]);
});
};

__ext_model_retry_t = setTimeout(tick, delays[i++]);
}

function runExternal() {
if (isBlacklistedSite()) { unpaintAll(); return; }

// ✅ 토글 꺼져있으면 즉시 종료
chrome.storage.local.get(["__ext_model_enabled", STORAGE_KEY_MODELS], res => {
if (res.__ext_model_enabled !== true) {
unpaintAll();
return;
}
const models = res[STORAGE_KEY_MODELS] || [];
if (!models.length) {
// [추가] 스냅샷이 있고 TTL 이내면 즉시 칠하기
chrome.storage.local.get([SNAPSHOT_KEY, SNAPSHOT_AT_KEY], snap => {
const arr = snap[SNAPSHOT_KEY] || [];
const at = snap[SNAPSHOT_AT_KEY] || 0;
const fresh = (Date.now() - at) <= SNAPSHOT_TTL_MS;
if (Array.isArray(arr) && arr.length && fresh) {
try { highlightInElementExternal(document.body, arr); } catch (_) { }
} else {
// 신선한 스냅샷 없으면 기존 표시를 지우되…
unpaintAll();
}
// …저장 지연 대비 짧은 재조회 시작
quickRefetchModels();
});
return;
}

// 1) 모델 먼저 칠하기(스냅샷 방식: 중간 멈춤 방지)
highlightInElementExternal(document.body, models);
});
}

/* ============================================================
* 7. 엔진
* ============================================================ */
const debounced = debounce(() => {
if (isAdminPage()) runAdmin();
else runExternal();
}, 120);

function debounce(fn, wait) {
let t;
return () => {
clearTimeout(t);
t = setTimeout(fn, wait);
};
}

function __awaitBL(cb) {
if (__bl_loaded__) { cb(); return; }
const t = setInterval(() => {
if (__bl_loaded__) { clearInterval(t); cb(); }
}, 20);
}
const __gated = () => __awaitBL(debounced);

window.addEventListener("hashchange", __gated);
document.addEventListener("DOMContentLoaded", __gated);
new MutationObserver(__gated).observe(document.body, { childList: true, subtree: true });
if (document.readyState !== "loading") __gated();
// ✅ 모델명 강제 재평가 메시지 처리(자동검색 직후 BG가 여러 번 쏘는 훅)
chrome.runtime.onMessage.addListener((msg) => {
if (!msg || !msg.action) return;
if (msg.action === "model_refresh") {
if (isAdminPage()) runAdmin();
else runExternal();
}
});
// [추가] 외부 탭: STORAGE에 모델이 뒤늦게 들어오면 즉시 칠하기
chrome.storage.onChanged.addListener((changes, area) => {
if (area !== "local") return;
if (!changes || !changes[STORAGE_KEY_MODELS]) return;
if (isAdminPage()) return; // Admin 화면은 runAdmin이 따로 돈다

const models = changes[STORAGE_KEY_MODELS].newValue || [];
if (Array.isArray(models) && models.length) {
try { highlightInElementExternal(document.body, models); } catch (_) { }
}
});

log("Loaded at", host, path, { scoped: isScopedHost() });
})();
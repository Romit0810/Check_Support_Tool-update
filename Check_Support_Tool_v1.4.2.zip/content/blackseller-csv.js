// ============================================================
// blackseller-csv.js
// 블랙셀러 페이지에서 직접 검색하는 방식
// admin.js+blackseller-csv.js였던걸 분리함
// ============================================================

console.log("[CONTENT] blackseller-csv.js 로드됨:", location.href);

(function () {

// 공통 상수 / 유틸 함수
const HIGHLIGHT_COLOR = "#ffff00"; // ON 또는 ALL인경우 (노란색)
const HIGHLIGHT_GRAY = "#d9d9d9"; // OFF인경우 (연회색)

// KAN ID / UNITNAME 형식 체크용 정규식
const KAN_REGEX = /^[0-9]{3,4}$/;
const UNIT_REGEX = /^[A-Za-z0-9&, ]+$/;

// 문자열 정리 (공백 통일)
const tnorm = (s) => (s || "").replace(/\s+/g, " ").trim();

// 대소문자 무시 비교
const ciEq = (a, b) => tnorm(a).toLowerCase() === tnorm(b).toLowerCase();

// 블랙셀러 페이지 감지

function isBlackSeller() {
return location.protocol === "file:";
}

function findKanidHeader() {
const all = document.querySelectorAll("th, td, div, span");
for (const el of all) {
const txt = tnorm(el.textContent || "");
if (ciEq(txt, "KANID")) {
return el.closest("th") || el;
}
}
return null;
}

function findBSHeader() {
const all = document.querySelectorAll("th, td, div, span");
for (const el of all) {
const txt = tnorm(el.textContent || "");
if (ciEq(txt, "블랙셀러 여부")) {
return el.closest("th") || el;
}
}
return null;
}

function getKanidColumnInfo() {
const headerEl = findKanidHeader();
const bsHeader = findBSHeader();

if (!headerEl || !bsHeader) return null;

const table = headerEl.closest("table");
if (!table) return null;

const headerRow = headerEl.parentElement;
const cells = Array.from(headerRow.children);
const colIndex = cells.indexOf(headerEl);

const bsRow = bsHeader.parentElement;
const bsCells = Array.from(bsRow.children);
const bsIndex = bsCells.indexOf(bsHeader);

return { table, colIndex, bsIndex };
}

// 검색 여부 확인
function isSearchBlank() {
const inp = document.querySelector("#searchInput");
return !inp || !inp.value || inp.value.trim() === "";
}

function hasBSResults(retry = 0) {
const tbl = document.querySelector("#dataTable");
if (!tbl) return false;

const rows = tbl.querySelectorAll("tbody tr, tr");
const valid = Array.from(rows).some(
tr => tr.querySelector("td") && tr.textContent.trim() !== ""
);

if (!valid && retry < 3) {
console.warn(`[CONTENT] 데이터테이블 비어있음 → 재시도 ${retry + 1}`);
setTimeout(() => hasBSResults(retry + 1), 400);
return false;
}

return valid;
}

// 배너 렌더링
function ensureBannerAboveTable(text, tableEl, highlight) {
const id = "__ext_bs_banner__";
let banner = document.getElementById(id);

if (!banner) {
banner = document.createElement("div");
banner.id = id;
banner.style.fontSize = "14px";
banner.style.fontWeight = "700";
banner.style.padding = "6px 10px";
banner.style.display = "inline-block"; // 글씨 길이만큼만 배경
banner.style.margin = "0 0 8px 0";
banner.style.borderRadius = "8px"; // 둥근정도
banner.style.lineHeight = "1.2";
banner.style.whiteSpace = "nowrap"; // 한 줄 유지
}

// - highlight === "error" → 검정 배경 + 흰 글씨
// - highlight === true → (ON/ALL) 노란 배경 + 검정 글씨
// - 그 외(false/undefined) → 배경 없음 + 검정 글씨
if (highlight === "error") {
banner.style.background = "#ff0000ff";
banner.style.color = "#ffffff";
} else if (highlight === true) {
banner.style.background = "#ffff00";
banner.style.color = "#000000";
} else {
banner.style.background = "transparent";
banner.style.color = "#000000";
}

if (banner.textContent !== text) {
banner.textContent = text;
}

if (!(banner.parentNode === tableEl.parentNode && banner.nextSibling === tableEl)) {
tableEl.parentNode.insertBefore(banner, tableEl);
}
}

// 테이블 하이라이트
function highlightWithinKanidColumn(kan) {
const info = getKanidColumnInfo();
if (!info) return { hasKAN: false, hasALL: false, table: null };

const { table, colIndex, bsIndex } = info;

if (isSearchBlank() || !hasBSResults()) {
return { hasKAN: false, hasALL: false, table };
}

let hasKAN = false;
let hasALL = false;

const rows = table.tBodies && table.tBodies.length
? Array.from(table.tBodies).flatMap(tb => Array.from(tb.rows))
: Array.from(table.rows);

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({
"&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;"
}[c]));

const ALL_WORD_RE = /\ball\b/i;

for (const row of rows) {

const cell = row.cells && row.cells[colIndex];
const bsCell = row.cells && row.cells[bsIndex];

if (!cell || !bsCell) continue;

const rawTxt = cell.textContent || "";
const txt = tnorm(rawTxt);
const bsTxt = tnorm(bsCell.textContent || "");

if (!txt) continue;

if (txt.includes(String(kan)) && ciEq(bsTxt, "Blackseller On")) {
const idx = txt.indexOf(String(kan));
const before = esc(txt.slice(0, idx));
const match = esc(txt.slice(idx, idx + String(kan).length));
const after = esc(txt.slice(idx + String(kan).length));
cell.innerHTML = `${before}<mark data-ext-highlight-bs="1">${match}</mark>${after}`;
hasKAN = true;
continue;
}

const allMatch = txt.match(ALL_WORD_RE);
if (allMatch && ciEq(bsTxt, "Blackseller On")) {
const idx = txt.toLowerCase().indexOf(allMatch[0].toLowerCase());
const before = esc(txt.slice(0, idx));
const match = esc(txt.slice(idx, idx + 3));
const after = esc(txt.slice(idx + 3));
cell.innerHTML = `${before}<mark data-ext-highlight-bs="1">${match}</mark>${after}`;
hasALL = true;
continue;
}

if (txt.includes(String(kan))) {
cell.innerHTML = `<mark data-ext-highlight-bs="gray">${esc(txt)}</mark>`;
continue;
}

if (allMatch) {
cell.innerHTML = `<mark data-ext-highlight-bs="gray">${esc(txt)}</mark>`;
continue;
}
}

return { hasKAN, hasALL, table };
}

// 블랙셀러 메인

function runBlackSeller() {

chrome.storage.local.get(["__ext_last_kan"], (res) => {

const kan = res.__ext_last_kan;

if (!kan) {
const old = document.getElementById("__ext_bs_banner__");
if (old) old.remove();
return;
}

const { hasKAN, hasALL, table } =
highlightWithinKanidColumn(String(kan));

if (!table) {
const old = document.getElementById("__ext_bs_banner__");
if (old) old.remove();
return;
}

let banner = `KAN ID : ${kan}`;
let highlight = false;

if (hasKAN) { banner += " / 블랙셀러 ON"; highlight = true; }
if (hasALL) { banner += " / 블랙셀러 ALL"; highlight = true; }

ensureBannerAboveTable(banner, table, highlight);
});
}

// 전체 실행
function main() {

if (isBlackSeller()) {

function safeRunBlackSeller() {
// 오류 상세 문구를 위해 필요한 키를 함께 읽음
chrome.storage.local.get(["__ext_admin_error", "__ext_admin_tabs", "__ext_admin_viid_ok"], (res) => {

// 먼저 현재 table 존재 여부 확인
const info = getKanidColumnInfo();
const table = info && info.table;

// 표 자체가 없으면 (CSV 미검색 상태와 동일)
if (!table) {
const old = document.getElementById("__ext_bs_banner__");
if (old) old.remove();
return;
}

// 오류일 때 상세 사유 반영
if (res.__ext_admin_error) {
const adminTabs = Number(res.__ext_admin_tabs || 0);
const hasViid = !!res.__ext_admin_viid_ok;

// 기본 메시지
let msg = "사용불가";

// VIID 미검색 조건: 어드민 없음 또는 검색 안 됨
if (adminTabs === 0 || !hasViid) {
msg = "사용불가ㅣVIID 미검색";
}
// 어드민 두개 이상
else if (adminTabs > 1) {
msg = "사용불가ㅣ어드민 여러개";
}

// 배너 표시 (검정 배너 + 흰 글씨)
ensureBannerAboveTable(msg, table, "error");

// 하이라이트 제거
document
.querySelectorAll("[data-ext-highlight-bs]")
.forEach(el => {
el.style.background = "";
el.removeAttribute("data-ext-highlight-bs");
});

return;
}

// 정상일 때만 기존 로직 실행
runBlackSeller();
});
}


safeRunBlackSeller();

let raf;
const mo = new MutationObserver(() => {
if (raf) cancelAnimationFrame(raf);
raf = requestAnimationFrame(safeRunBlackSeller);
});

mo.observe(document.body, { childList: true, subtree: true });

chrome.storage.onChanged.addListener((changes, area) => {
if (area !== "local") return;

// KAN 변경 → 즉시 반영
if ("__ext_last_kan" in changes) {
console.log("[CONTENT] __ext_last_kan 변경:", changes.__ext_last_kan.newValue);
safeRunBlackSeller();
}

// 오류 플래그 변경 → 즉시 반영
if ("__ext_admin_error" in changes) {
console.log("[CONTENT] __ext_admin_error 변경:", changes.__ext_admin_error.newValue);
safeRunBlackSeller();
}

// admin1 탭 수 변경 → “어드민 여러개/없음/정상” 문구 즉시 반영
if ("__ext_admin_tabs" in changes) {
console.log("[CONTENT] __ext_admin_tabs 변경:", changes.__ext_admin_tabs.newValue);
safeRunBlackSeller();
}

// VIID 검색 성공 여부 변경 → “VIID 미검색/정상” 문구 즉시 반영
if ("__ext_admin_viid_ok" in changes) {
console.log("[CONTENT] __ext_admin_viid_ok 변경:", changes.__ext_admin_viid_ok.newValue);
safeRunBlackSeller();
}
});

const search = document.querySelector("#searchInput");
if (search) {
["input", "change", "keyup", "search"].forEach(ev =>
search.addEventListener(ev, () => safeRunBlackSeller())
);
}
}

}

// DOM 로딩 후 실행
if (document.readyState === "loading") {
document.addEventListener("DOMContentLoaded", main);
} else {
main();
}

// 스타일 삽입
const style = document.createElement("style");
style.textContent = `
[data-ext-highlight-bs="1"] { background: ${HIGHLIGHT_COLOR} !important; }
[data-ext-highlight-bs="gray"] { background: ${HIGHLIGHT_GRAY} !important; }
`;
document.documentElement.appendChild(style);

})();
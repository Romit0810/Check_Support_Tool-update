/*************************************************
* Coupang Price Admin Helper - ce.js
*************************************************/

const TOGGLE_KEY = "__ext_ce_required_enabled";
const FOLD_STATE_KEY = "__ext_ce_is_collapsed"; // 접힘 상태를 저장할 키 추가
const KAN_REGEX = /^[0-9]{3,4}$/;

const STATE = {
enabled: false,
csvLoaded: false,
lastKanId: null,
toastEl: null,
isCollapsed: false // 초기화 시 스토리지에서 읽어올 예정
};

let KAN_MAP = {};

// ... (기존 유틸리티/파싱 함수는 동일함) ...
const norm = (s) => (s || "").toLowerCase().replace(/\s+/g, "");
function normalizeKanId(v) { return (v || "").replace(/\uFEFF/g, "").replace(/[^\d]/g, "").trim(); }
function splitItems(text) { if (!text) return []; return text.split(/\r?\n|\|/g).map(t => t.trim()).filter(Boolean); }
function findHeaderIndex(headerArr, candidates) {
const normHeader = headerArr.map(h => norm(h));
for (const c of candidates) {
const target = norm(c);
let i = normHeader.findIndex(h => h === target);
if (i >= 0) return i;
i = normHeader.findIndex(h => h.includes(target));
if (i >= 0) return i;
}
return -1;
}

function parseCSVWithQuotes(text) {
const rows = []; let row = []; let field = ""; let inQuotes = false;
const pushField = () => { row.push(field); field = ""; };
const pushRow = () => { if (row.length && row.some(c => (c || "").trim() !== "")) rows.push(row); row = []; };
for (let i = 0; i < text.length; i++) {
const ch = text[i]; const next = text[i + 1];
if (ch === '"') { if (inQuotes && next === '"') { field += '"'; i++; } else { inQuotes = !inQuotes; } continue; }
if (ch === "," && !inQuotes) { pushField(); continue; }
if ((ch === "\n" || ch === "\r") && !inQuotes) { if (ch === "\r" && next === "\n") i++; pushField(); pushRow(); continue; }
field += ch;
}
pushField(); pushRow(); return rows;
}


// UI 뼈대 생성
function ensureToast() {
if (STATE.toastEl) return STATE.toastEl;

const el = document.createElement("div");
el.id = "kan-helper-toast";
// 3컬럼 간격 조정: 75px(KANID) / 1fr(Product) / 60px(필수여부)
el.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647;width:380px;background:rgba(40,40,40,0.90);color:#fff;padding:15px;border-radius:10px;box-shadow:0 8px 25px rgba(0,0,0,0.4);font-family:sans-serif;border:1px solid rgba(255,255,255,0.1); transition: opacity 0.2s ease; display: none;";

el.innerHTML = `
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
<div style="font-weight:800;font-size:13px;opacity:0.8;">KANID Helper</div>
<button id="kan-fold-btn" style="background:rgba(255,255,255,0.1);border:none;color:#fff;cursor:pointer;font-size:14px;padding:2px 8px;border-radius:4px;">▾</button>
</div>

<div style="display:grid;grid-template-columns: 80px 1.1fr 1fr; gap:8px; margin-bottom:12px; align-items: start;">
<div>
<div style="opacity:0.6;font-size:12px;">KANID</div>
<div id="t-kanid" style="font-weight:900;font-size:15px;margin-top:2px;"></div>
</div>
<div>
<div style="opacity:0.6;font-size:12px;">Product</div>
<div id="t-Product" style="font-weight:800;font-size:13px;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"></div>
</div>
<div style="text-align:left; padding-left:5px;">
<div style="opacity:0.6;font-size:12px;">필수여부</div>
<div id="t-has-required" style="font-weight:900;font-size:16px;margin-top:2px;"></div>
</div>
</div>

<div id="kan-details">
<div style="border-top:1px solid rgba(255,255,255,0.1);padding-top:10px;">
<div style="opacity:0.6;font-size:12px;">BRAND</div><div id="t-brand" style="font-weight:600;font-size:13px;margin-top:2px;"></div>
</div>
<div style="margin-top:10px;padding-top:10px;">
<div style="opacity:0.6;font-size:12px;">필수속성</div>
<ul id="t-required" style="margin:5px 0 0;padding-left:16px;line-height:1.6;list-style:square;font-size:12px;"></ul>
</div>
</div>
`;

document.body.appendChild(el);
const foldBtn = el.querySelector("#kan-fold-btn");
const details = el.querySelector("#kan-details");

foldBtn.onclick = async () => {
STATE.isCollapsed = !STATE.isCollapsed;
// 접힘 상태를 스토리지에 저장
await chrome.storage.local.set({ [FOLD_STATE_KEY]: STATE.isCollapsed });
applyFold();
};

function applyFold() {
details.style.display = STATE.isCollapsed ? "none" : "block";
foldBtn.textContent = STATE.isCollapsed ? "▴" : "▾";
}

el.applyFold = applyFold;
STATE.toastEl = el;
return el;
}

function updateContent(kanId) {
const data = KAN_MAP[kanId];
const toast = ensureToast();

toast.querySelector("#t-kanid").textContent = kanId;
toast.querySelector("#t-Product").textContent = data ? data.Product : "CE X";
toast.querySelector("#t-brand").textContent = data ? data.brand : "-";

const hasRequiredEl = toast.querySelector("#t-has-required");
if (data && data.requiredItems.length > 0) {
hasRequiredEl.textContent = "O";
hasRequiredEl.style.color = "#4ade80";
} else {
hasRequiredEl.textContent = "X";
hasRequiredEl.style.color = "#ff6b6b";
}

const ul = toast.querySelector("#t-required");
ul.innerHTML = "";
const items = (data && data.requiredItems.length > 0) ? data.requiredItems : ["전체적인 동일비교 및 카테고리 심화를 참고해주세요"];
items.forEach(it => {
const li = document.createElement("li"); li.textContent = it; ul.appendChild(li);
});

toast.applyFold();
toast.style.display = "block";
}

async function reevaluate() {
// 스토리지에서 토글 상태, KANID뿐만 아니라 '접힘 상태'도 함께 가져옴
const got = await chrome.storage.local.get([TOGGLE_KEY, "__ext_last_kan", "__ext_admin_error", FOLD_STATE_KEY]);

STATE.enabled = got[TOGGLE_KEY] === true;
STATE.isCollapsed = got[FOLD_STATE_KEY] === true; // 저장된 접힘 상태 업데이트

const kan = String(got.__ext_last_kan || "").trim();
const isValidKan = kan && KAN_REGEX.test(kan);

if (!STATE.enabled || got.__ext_admin_error || !isValidKan) {
if (STATE.toastEl) STATE.toastEl.style.display = "none";
STATE.lastKanId = null;
return;
}

if (kan !== STATE.lastKanId) {
STATE.lastKanId = kan;
updateContent(kan);
} else if (STATE.toastEl) {
// ID는 같아도 접힘 상태가 스토리지 변경으로 바뀔 수 있으므로 재적용
STATE.toastEl.applyFold();
if (STATE.toastEl.style.display === "none") STATE.toastEl.style.display = "block";
}
}
// [ce.js 하단부 통합 수정본]

// 1. 데이터 처리기 (이름이 달라도 무조건 찾기)
function processMasterData(masterData) {
const map = {};
// 1. 탭 이름 'kanid' 찾기
const tabKey = Object.keys(masterData).find(k => k.toLowerCase() === 'kanid');
const kanRows = masterData[tabKey] || [];

console.log("[CE] 📊 분석 시작 - 탭이름:", tabKey, "/ 행 개수:", kanRows.length);

kanRows.forEach((row, idx) => {
// 2. 시트 헤더 명칭과 정확히 일치하는 값들을 가져옵니다.
// row["헤더명"] 방식을 써야 'Kan ID'처럼 공백이 있는 이름을 읽을 수 있습니다.

// Kan ID (메인 키)
const rawKanId = row["Kan ID"] || row["kanid"] || "";
const kanId = normalizeKanId(String(rawKanId));

if (kanId) {
map[kanId] = {
// Product (참고용)
Product: (row["Product"] || "-").trim(),
// brand 구분
brand: (row["brand 구분"] || "-").trim(),
// 필수속성 (splitItems 함수로 리스트화)
requiredItems: splitItems(row["필수속성"] || "")
};

// 첫 번째 데이터만 샘플로 로그를 찍어봅니다.
if (Object.keys(map).length === 1) {
console.log("[CE] 🎯 첫 번째 데이터 매핑 성공:", map[kanId]);
}
}
});

return map;
}

// 2. 초기화 및 리스너 통합 실행부
(async () => {
console.log("[CE] 🚀 스크립트 초기화 시작");

async function initKanMap() {
try {
const res = await chrome.storage.local.get(["__ext_master_data", FOLD_STATE_KEY]);
console.log("[CE] 📦 스토리지 키 확인:", Object.keys(res));

if (res.__ext_master_data) {
KAN_MAP = processMasterData(res.__ext_master_data);
STATE.csvLoaded = true;
console.log("[CE] ✅ 매핑 완료 - 데이터 개수:", Object.keys(KAN_MAP).length);
} else {
console.warn("[CE] ⚠️ 스토리지에 데이터가 없습니다. 동기화를 기다립니다.");
}

STATE.isCollapsed = res[FOLD_STATE_KEY] === true;
} catch (e) {
console.error("[CE] 💥 초기화 에러:", e);
} finally {
await reevaluate();
}
}

await initKanMap();

// 스토리지 변경 감지 (통합)
chrome.storage.onChanged.addListener((changes, area) => {
if (area !== "local") return;

if (changes.__ext_master_data) {
console.log("[CE] 🔄 서버 데이터 실시간 업데이트 감지");
KAN_MAP = processMasterData(changes.__ext_master_data.newValue);
reevaluate();
}

if (changes[TOGGLE_KEY] || changes["__ext_last_kan"] || changes[FOLD_STATE_KEY] || changes["__ext_admin_error"]) {
reevaluate();
}
});

setInterval(reevaluate, 1000);
})();

//============================================================
// option.js
// 옵션 + 오토옵션 통합
//============================================================
(function () {

    // ============================================================
    // 블랙리스트 (시트 연동) — storage 키: BlacklistSite
    // ============================================================
    let __blacklist_site = null;
    let __bl_loaded__ = false; // 로드 완료 플래그

    function __ext_loadBlacklistSite(cb) {
        try {
            chrome.storage.local.get(["BlacklistSite"], (res) => {
                __blacklist_site = (res.BlacklistSite || []).map(s => String(s || "").trim());
                __bl_loaded__ = true;
                if (typeof cb === "function") cb();
            });
        } catch {
            __blacklist_site = [];
            __bl_loaded__ = true;
            if (typeof cb === "function") cb();
        }
    }
    // 최초 1회 로드
    __ext_loadBlacklistSite();

    function isBlacklistedUrl(href) {
        try {
            const list = Array.isArray(__blacklist_site) ? __blacklist_site : [];
            return list.some(u => href.startsWith(u));
        } catch { return false; }
    }

    // 블랙리스트 변경 즉시 반영 + 현재 페이지면 즉시 언랩/중단
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "local" || !changes.BlacklistSite) return;

        __blacklist_site = (changes.BlacklistSite.newValue || []).map(s => String(s || "").trim());

        if (isBlacklistedUrl(location.href)) {
            try { unwrapAllHighlights(document); } catch (_) { }
            // 이후 하이라이트 시도들도 자연스럽게 가드에서 중단됨
        }
    });


    if (window.__EXT_OPTION_ACTIVE__) return;
    window.__EXT_OPTION_ACTIVE__ = true;

    // ===== 상수 =====
    const OPTION_KEY = "__ext_competitor_options"; // Admin1에서 추출/저장한 옵션 배열 사용
    const OPTION_KEY_AUTO = "__ext_competitor_options_auto"; // Admin2에서 추출/저장한 옵션 배열 사용
    const PING_KEY = "__ao_refresh";
    const HIGHLIGHT_BG = "transparent";
    const HIGHLIGHT_COLOR = "#ff4000ff";  // 옵션 컬러
    const BANNER_ATTR = "data-overseas-banner";
    const MARK_ATTR = "data-ao"; // ★ option.js 고유 마커
    const ALLOW_CLASS = "__ext-ao-allow";
    const STYLE_ID = "__ext_option_block_css";

    // ──────────────────────────────────────────────────────────────
    // ★ AUTO(Admin2) 기능 ON/OFF 방법 : false로 변경
    const AUTO_ENABLED = true;
    // ──────────────────────────────────────────────────────────────

    const host = location.host;
    const path = location.pathname || "";
    const isAdminHost = () => host === "price.coupang.com";
    const isAdmin1 = isAdminHost() && /^#\/matching\/\d+(\b|[/?#])?/i.test(location.hash || "");
    const isAdmin2 = isAdminHost() && /^#\/itemmapping\//i.test(location.hash || "");

    // ── 유틸 ─────────────────────────────────────────────────────
    const log = (...a) => { try { console.log("[OPTION]", ...a); } catch (_) { } };

    function isVisible(el) {
        if (!el) return false;
        if (el.offsetParent !== null) return true;
        return el.getClientRects && el.getClientRects().length > 0;
    }

    function normalize(s) {
        return String(s || "").replace(/\s+/g, " ").trim();
    }

    // 비교용 정규화: 옵션명 끝 꼬리문구 4종 제거 + 공백 정리
    function normalizeForExactCompare(s) {
        let t = String(s || "").replace(/\s+/g, " ").trim();

        const tailUnit =
            '(?:' +
            '\\s*-\\s*\\d+\\s*개\\s*남음\\s*' +
            '|\\s*\\(\\s*품절\\s*\\)\\s*' +
            '|\\s*\\(\\s*[+\\-]\\s*\\d{1,3}(?:,\\d{3})*(?:\\.\\d+)?\\s*원\\s*\\)\\s*' +
            '|\\s*[+\\-]?\\s*\\d{1,3}(?:,\\d{3})*(?:\\.\\d+)?\\s*(?:원)?\\s*' +
            '|\\s*(?:재고\\s*있음|재고있음|일시\\s*품절|일시품절|품절|구매\\s*가능|구매가능|구매\\s*불가|구매불가)\\s*' +
            '|\\s*[\\|·ㆍ⋅:／/~\\-–—]\\s*' +
            '|\\s*선택\\s*' +
            ')';

        t = t.replace(new RegExp(`(?:${tailUnit})+$`), "");
        return t.replace(/\s+/g, " ").trim();
    }

    // 전체 일치만 허용하는 유연 패턴
    function buildOptionsRegex(options) {
        const sorted = [...options].filter(Boolean).sort((a, b) => b.length - a.length);
        const toFlexiblePattern = (s) => {
            let esc = String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
            esc = esc.replace(/ +/g, "[\\s\\u00A0\\u1680\\u2000-\\u200B\\u202F\\u205F\\u3000]+");
            esc = esc.replace(/\\-/g, "[-\\u2212\\u2010-\\u2015]");
            return esc;
        };
        const escaped = sorted.map(toFlexiblePattern);
        if (!escaped.length) {
            const source = "(?!)";
            return { sorted, regex: /(?!)/g, source };
        }
        const leftBoundary = `(^\\s*)`;
        const body = `(${escaped.join("|")})`;

        // 꼬리 유닛: 여러 번 반복 허용
        const tailUnit =
            '(?:' +
            '\\s*-\\s*\\d+\\s*개\\s*남음\\s*' +
            '|\\s*\\(\\s*품절\\s*\\)\\s*' +
            '|\\s*\\(\\s*[+\\-]\\s*\\d{1,3}(?:,\\d{3})*(?:\\.\\d+)?\\s*원\\s*\\)\\s*' +
            '|\\s*[+\\-]?\\s*\\d{1,3}(?:,\\d{3})*(?:\\.\\d+)?\\s*(?:원)?\\s*' +
            '|\\s*(?:재고\\s*있음|재고있음|일시\\s*품절|일시품절|품절|구매\\s*가능|구매가능|구매\\s*불가|구매불가)\\s*' +
            '|\\s*[\\|·ㆍ⋅:／/~\\-–—]\\s*' +
            '|\\s*선택\\s*' +
            ')';

        const tail = `((?:${tailUnit})*)`;

        const rightBoundary = `\\s*$`;
        const source = `${leftBoundary}${body}${tail}${rightBoundary}`;
        const re = new RegExp(source, "g");
        return { sorted, regex: re, source };
    }

    function escHtml(s) {
        return String(s || "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");
    }

    function traverseRootWithShadow(root, each) {
        if (!root) return;
        each(root);
        if (root.querySelectorAll) {
            const all = root.querySelectorAll("*");
            all.forEach(el => {
                if (el.shadowRoot) {
                    each(el.shadowRoot);
                    traverseRootWithShadow(el.shadowRoot, each);
                }
            });
        }
    }

    function unwrapNode(node) {
        const p = node && node.parentNode;
        if (!p) return;
        const frag = document.createDocumentFragment();
        while (node.firstChild) frag.appendChild(node.firstChild);
        p.replaceChild(frag, node);
    }

    function clearAoMark(el) {
        if (!el) return;
        el.style.backgroundColor = "";
        el.style.color = "";
        el.style.fontWeight = "";
        el.style.outline = "";
        if (el.hasAttribute(MARK_ATTR)) el.removeAttribute(MARK_ATTR);
    }

    function unwrapAllHighlights(root = document) {
        let dirty = true;
        while (dirty) {
            dirty = false;
            traverseRootWithShadow(root, (r) => {
                if (!r.querySelectorAll) return;
                const nodes = r.querySelectorAll(`[${MARK_ATTR}]`);
                if (nodes.length) {
                    nodes.forEach(n => {
                        if (n.tagName === "SPAN") { unwrapNode(n); }
                        else { clearAoMark(n); }
                    });
                    dirty = true;
                }
            });
        }
    }

    // 옵션 본문만 감싸는 유틸: 컨테이너 매칭(속성 일치) 시 tail 건드리지 않음
    function wrapOptionBodyText(el, sortedOptions) {
        if (!el || !Array.isArray(sortedOptions) || sortedOptions.length === 0) return;

        // ★ model span이 있는 컨테이너는 Range 조작 금지 → 텍스트 소실 방지
        if (el.querySelector && el.querySelector('.__ext-model-mark, .__ext-model-mark-mismatch')) return;

        // --- 컨테이너 내 텍스트 평탄화 + 위치 맵 (이미 감싼/배너/스크립트/스타일 제외)
        function __flatTextMap(root) {
            const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
                acceptNode(node) {
                    const p = node.parentElement;
                    if (!p) return NodeFilter.FILTER_REJECT;
                    if (p.closest && p.closest(`[${BANNER_ATTR}="1"]`)) return NodeFilter.FILTER_REJECT;
                    // 이미 감싼(data-ao) 곳은 다시 감싸지 않음
                    if (p.closest && p.closest(`[${MARK_ATTR}="1"]`)) return NodeFilter.FILTER_REJECT;
                    if (!node.nodeValue) return NodeFilter.FILTER_REJECT;
                    const tag = p.tagName;
                    if (tag === "SCRIPT" || tag === "STYLE") return NodeFilter.FILTER_REJECT;
                    // ★ model-name span(__ext-model-mark) 안의 텍스트도 순회 허용
                    // (model span이 텍스트를 감싸도 옵션 본문 감싸기가 정상 동작해야 함)
                    return NodeFilter.FILTER_ACCEPT;
                }
            });
            const map = [];
            let text = "", pos = 0, n;
            while ((n = walker.nextNode())) {
                const v = n.nodeValue || "";
                if (!v) continue;
                map.push({ node: n, start: pos, end: pos + v.length });
                text += v;
                pos += v.length;
            }
            return { text, map };
        }

        // --- 옵션 '본문'만 잡는 정규식(ANYWHERE, GLOBAL, CASE-INSENSITIVE)
        function __buildBodyRegexFromOptions(options) {
            const toFlexiblePattern = (s) => {
                let esc = String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
                esc = esc.replace(/ +/g, "[\\s\\u00A0\\u1680\\u2000-\\u200B\\u202F\\u205F\\u3000]+");
                esc = esc.replace(/\\-/g, "[-\\u2212\\u2010-\\u2015]");
                return esc;
            };
            const escaped = options
                .filter(Boolean)
                .sort((a, b) => b.length - a.length)
                .map(toFlexiblePattern);
            if (!escaped.length) return null;
            // 앵커 없음, 글로벌 + 대소문자 무시 — 본문이 텍스트 어디에 있어도 잡힘
            return new RegExp(`(${escaped.join("|")})`, "gi");
        }

        // --- 평탄화
        const { text, map } = __flatTextMap(el);
        const bodyRe = __buildBodyRegexFromOptions(sortedOptions);
        if (!bodyRe || !text) return;

        // --- 모든 매칭 수집
        const matches = [];
        let m;
        while ((m = bodyRe.exec(text)) !== null) {
            matches.push({ start: m.index, end: m.index + m[0].length });
        }
        if (!matches.length) return;

        // --- 평탄화 오프셋 → Range
        function __locate(map, idx, isEnd = false) {
            for (const seg of map) {
                const inSeg = isEnd ? (idx > seg.start && idx <= seg.end) : (idx >= seg.start && idx < seg.end);
                if (inSeg) return { node: seg.node, offset: idx - seg.start };
                if (!isEnd && idx === seg.end) return { node: seg.node, offset: seg.node.nodeValue.length };
            }
            return null;
        }

        // --- 뒤에서 앞으로 감싸기 (앞에서부터 감싸면 오프셋이 밀려 뒤 매칭이 틀어짐)
        for (let i = matches.length - 1; i >= 0; i--) {
            const { start, end } = matches[i];

            const s = __locate(map, start, false);
            const e = __locate(map, end, true);
            if (!s || !e) continue;

            const r = document.createRange();
            r.setStart(s.node, s.offset);
            r.setEnd(e.node, e.offset);

            const wrapper = document.createElement("span");
            wrapper.setAttribute(MARK_ATTR, "1");
            wrapper.style.backgroundColor = "transparent";

            try { r.surroundContents(wrapper); }
            catch (_) {
                const frag = r.extractContents();
                wrapper.appendChild(frag);
                r.insertNode(wrapper);
            }

            /* [ADD] 래핑 결과, 내부 첫 엘리먼트가 <strong>/<b>라면 그 요소에도 마크를 함께 부여 */
            const firstEl = wrapper.firstElementChild;
            if (firstEl && (firstEl.tagName === 'STRONG' || firstEl.tagName === 'B')) {
                firstEl.setAttribute(MARK_ATTR, "1");
            }
        }
    }

    // ── 깜빡임 방지 CSS ──────────────────────────────────────────
    function isScopedHost() {
        if (host === "brand.naver.com") return true;
        if (host === "smartstore.naver.com") return true;
        if (/\.?11st\.co\.kr$/i.test(host) && path.startsWith("/products/")) return true;
        if (/\.?gmarket\.co\.kr$/i.test(host) && path.toLowerCase().startsWith("/item")) return true;
        if (/^itempage\d*\.auction\.co\.kr$/i.test(host)) return true;
        const isOhouse = /(?:^|\.)ohou\.se$/i.test(host) && (/^\/goods\//.test(path) || /^\/store\/goods\//.test(path));
        if (isOhouse) return true;
        if (/(?:^|\.)musinsa\.com$/i.test(host) && (
            /^\/products\//.test(path) || /^\/app\/goods\//.test(path) || /^\/goods\//.test(path)
        )) return true;

        // CJ 전용 마크업 감지 시 스코프 활성화
        try {
            if (document.querySelector('div.option_list_wrap ul.option_list[role="listbox"]')) return true;
        } catch (_) { }

        return false;
    }

    function injectBlockCSS() {
        if (document.getElementById(STYLE_ID)) return;
        let css = "";
        if (isAdminHost()) {
            css += `
html [${MARK_ATTR}]{
background-color: transparent !important;
color: inherit !important;
font-weight: inherit !important;
}
`;
        } else if (isScopedHost()) {
            css += `
html [${MARK_ATTR}]{
background-color: transparent !important;
color: inherit !important;
font-weight: inherit !important;
}
.${ALLOW_CLASS} [${MARK_ATTR}]{
background-color: ${HIGHLIGHT_BG} !important;
color: ${HIGHLIGHT_COLOR} !important;
font-weight: 900 !important;
}
`;
        }
        if (css.trim()) {
            const style = document.createElement("style");
            style.id = STYLE_ID;
            style.type = "text/css";
            style.textContent = css;
            (document.head || document.documentElement).appendChild(style);
        }
    }

    injectBlockCSS();

    // ── Admin1: 옵션 추출만, 컬러링 금지 ────────────────────────
    if (isAdmin1) {
        log("Admin1 detected → 옵션 추출/저장");

        function getSingleVisibleRow() {
            const mappingsPaneActive = document.querySelector('.ant-tabs-tabpane-active[id$="-panel-mappings"]');
            const mappingsPaneById = document.querySelector('[id$="-panel-mappings"]');
            const activeBtn = document.querySelector('.ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn');
            const activePaneByActiveBtn = (activeBtn && document.getElementById(activeBtn.getAttribute('aria-controls'))) || null;
            const pane = mappingsPaneActive || mappingsPaneById || activePaneByActiveBtn
                || document.querySelector('.ant-tabs-content-holder .ant-tabs-tabpane-active');

            if (pane) {
                const virtualHolder = pane.querySelector(".ant-table-tbody-virtual-holder-inner");
                if (virtualHolder && isVisible(virtualHolder)) {
                    const vRows = Array.from(virtualHolder.querySelectorAll(".ant-table-row[data-row-key]"))
                        .filter(r => isVisible(r) && (r.textContent || "").trim() !== "");
                    if (vRows.length === 1) return vRows[0];
                }
                const table = pane.querySelector(".ant-table-body table");
                if (table && isVisible(table)) {
                    const rows = Array.from(table.querySelectorAll("tbody tr"))
                        .filter(tr => isVisible(tr) && tr.querySelector("td") && tr.textContent.trim() !== "");
                    if (rows.length === 1) return rows[0];
                }
            }
            return null;
        }

        function findItemNameElFromRow(rowEl) {
            if (!rowEl) return null;
            let el = rowEl.querySelector(".ManualMappingListContainer__itemName___27daQ");
            if (el) return el;
            el = rowEl.querySelector('#itemName, [id="itemName"]');
            if (el) return el;
            const candidates = Array.from(rowEl.querySelectorAll(".ant-table-cell, td, div"));
            for (const c of candidates) {
                const t = (c.textContent || "").trim();
                if (t && t.length >= 2 && !c.querySelector("input,button,select,textarea")) return c;
            }
            return null;
        }

        function extractOptions() {
            const rowEl = getSingleVisibleRow();
            if (!rowEl) return [];
            const nameEl = findItemNameElFromRow(rowEl);
            if (!nameEl) return [];
            const text = (nameEl.textContent || "").trim();
            const out = [];

            const delim = '(::|:!:)';
            const re = new RegExp(`${delim}\\s*([\\s\\S]*?)(?=\\s*${delim}|$)`, 'g');

            let m;
            while ((m = re.exec(text)) !== null) {
                const usedDelim = m[1]; // ★ [PATCH-SLASH] 실제 사용된 구분자(:: 또는 :!:) 식별
                const segRaw = String(m[2] || "");
                const segNorm = segRaw.replace(/\s+/g, " ").trim();

                if (!segNorm) continue;

                // ★ [PATCH-SLASH] "오직 '::' 뒤에서만" 슬래시로 추가 분할
                if (usedDelim === '::' && /[\/／]/.test(segNorm)) {
                    if (location.host === 'brand.naver.com') {
                        // 네이버 브랜드 스토어에서만: 원본 + 조각(부분일치 허용 경로도 활성화)
                        out.push(segNorm);
                        segNorm.split(/\s*[\/／]\s*/).forEach(piece => {
                            const p = (piece || "").replace(/\s+/g, " ").trim();
                            if (p) out.push(p);
                        });
                    } else {
                        // 그 외 사이트: 슬래시 분해 금지 → 원본만 저장 (부분일치 자연 비활성화)
                        out.push(segNorm);
                    }
                } else {
                    out.push(segNorm);
                }
            }
            return Array.from(new Set(out)).filter(Boolean).sort((a, b) => b.length - a.length);
        }

        function saveOptions() {
            const options = extractOptions();
            try { chrome.storage.local.set({ [OPTION_KEY]: options }); } catch (_) { }
            log("(Admin1) 저장 옵션:", options);
        }

        saveOptions();
        let raf = null;
        const mo = new MutationObserver(() => {
            if (raf) cancelAnimationFrame(raf);
            raf = requestAnimationFrame(saveOptions);
        });
        mo.observe(document.body, { childList: true, subtree: true, characterData: true });

        function cleanOnUnload() {
            try { chrome.storage.local.set({ [OPTION_KEY]: [] }); } catch (_) { }
        }
        window.addEventListener("beforeunload", cleanOnUnload);
        window.addEventListener("pagehide", cleanOnUnload);

        unwrapAllHighlights(document);
        return; // Admin1은 컬러링 금지
    }

    // ── Admin2: 옵션 추출만, 컬러링 금지 ────────────────────────
    if (AUTO_ENABLED && isAdmin2) {
        log("Admin2 detected → 옵션 추출/저장(auto)");

        function extractOptions() {
            const td = document.querySelector("td[data-elm-id='AutoMapping__Competitor-itemName']");
            if (!td) return [];
            const text = (td.innerText || td.textContent || "").trim();
            const out = [];

            const delim = '(::|:!:)';
            const re = new RegExp(`${delim}\\s*([\\s\\S]*?)(?=\\s*${delim}|$)`, 'g');

            let m;
            while ((m = re.exec(text)) !== null) {
                const usedDelim = m[1];
                const segRaw = String(m[2] || "");
                const segNorm = segRaw.replace(/\s+/g, " ").trim();

                if (!segNorm) continue;

                if (usedDelim === '::' && /[\/／]/.test(segNorm)) {
                    if (location.host === 'brand.naver.com') {
                        // 네이버 브랜드 스토어에서만: 원본 + 조각 저장
                        out.push(segNorm);
                        segNorm.split(/\s*[\/／]\s*/).forEach(piece => {
                            const p = (piece || "").replace(/\s+/g, " ").trim();
                            if (p) out.push(p);
                        });
                    } else {
                        // 그 외 사이트: 원본만 저장(분해 금지)
                        out.push(segNorm);
                    }
                } else {
                    out.push(segNorm);
                }
            }
            return Array.from(new Set(out)).filter(Boolean).sort((a, b) => b.length - a.length);
        }

        function saveOptions() {
            const options = extractOptions();
            try { chrome.storage.local.set({ [OPTION_KEY_AUTO]: options }); } catch (_) { }
            log("(Admin2) 저장 옵션:", options);
        }

        saveOptions();
        let raf = null;
        const mo = new MutationObserver(() => {
            if (raf) cancelAnimationFrame(raf);
            raf = requestAnimationFrame(saveOptions);
        });
        mo.observe(document.body, { childList: true, subtree: true, characterData: true });

        function cleanOnUnload() {
            try { chrome.storage.local.set({ [OPTION_KEY_AUTO]: [] }); } catch (_) { }
        }
        window.addEventListener("beforeunload", cleanOnUnload);
        window.addEventListener("pagehide", cleanOnUnload);

        unwrapAllHighlights(document);
        return; // Admin2는 컬러링 금지
    }

    // 어드민 호스트 전체 차단
    if (isAdminHost()) {
        unwrapAllHighlights(document);
        log("Admin host detected → 컬러링 비활성화");
        return;
    }

    // ── 스코프 레지스트리 ─────────────────────────────────────────
    const SITE_SCOPES = {
        entries: [
            //브랜드스토어
            {
                id: "naver_brandstore_option_dropdown",
                isMatch() { return host === "brand.naver.com"; },
                getAllowedRoots() {
                    const btnSel = [
                        'a[role="button"][aria-haspopup="listbox"][data-shp-area-id="optselect"]',
                        'a[role="button"][aria-haspopup="listbox"][data-shp-contents-type="옵션"]',
                    ].join(", ");
                    const buttons = Array.from(document.querySelectorAll(btnSel)).filter(isVisible);
                    const panels = Array.from(document.querySelectorAll('[role="listbox"]')).filter(isVisible);
                    const allowed = new Set();
                    if (buttons.length && panels.length) {
                        const MAX_DIST = 600;
                        for (const btn of buttons) {
                            const br = btn.getBoundingClientRect();
                            const bcx = br.left + br.width / 2, bcy = br.top + br.height / 2;
                            let best = null, bestDist = Infinity;
                            for (const p of panels) {
                                if (!p.querySelector('[role="option"]')) continue;
                                const pr = p.getBoundingClientRect();
                                const pcx = pr.left + pr.width / 2, pcy = pr.top + pr.height / 2;
                                const dist = Math.hypot(bcx - pcx, bcy - pcy);
                                if (dist < bestDist) { bestDist = dist; best = p; }
                            }
                            if (best && bestDist <= MAX_DIST) allowed.add(best);
                        }
                    }
                    const brandExtra = [
                        ...document.querySelectorAll("strong.ozMukSs9gm, .UQXwEUpdEN .U9FovFnBmF"),
                        ...document.querySelectorAll(".flicking-viewport[role='radiogroup'], .flicking-viewport[role='radiogroup'] ul.flicking-camera"),
                        ...document.querySelectorAll(".TYJuaB03Ht"),
                        ...document.querySelectorAll('div.W1uViPpPDJ[role="radiogroup"]'),
                        ...document.querySelectorAll('div.XCOrxJzfAt[role="radiogroup"]'),
                        ...document.querySelectorAll('div[role="radiogroup"][data-shp-contents-type="색상"]'),
                        ...document.querySelectorAll('div[role="radiogroup"][data-shp-contents-type="사이즈"]'),
                        ...document.querySelectorAll('div.mEPWmZh5g9'),
                        ...document.querySelectorAll('div.ggfaY5qRku'),
                        ...document.querySelectorAll('div.xfW3DXpUDw'),
                    ].filter(isVisible);
                    brandExtra.forEach(n => allowed.add(n));
                    const roots = Array.from(allowed);
                    roots.forEach(r => r.classList.add(ALLOW_CLASS));
                    return roots;
                },
            },
            //스마트스토어
            {
                id: "naver_smartstore_quantity_dropdown",
                isMatch() { return host === "smartstore.naver.com"; },
                getAllowedRoots() {
                    const btnSel = 'a[role="button"][aria-haspopup="listbox"][data-shp-area-id="optselect"]';
                    const buttons = Array.from(document.querySelectorAll(btnSel)).filter(isVisible);
                    const allowed = new Set();
                    if (buttons.length) {
                        const NEAR_CONTAINER_SEL = ['.KobocOawE2', '.hChTeQ6YMe', '.DcIEfnCExV'].join(', ');
                        for (const btn of buttons) {
                            const container = btn.closest(NEAR_CONTAINER_SEL) || btn.parentElement;
                            if (container) {
                                const listboxes = Array.from(container.querySelectorAll('ul[role="listbox"], [role="listbox"]')).filter(isVisible);
                                for (const lb of listboxes) allowed.add(lb);
                            }
                        }
                        if (allowed.size === 0) {
                            const panels = Array.from(document.querySelectorAll('ul[role="listbox"], [role="listbox"]')).filter(isVisible);
                            const MAX_DIST = 800;
                            for (const btn of buttons) {
                                const br = btn.getBoundingClientRect();
                                const bcx = br.left + br.width / 2, bcy = br.top + br.height / 2;
                                let best = null, bestDist = Infinity;
                                for (const p of panels) {
                                    if (!p.querySelector('[role="option"]')) continue;
                                    const pr = p.getBoundingClientRect();
                                    const pcx = pr.left + pr.width / 2, pcy = pr.top + pr.height / 2;
                                    const dist = Math.hypot(bcx - pcx, bcy - pcy);
                                    if (dist < bestDist) { bestDist = dist; best = p; }
                                }
                                if (best && bestDist <= MAX_DIST) allowed.add(best);
                            }
                        }
                    }
                    const smartRadio = [
                        ...document.querySelectorAll("div.XCOrxJzfAt[role='radiogroup']"),
                        ...document.querySelectorAll(".XCOrxJzfAt .wdKPuojthN"),
                    ].filter(isVisible);
                    smartRadio.forEach(n => allowed.add(n));
                    const smartImageRadio = [
                        ...document.querySelectorAll("div.WrWW4M9Uiw[role='radiogroup']"),
                        ...document.querySelectorAll(".WrWW4M9Uiw .NoyQpm_sXz"),
                    ].filter(isVisible);
                    smartImageRadio.forEach(n => allowed.add(n));
                    (function addNaverFarmstoreColorTitle() {
                        const titles = Array.from(document.querySelectorAll('div.xfW3DXpUDw > strong.C7JiRBcY_D')).filter(isVisible);
                        titles.forEach(t => allowed.add(t));
                    })();
                    const roots = Array.from(allowed);
                    roots.forEach(r => r.classList.add(ALLOW_CLASS));
                    return roots;
                },
            },
            // 11번가
            {
                id: "elevenst_products_dropdown",
                isMatch() { return /\.?11st\.co\.kr$/i.test(host) && path.startsWith("/products/"); },
                getAllowedRoots() {
                    const roots = [
                        ...Array.from(document.querySelectorAll(".l_product_buy_list .accordion_body.dropdown_list")),
                        ...Array.from(document.querySelectorAll(".l_product_buy_list ul.option_item_list")),
                        ...Array.from(document.querySelectorAll(".l_product_buy_list ul.b_product_buy_option")),
                    ].filter(isVisible);
                    roots.forEach(r => r.classList.add(ALLOW_CLASS));
                    return roots;
                },
            },
            // Gmarket
            {
                id: "gmarket_item_dropdown",
                isMatch() { return /\.?gmarket\.co\.kr$/i.test(host) && path.toLowerCase().startsWith("/item"); },
                getAllowedRoots() {
                    const BTN_SEL = [
                        'button.select-item_option.uxeselect_btn',
                        'button.uxeselect_btn.select-item_option',
                        'button.uxeselect_btn',
                        'button.select-item_option'
                    ].join(", ");
                    const buttons = Array.from(document.querySelectorAll(BTN_SEL)).filter(isVisible);
                    if (!buttons.length) return [];
                    const allowed = new Set();
                    const PANEL_SEL_STRICT = [
                        '[role="listbox"].select-item_list', 'ul.select-item_list[role="listbox"]',
                        '.uxeselect_layer', '.select-item_layer', '.option_list', '.option_select_list', '.select-list'
                    ].join(', ');
                    const NEAR_CONTAINER_SEL = [
                        '.uxeselect', '.select-item', '.option_box', '.option_select',
                        '.vip_prd_option', '.layer_wrap', '.list_select'
                    ].join(', ');
                    const hasOptionsStrict = (el) => !!el.querySelector('[role="option"], li.option_item, li .option_item, a[role="option"], button[role="option"]');
                    for (const btn of buttons) {
                        const sib = btn.nextElementSibling;
                        if (sib && isVisible(sib) && sib.matches(PANEL_SEL_STRICT) && hasOptionsStrict(sib)) { allowed.add(sib); continue; }
                        const container = btn.closest(NEAR_CONTAINER_SEL) || btn.parentElement;
                        if (container) {
                            const localPanels = Array.from(container.querySelectorAll(PANEL_SEL_STRICT)).filter(el => isVisible(el) && hasOptionsStrict(el));
                            for (const p of localPanels) allowed.add(p);
                            if (!localPanels.length) {
                                const relaxed = Array.from(container.querySelectorAll('ul, ol')).filter(el => isVisible(el) && el.querySelector('li'));
                                for (const p of relaxed) allowed.add(p);
                            }
                        }
                    }
                    if (allowed.size === 0) {
                        const allStrictPanels = Array.from(document.querySelectorAll(PANEL_SEL_STRICT)).filter(el => isVisible(el) && hasOptionsStrict(el));
                        const MAX_DIST = 1000;
                        for (const btn of buttons) {
                            const br = btn.getBoundingClientRect();
                            const bcx = br.left + br.width / 2, bcy = br.top + br.height / 2;
                            let best = null, bestDist = Infinity;
                            for (const p of allStrictPanels) {
                                const pr = p.getBoundingClientRect();
                                const pcx = pr.left + pr.width / 2, pcy = pr.top + pr.height / 2;
                                const dist = Math.hypot(bcx - pcx, bcy - pcy);
                                if (dist < bestDist) { bestDist = dist; best = p; }
                            }
                            if (best && bestDist <= MAX_DIST) allowed.add(best);
                        }
                    }
                    const roots = Array.from(allowed);
                    roots.forEach(r => r.classList.add(ALLOW_CLASS));
                    return roots;
                },
            },
            // Auction
            {
                id: "auction_item_dropdown",
                isMatch() { return /^itempage\d*\.auction\.co\.kr$/i.test(host); },
                getAllowedRoots() {
                    const BTN_SEL = [
                        'button.select-item_option.uxeselect_btn',
                        'button.uxeselect_btn.select-item_option',
                        'button.uxeselect_btn',
                        'button.select-item_option'
                    ].join(", ");
                    const buttons = Array.from(document.querySelectorAll(BTN_SEL)).filter(isVisible);
                    if (!buttons.length) return [];
                    const allowed = new Set();
                    const PANEL_SEL_STRICT = [
                        '[role="listbox"].select-item_list', 'ul.select-item_list[role="listbox"]',
                        '.uxeselect_layer', '.select-item_layer', '.option_list', '.option_select_list', '.select-list'
                    ].join(', ');
                    const NEAR_CONTAINER_SEL = [
                        '.uxeselect', '.select-item', '.option_box', '.option_select',
                        '.vip_prd_option', '.layer_wrap', '.list_select', '.section_opt', '.box_opt', '.area_select'
                    ].join(', ');
                    const hasOptionsStrict = (el) => !!el.querySelector('[role="option"], li.option_item, li .option_item, a[role="option"], button[role="option"]');
                    for (const btn of buttons) {
                        const sib = btn.nextElementSibling;
                        if (sib && isVisible(sib) && sib.matches(PANEL_SEL_STRICT) && hasOptionsStrict(sib)) { allowed.add(sib); continue; }
                        const container = btn.closest(NEAR_CONTAINER_SEL) || btn.parentElement;
                        if (container) {
                            const localPanels = Array.from(container.querySelectorAll(PANEL_SEL_STRICT)).filter(el => isVisible(el) && hasOptionsStrict(el));
                            for (const p of localPanels) allowed.add(p);
                            if (!localPanels.length) {
                                const relaxed = Array.from(container.querySelectorAll('ul, ol')).filter(el => isVisible(el) && el.querySelector('li'));
                                for (const p of relaxed) allowed.add(p);
                            }
                        }
                    }
                    const addNodes = (selectors, { allowHidden = false } = {}) => {
                        for (const sel of selectors) {
                            Array.from(document.querySelectorAll(sel)).forEach(n => {
                                if (allowHidden || isVisible(n)) allowed.add(n);
                            });
                        }
                    };
                    addNodes(['ul.type_thumbnail.item_block_lst', 'ul.type_thumbnail.item_block_lst[id^="ucItemOrderInfo_ucOptionTemplate_"]']);
                    addNodes(['div.optiontype.type_block', 'div.item_block']);
                    addNodes(['ul.type_thumbnail.item_block_lst li > a']);
                    addNodes(['div.infobox.block_info'], { allowHidden: true });
                    const roots = Array.from(allowed);
                    roots.forEach(r => r.classList.add(ALLOW_CLASS));
                    return roots;
                },
            },
            // 오늘의집(ohou.se)
            {
                id: "ohouse_store_goods_scopes",
                isMatch() { return /(?:^|\.)ohou\.se$/i.test(host) && (/^\/goods\//.test(path) || /^\/store\/goods\//.test(path)); },
                getAllowedRoots() {
                    const allowed = new Set([
                        ...document.querySelectorAll('ul[data-testid="selected-option-list"]'),
                        ...document.querySelectorAll(
                            'select[data-testid="first-depth-select"], ' +
                            'select[data-testid="second-depth-select"], ' +
                            'select[data-testid="additional-select"]'
                        ),
                        ...document.querySelectorAll('#buy, [data-testid*="option"], [class*="Option"], [class*="option"]')
                    ].filter(isVisible));
                    const roots = Array.from(allowed);
                    roots.forEach(r => r.classList.add(ALLOW_CLASS));
                    return roots;
                },
            },
            // 무신사
            {
                id: "musinsa_product_option_dropdown",
                isMatch() {
                    return /(?:^|\.)musinsa\.com$/i.test(host) && (
                        /^\/products\//.test(path) || /^\/app\/goods\//.test(path) || /^\/goods\//.test(path)
                    );
                },
                getAllowedRoots() {
                    const nodes = [
                        ...document.querySelectorAll('[class^="OptionDropdown__Wrapper-sc-"]'),
                        ...document.querySelectorAll('.static-dropdown-menu[data-mds="StaticDropdownMenu"]'),
                        ...document.querySelectorAll('[data-mds="StaticDropdownMenuContent"]'),
                        ...document.querySelectorAll('[data-mds="StaticDropdownMenuItem"]'),
                        ...document.querySelectorAll('[data-mds="DropdownTriggerBox"]'),
                        ...document.querySelectorAll('[data-mds="DropdownTriggerInput"]'),
                    ].filter(isVisible);
                    const allowed = new Set(nodes);
                    const roots = Array.from(allowed);
                    roots.forEach(r => r.classList.add(ALLOW_CLASS));
                    return roots;
                },
            },
            // CJ
            {
                id: "cj_option_list_wrap",
                isMatch() {
                    try {
                        return !!document.querySelector('div.option_list_wrap ul.option_list[role="listbox"]');
                    } catch (_) { return false; }
                },
                getAllowedRoots() {
                    const allowed = new Set();
                    const wraps = Array.from(document.querySelectorAll('div.option_list_wrap')).filter(isVisible);
                    wraps.forEach(w => {
                        allowed.add(w);
                        const list = w.querySelector('ul.option_list[role="listbox"]');
                        if (list && isVisible(list)) allowed.add(list);
                        w.querySelectorAll('li, a[role="option"], p.option_item').forEach(n => {
                            if (isVisible(n)) allowed.add(n);
                        });
                    });
                    const roots = Array.from(allowed);
                    roots.forEach(r => r.classList.add(ALLOW_CLASS));
                    return roots;
                },
            },

            //컬리
            {
                id: "kurly_option_dropdown",
                isMatch() {
                    try {
                        return !!document.querySelector('.css-metm2b.ewfoon50');
                    } catch (_) { return false; }
                },
                getAllowedRoots() {
                    const allowed = new Set();

                    // 실제 옵션 텍스트 span만 선택
                    const spans = document.querySelectorAll('.css-metm2b.ewfoon50');

                    spans.forEach(sp => {
                        if (isVisible(sp)) allowed.add(sp);
                    });

                    const roots = Array.from(allowed);
                    roots.forEach(r => r.classList.add(ALLOW_CLASS));
                    return roots;
                },
            },

            // GS SHOP
            {
                id: "gsshop_option_area",
                isMatch() {
                    const host = location.host;
                    const path = location.pathname || "";
                    if (/(?:^|\.)gsshop\.com$/i.test(host)) return true;
                    try {
                        // AO(=data-ao) 마크된 본문이 보이면 스코프 활성화
                        return !!document.querySelector('span[data-ao="1"]');
                    } catch (_) { return false; }
                },
                getAllowedRoots() {
                    const allowed = new Set();

                    // 1) 옵션 본문 스팬(data-ao="1") 자체를 허용 루트로
                    Array.from(document.querySelectorAll('span[data-ao="1"]')).forEach(sp => {
                        if (isVisible(sp)) allowed.add(sp);
                        // 2) 주변 컨테이너도 함께 허용
                        const box = sp.closest(
                            [
                                '[role="listbox"]',
                                'ul', 'ol', 'li',
                                'a[role="option"]', 'button[role="option"]',
                                'div', 'section'
                            ].join(', ')
                        );
                        if (box && isVisible(box)) allowed.add(box);
                    });

                    // 3) 전통적인 옵션 블록 후보도 함께 추가
                    const candidates = [
                        '[role="listbox"]',
                        'ul.option_list', 'ul.select-list', 'ul[data-testid*="option"]',
                        'div.option', 'div.options', 'div.option_list_wrap'
                    ];
                    candidates.forEach(sel => {
                        document.querySelectorAll(sel).forEach(n => {
                            if (isVisible(n)) allowed.add(n);
                        });
                    });

                    const roots = Array.from(allowed);
                    roots.forEach(r => r.classList.add(ALLOW_CLASS));
                    return roots;
                },
            },
        ],
        getActiveAllowedRoots() {
            const out = []; const seen = new Set();
            for (const entry of this.entries) {
                try {
                    if (!entry || typeof entry.isMatch !== "function" || typeof entry.getAllowedRoots !== "function") continue;
                    if (!entry.isMatch()) continue;
                    const arr = entry.getAllowedRoots() || [];
                    for (const r of arr) {
                        if (!r || r.nodeType !== 1) continue;
                        if (!seen.has(r)) { seen.add(r); out.push(r); }
                    }
                } catch (_) { }
            }
            return out;
        },

    };

    // ── 컬러링 공통 함수: 옵션명에 해당하는 요소에 스타일 강제 적용 ──
    // 모델명 스팬(__ext-model-mark)이 텍스트를 쪼개더라도 data-optionvalue1 속성으로 직접 비교하여 해결
    function applyOptionColorToEl(el, MARK_ATTR_NAME, sortedOptions) {
        // 컨테이너에는 data-ao 부여 금지, 색도 금지 (CSS가 컨테이너까지 물들임)
        // 색은 오직 <span data-ao="1"> 에만 적용
        const markSel = `[${MARK_ATTR_NAME}="1"]`;
        const targets = el.matches(markSel) ? [el] : Array.from(el.querySelectorAll(markSel));

        if (targets.length) {
            targets.forEach(node => {
                node.style.setProperty("background-color", "transparent", "important");
                node.style.setProperty("color", HIGHLIGHT_COLOR, "important");
                node.style.setProperty("-webkit-text-fill-color", HIGHLIGHT_COLOR, "important");
                node.style.setProperty("font-weight", "900", "important");
                node.style.setProperty("font-size", "16px", "important");
                node.style.setProperty("opacity", "1", "important");
                node.style.setProperty("filter", "none", "important");
                node.style.setProperty("mix-blend-mode", "normal", "important");

                /* [ADD] 내부 <strong>/<b>에도 동일 스타일을 인라인 !important로 강제 */
                const strongs = node.querySelectorAll("strong, b");
                strongs.forEach(st => {
                    st.style.setProperty("color", HIGHLIGHT_COLOR, "important");
                    st.style.setProperty("-webkit-text-fill-color", HIGHLIGHT_COLOR, "important");
                    st.style.setProperty("font-weight", "900", "important");
                    st.style.setProperty("font-size", "16px", "important");
                    // 필요시 줄간격까지 통일
                    st.style.setProperty("line-height", "1.2", "important");
                });
            });
        } else {

            // 원시 컨트롤만 컨테이너 직접 칠함
            if (el.tagName === "OPTION" || el.getAttribute("role") === "radio") {
                el.style.setProperty("background-color", "transparent", "important");
                el.style.setProperty("color", HIGHLIGHT_COLOR, "important");
                el.style.setProperty("-webkit-text-fill-color", HIGHLIGHT_COLOR, "important");
                el.style.setProperty("font-weight", "900", "important"); // 이미 최대 굵기
                el.style.setProperty("font-size", "16px", "important"); // 글씨 크기

            }
        }

        // 레이스 방지: 옵션 본문 스팬만 재강제
        const forceColor = () => {
            if (!el.isConnected) return;
            const again = el.matches(markSel) ? [el] : Array.from(el.querySelectorAll(markSel));
            again.forEach(node => {
                node.style.setProperty("background-color", "transparent", "important");
                node.style.setProperty("color", HIGHLIGHT_COLOR, "important");
                node.style.setProperty("-webkit-text-fill-color", HIGHLIGHT_COLOR, "important");
                node.style.setProperty("font-weight", "900", "important");
                node.style.setProperty("font-size", "16px", "important"); // 글씨 크기
            });
        };
        requestAnimationFrame(forceColor);
        setTimeout(forceColor, 0);
        setTimeout(forceColor, 80);
        setTimeout(forceColor, 200);
    }

    // ── 컬러링 함수들 ─────────────────────────────────────────────
    function highlightTextNodesInRoot(root, optionsReLike) {
        if (!root) return;
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
            acceptNode(node) {
                const p = node.parentElement;
                if (!node.nodeValue || !p) return NodeFilter.FILTER_REJECT;
                if (p.closest && p.closest(`[${BANNER_ATTR}="1"]`)) return NodeFilter.FILTER_REJECT;
                if (p.closest && p.closest(`[${MARK_ATTR}="1"]`)) return NodeFilter.FILTER_REJECT;
                // ★ model-name.js가 감싼 span 안에 있는 텍스트 노드도 옵션 컬러링 대상으로 허용
                // (model span 안의 텍스트가 옵션과 일치하면 컬러링해야 하므로 REJECT 하지 않음)
                const tag = p.tagName;
                if (tag === "OPTION" || tag === "SCRIPT" || tag === "STYLE") return NodeFilter.FILTER_REJECT;
                const testRe = new RegExp(optionsReLike.source, "g");
                return testRe.test(node.nodeValue) ? NodeFilter.FILTER_ACCEPT :
                    NodeFilter.FILTER_REJECT;
            }
        });
        const nodes = [];
        while (walker.nextNode()) nodes.push(walker.currentNode);
        for (const textNode of nodes) {
            const pEl = textNode.parentElement;
            if (!pEl) continue;

            // 컨테이너 라벨 취득(속성 우선) → 정확 일치일 때만 치환 허용
            const container = pEl.closest('[data-optionvalue1], [data-optionnm], [data-dtloptnm], [aria-label], a[role="option"], button[role="option"], li, option') || pEl;

            let containerLabel =
                (container.getAttribute && (
                    container.getAttribute('data-optionvalue1') ||
                    container.getAttribute('data-optionnm') ||
                    container.getAttribute('data-dtloptnm') || // ★ 11번가
                    container.getAttribute('data-shp-contents-id') || // ★ 스마트스토어 옵션 라벨
                    container.getAttribute('aria-label')
                )) || "";

            if (!containerLabel) {
                const clone = container.cloneNode(true);
                // ★ model-name span은 remove()하지 않고 unwrap(텍스트만 보존)해야
                // "(테팔정품)EY1308KR" 같은 원본 텍스트가 유지됨
                clone.querySelectorAll('.__ext-model-mark, .__ext-model-mark-mismatch').forEach(n => {
                    const txt = document.createTextNode(n.textContent || "");
                    if (n.parentNode) n.parentNode.replaceChild(txt, n);
                });
                clone.querySelectorAll('[data-model], [data-model-mark]').forEach(n => n.remove());
                containerLabel = (clone.textContent || "").replace(/\s+/g, " ").trim();
                containerLabel = containerLabel.replace(/\(\s*\)|\[\s*\]|\{\s*\}/g, " ").replace(/\s+/g, " ").trim();
            }


            const keys = optionsReLike._sortedOptions || [];
            const keysNorm = keys.map(k => normalizeForExactCompare(k));
            const isExactAny = (label) => {
                const norm = normalizeForExactCompare(label || "");
                return keysNorm.some(k => k && norm === k);
            };

            // "본문 포함" 판정: 컨테이너 라벨에서 옵션 본문이 부분 매칭 되면 true
            function hasBodyInside(label) {
                if (!label) return false;
                const normLabel = String(label).replace(/\s+/g, " ").trim();
                // 옵션 본문(유연 패턴)으로 OR 매칭
                const flexible = keys
                    .filter(Boolean)
                    .sort((a, b) => b.length - a.length)
                    .map(s => {
                        let esc = String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
                        esc = esc.replace(/ +/g, "[\\s\\u00A0\\u1680\\u2000-\\u200B\\u202F\\u205F\\u3000]+");
                        esc = esc.replace(/\-/g, "[-\\u2212\\u2010-\\u2015]");
                        return esc;
                    })
                    .join("|");
                if (!flexible) return false;
                const reBodyOnly = new RegExp(`(${flexible})`, "i");
                return reBodyOnly.test(normLabel);
            }

            const exact = isExactAny(containerLabel);
            const bodyIncluded = !exact && hasBodyInside(containerLabel);

            // 정확 일치면 기존 로직(텍스트 노드 치환) 진행
            // 정확 일치 실패지만 본문 포함이면 컨테이너 내 본문만 감싸기 유틸 사용
            if (!exact && !bodyIncluded) {
                const isNaverFarmTitle = container.matches && container.matches('strong.C7JiRBcY_D');
                if (isNaverFarmTitle) {
                    const sortedOptions = (optionsReLike && optionsReLike._sortedOptions) ? optionsReLike._sortedOptions : [];
                    wrapOptionBodyText(container, sortedOptions);
                    continue;
                }
                continue;
            }
            // 본문 포함 케이스면 텍스트 노드 단위(^...$) 치환 대신, 컨테이너 범위에서 본문만 감싸기
            if (!exact && bodyIncluded) {
                // ★ model span이 컨테이너 안에 있으면 오매칭이므로 스킵
                if (container.querySelector && container.querySelector('.__ext-model-mark, .__ext-model-mark-mismatch')) {
                    continue;
                }
                const sortedOptions = (optionsReLike && optionsReLike._sortedOptions) ? optionsReLike._sortedOptions : [];
                wrapOptionBodyText(container, sortedOptions);
                continue;
            }

            // ↓ 기존 "정확 일치" 케이스는 유지(텍스트 노드 전체가 옵션+tail로 구성된 경우)
            // ▼ 인터랙티브 옵션(드롭다운 항목 등)에서는 텍스트 치환 금지 → 컨테이너 Range 래핑만
            const interactive = container.closest && (
                container.closest('a[role="option"], button[role="option"], [role="option"]')
            );
            if (interactive) {
                const sortedOptions = (optionsReLike && optionsReLike._sortedOptions) ? optionsReLike._sortedOptions : [];
                wrapOptionBodyText(interactive, sortedOptions);
                continue; // 텍스트 치환 로직은 스킵(이벤트/구조 보호)
            }

            // ▼ 정적 텍스트에서만 기존 치환 유지
            const original = textNode.nodeValue || "";
            const escaped = escHtml(original);
            const re = new RegExp(optionsReLike.source, "g");
            const highlightedHtml = escaped.replace(
                re,
                (m, g1, g2, g3) =>
                    `${g1 || ""}` +
                    `<span ${MARK_ATTR}="1" style="background-color:transparent !important;` +
                    `color:${HIGHLIGHT_COLOR} !important;` +
                    `-webkit-text-fill-color:${HIGHLIGHT_COLOR} !important;` +
                    `font-weight:900 !important;` +
                    `font-size:16px !important">` +
                    `${escHtml(g2)}` +
                    `</span>` +
                    `<span style="color:inherit !important; -webkit-text-fill-color:inherit !important; font-weight:inherit !important">` +
                    `${g3 || ""}` +
                    `</span>`
            );

            if (highlightedHtml !== escaped) {
                const wrapper = document.createElement("span");
                wrapper.innerHTML = highlightedHtml;
                if (textNode.parentNode) textNode.parentNode.replaceChild(wrapper, textNode);
            }
        }
        // ── 컨테이너(li/a/button) 단위 매칭 ──
        try {
            const keysNorm = optionsReLike._sortedOptions
                ? optionsReLike._sortedOptions.map(k => normalizeForExactCompare(k))
                : [];
            const reFull = new RegExp(optionsReLike.source, "g");
            const candidates = Array.from(root.querySelectorAll('a[role="option"], button[role="option"], li > a, a[href], li'));
            for (const el of candidates) {
                if (!el || !isVisible(el)) continue;
                if (el.getAttribute && el.getAttribute(MARK_ATTR) === "1") continue;

                let matched = false;

                // 1순위: 속성값 비교(11번가/스마트스토어 포함)
                const optVal = el.getAttribute('data-optionvalue1')
                    || el.getAttribute('data-optionnm')
                    || el.getAttribute('data-dtloptnm') // ★ 11번가
                    || el.getAttribute('data-shp-contents-id') // ★ 스마트스토어
                    || el.getAttribute('aria-label')
                    || "";
                if (optVal) {
                    const optValNorm = normalizeForExactCompare(optVal);
                    if (keysNorm.length && keysNorm.some(k => k && optValNorm === k)) {
                        matched = true;
                    }
                }

                // 2순위: 클론에서 모델명 스팬 제거 후 textContent로 비교
                if (!matched) {
                    const clone = el.cloneNode(true);
                    // ★ model-name span unwrap (텍스트 보존) — remove() 하면 원본 텍스트가 날아가서 오매칭 발생
                    clone.querySelectorAll('.__ext-model-mark, .__ext-model-mark-mismatch').forEach(n => {
                        const txt = document.createTextNode(n.textContent || "");
                        if (n.parentNode) n.parentNode.replaceChild(txt, n);
                    });
                    clone.querySelectorAll('[data-model], [data-model-mark]').forEach(n => n.remove());
                    let txt = (clone.textContent || "").replace(/\s+/g, " ").trim();
                    txt = txt.replace(/\(\s*\)|\[\s*\]|\{\s*\}/g, " ").replace(/\s+/g, " ").trim();
                    // ★ 부분일치(reFull) 대신 정확일치만 허용
                    const txtNorm = normalizeForExactCompare(txt);
                    if (txtNorm && keysNorm.some(k => k && txtNorm === k)) matched = true;
                }

                // 3순위: 완똑 — 자식이 모델스팬 하나뿐이고 그 텍스트가 옵션과 정확히 일치
                if (!matched) {
                    const onlyModelSpan =
                        el.children &&
                        el.children.length === 1 &&
                        el.firstElementChild &&
                        el.firstElementChild.classList &&
                        el.firstElementChild.classList.contains("__ext-model-mark");
                    if (onlyModelSpan) {
                        const modelTxt = (el.firstElementChild.textContent || "").replace(/\s+/g, " ").trim();
                        const exactTester = (function makeExactTester(keys) {
                            const keysNorm2 = (keys || []).map(k => normalizeForExactCompare(k));
                            return function matches(label) {
                                const norm = normalizeForExactCompare(label || "");
                                return keysNorm2.some(k => k && norm === k);
                            };
                        })(optionsReLike._sortedOptions || []);
                        if (exactTester(modelTxt)) matched = true;
                    }
                }

                if (matched) {
                    const sortedOptions = (optionsReLike && optionsReLike._sortedOptions) ? optionsReLike._sortedOptions : [];
                    if (!el.querySelector('.__ext-model-mark, .__ext-model-mark-mismatch')) {
                        wrapOptionBodyText(el, sortedOptions);
                    } else {
                        // ★ model span에는 data-ao 붙이지 않음 (분홍 스타일 보존)
                        // model span 바깥의 텍스트노드만 data-ao span으로 감싸기
                        const childNodes = Array.from(el.childNodes);
                        for (const node of childNodes) {
                            if (node.nodeType === Node.TEXT_NODE && node.nodeValue && node.nodeValue.trim()) {
                                const sp = document.createElement("span");
                                sp.setAttribute(MARK_ATTR, "1");
                                sp.textContent = node.nodeValue;
                                node.parentNode.replaceChild(sp, node);
                            }
                        }
                    }
                    applyOptionColorToEl(el, MARK_ATTR, []);
                }

            }
        } catch (_) { }

    }

    function makeExactTester(keys) {
        const keysNorm = keys.map(k => normalizeForExactCompare(k));
        return function matches(label) {
            const norm = normalizeForExactCompare(label || "");
            return keysNorm.some(k => k && norm === k);
        };
    }

    function highlightNativeSelectsInRoot(root, sortedOptions) {
        if (!root.querySelectorAll) return;
        const tester = makeExactTester(sortedOptions);
        root.querySelectorAll("select").forEach(sel => {
            const opts = sel.options || [];
            for (let i = 0; i < opts.length; i++) {
                const opt = opts[i];
                const matched = tester(opt.textContent || "");
                if (matched) {
                    opt.style.backgroundColor = "transparent";
                    opt.style.color = HIGHLIGHT_COLOR;
                    opt.style.fontWeight = "900";
                } else {
                    opt.style.backgroundColor = "";
                    opt.style.color = "";
                    opt.style.fontWeight = "";
                }
            }
        });
    }

    function highlightRadioButtonsByAttributesInRoot(root, sortedOptions) {
        if (!root.querySelectorAll) return;
        const radioGroups = [
            ...root.querySelectorAll("div.XCOrxJzfAt[role='radiogroup']"),
            ...root.querySelectorAll("div.WrWW4M9Uiw[role='radiogroup']"),
        ];
        if (!radioGroups.length) return;
        const keysNorm = sortedOptions.map(k => normalizeForExactCompare(k));
        const isExactAny = (label) => {
            const norm = normalizeForExactCompare(label || "");
            return keysNorm.some(k => k && norm === k);
        };
        radioGroups.forEach(group => {
            const btns = group.querySelectorAll("button[role='radio']");
            btns.forEach(btn => {
                const a = btn.getAttribute("aria-label");
                const d = btn.getAttribute("data-shp-contents-id");
                const img = btn.querySelector("img[alt]");
                const alt = img && img.getAttribute("alt");
                const label = a || d || alt || btn.textContent || "";
                const matched = isExactAny(label);
                if (matched) {
                    btn.style.backgroundColor = "transparent";
                    btn.style.color = HIGHLIGHT_COLOR;
                    btn.style.fontWeight = "900";
                    btn.style.outline = "";
                    btn.setAttribute(MARK_ATTR, "1");
                } else {
                    btn.style.backgroundColor = "";
                    btn.style.color = "";
                    btn.style.fontWeight = "";
                    btn.style.outline = "";
                    if (btn.getAttribute(MARK_ATTR) === "1") btn.removeAttribute(MARK_ATTR);
                }
            });
        });
    }

    // ── 실행 스케줄/메인 ──────────────────────────────────────────
    let scheduled = null;
    let running = false;

    function scheduleHighlight() {
        if (scheduled) return;
        scheduled = requestAnimationFrame(() => {
            scheduled = null;
            if (!__bl_loaded__) {
                // 로드 완료 후 첫 실행만 보장
                const t = setInterval(() => {
                    if (__bl_loaded__) { clearInterval(t); runHighlight(); }
                }, 20);
                return;
            }
            runHighlight();
        });
    }

    function runHighlight() {
        // ⛔ 시트 로드 전에는 아무 것도 하지 않음 (초기부터 완전 차단 보장)
        if (!__bl_loaded__) return;

        // ⛔ 블랙리스트 접두사면 즉시 언랩 후 중단
        if (isBlacklistedUrl(location.href)) { unwrapAllHighlights(document); return; }

        if (running) return;
        running = true;

        // ★ OPTION_KEY(Admin1) + OPTION_KEY_AUTO(Admin2) 둘 다 읽어서 합침
        const keysToRead = AUTO_ENABLED
            ? ["__ext_option_enabled", OPTION_KEY, OPTION_KEY_AUTO]
            : ["__ext_option_enabled", OPTION_KEY];

        chrome.storage.local.get(keysToRead, res => {
            if (res.__ext_option_enabled !== true) {
                unwrapAllHighlights(document);
                running = false;
                return;
            }
            try {
                const list1 = (res && Array.isArray(res[OPTION_KEY])) ? res[OPTION_KEY] : [];
                const list2 = (AUTO_ENABLED && res && Array.isArray(res[OPTION_KEY_AUTO])) ? res[OPTION_KEY_AUTO] : [];
                // 중복 제거 후 합산
                const list = Array.from(new Set([...list1, ...list2]));
                if (!list.length) { unwrapAllHighlights(document); running = false; return; } // ← running = false 누락 패치
                const { sorted: sortedOptions, regex: optionsRe, source } = buildOptionsRegex(list);
                // _sortedOptions를 optionsRe에 부착하여 컨테이너 매칭에서도 사용 가능하게
                optionsRe._sortedOptions = sortedOptions;
                if (isScopedHost()) {
                    const allowedRoots = SITE_SCOPES.getActiveAllowedRoots();
                    if (!allowedRoots || allowedRoots.length === 0) { running = false; return; }
                    for (const root of allowedRoots) {
                        traverseRootWithShadow(root, (r) => {
                            highlightTextNodesInRoot(r, optionsRe);
                            highlightNativeSelectsInRoot(r, sortedOptions);
                            highlightRadioButtonsByAttributesInRoot(r, sortedOptions);
                        });
                    }
                    return;
                }
                traverseRootWithShadow(document, (root) => {
                    highlightTextNodesInRoot(root, optionsRe);
                    highlightNativeSelectsInRoot(root, sortedOptions);
                    highlightRadioButtonsByAttributesInRoot(root, sortedOptions);
                });
            } finally {
                running = false;
            }
        });
    }

    (function boot() {
        if (__bl_loaded__) { if (!isBlacklistedUrl(location.href)) runHighlight(); return; }
        const t = setInterval(() => {
            if (__bl_loaded__) {
                clearInterval(t);
                if (!isBlacklistedUrl(location.href)) runHighlight();
            }
        }, 20);
    })();

    let raf2 = null;
    const mo2 = new MutationObserver((mutations) => {
        const banner = document.querySelector(`[${BANNER_ATTR}="1"]`);
        const bannerOnly = banner && mutations.length > 0 && mutations.every(m => {
            if (m.type !== "childList") return true;
            const allNodes = [...Array.from(m.addedNodes || []), ...Array.from(m.removedNodes || [])].filter(n => n && n.nodeType === 1);
            if (allNodes.length === 0) return true;
            return allNodes.every(n => n === banner || (n.closest && n.closest(`[${BANNER_ATTR}="1"]`)));
        });
        if (bannerOnly) return;
        if (raf2) cancelAnimationFrame(raf2);
        raf2 = requestAnimationFrame(scheduleHighlight);
    });
    if (document.body) {
        mo2.observe(document.body, { childList: true, subtree: true, characterData: host !== "price.coupang.com" });
    } else {
        new MutationObserver((_, obs) => {
            if (document.body) { mo2.observe(document.body, { childList: true, subtree: true, characterData: true }); obs.disconnect(); }
        }).observe(document.documentElement || document, { childList: true, subtree: true });
    }

    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.onChanged) {
        chrome.storage.onChanged.addListener((changes, areaName) => {
            if (areaName !== "local") return;
            if (changes[OPTION_KEY] || (AUTO_ENABLED && changes[OPTION_KEY_AUTO])) {
                const v = (changes[OPTION_KEY] || changes[OPTION_KEY_AUTO]).newValue;
                if (!Array.isArray(v) || v.length === 0) {
                    // 한 쪽 키가 비워졌어도 다른 쪽에 값이 남아있을 수 있으므로 재-하이라이트로 처리
                    scheduleHighlight();
                    return;
                }
                scheduleHighlight();
            }
        });
    }

    chrome.runtime.onMessage.addListener((msg) => {
        if (msg?.action === "option_refresh") scheduleHighlight();
    });

    log("Loaded at", host, path, { scoped: isScopedHost() });
    // ★★★ AO 강제 오버라이드 CSS 추가 ★★★
    (function inject_AO_override_css() {
        if (document.getElementById("__ext_ao_override_css")) return;
        const st = document.createElement("style");
        st.id = "__ext_ao_override_css";
        st.textContent = `
    span[data-ao="1"] {
        color: #ff4000ff !important;
        -webkit-text-fill-color: #ff4000ff !important;
        font-weight: 900 !important;
        font-size: 16px !important;
    }

    /* [ADD] AO 스팬 내부의 모든 자식에게도 동일한 크기/굵기를 강제 */
    span[data-ao="1"] * {
        color: #ff4000ff !important;
        -webkit-text-fill-color: #ff4000ff !important;
        font-weight: 900 !important;
        font-size: 16px !important;
        line-height: 1.2 !important; /* 줄 높이까지 통일(선택) */
    }

    .__ext-model-mark,
    .__ext-model-mark-mismatch {
        font-size: 16px !important;
    }

    a[disabled] span[data-ao="1"],
    a.soldout span[data-ao="1"],
    a[aria-disabled="true"] span[data-ao="1"],
    *[class*="sold"] span[data-ao="1"],
    strong span[data-ao="1"],
    b span[data-ao="1"],
    .text__name span[data-ao="1"],
    .text__ell span[data-ao="1"] {
        color: #ff4000ff !important;
        -webkit-text-fill-color: #ff4000ff !important;
        font-size: 16px !important;
        font-weight: 900 !important;
    }
`;
        document.head.appendChild(st);
    })();

})();
// =============================================================
// etx_banner.js
// =============================================================

(function () {
// 탑 프레임에서만 동작(중복/iframe 주입 방지)
if (window.self !== window.top) return;

// ============================================================
// 0) 설정 (깜빡임 속도/횟수 등)
// ============================================================
const FADE_INTERVAL_MS = 500; // 속도조절 / 숫자가 낮을수록 빠름
const FADE_TOGGLES = 10; // 10 토글 = 5회 깜빡임 / 짝수로만 수정

// ============================================================
// 1. 블랙리스트 사이트 (시트 연동)
// ============================================================
let __blacklist_site = null;
let __bl_loaded__ = false;

function __ext_loadBlacklistSite(cb) {
try {
chrome.storage.local.get(["BlacklistSite"], (res) => {
__blacklist_site = (res.BlacklistSite || []).map(s => String(s || "").trim());
__bl_loaded__ = true;
if (typeof cb === "function") cb();
});
} catch {
__blacklist_site = [];
__bl_loaded__ = true;
if (typeof cb === "function") cb();
}
}

// 최초 1회 로드
__ext_loadBlacklistSite();

function isBlacklistSite() {
try {
const href = location.href;
const list = Array.isArray(__blacklist_site) ? __blacklist_site : [];
return list.some(u => href.startsWith(u));
} catch {
return false;
}
}

// ============================================================
// 2) 공용 배너 호스트
// ============================================================
const HOST_ID = "__ext_banner_host__";

function ensureBannerHost() {
let host = document.getElementById(HOST_ID);
if (!host) {
host = document.createElement("div");
host.id = HOST_ID;
host.setAttribute("data-ext-banner-host", "1");
Object.assign(host.style, {
all: "initial",
position: "fixed",
top: "20px",
left: "50vw",
transform: "translateX(-50%)",
zIndex: "2147483647",
display: "flex",
flexDirection: "column",
alignItems: "center",
gap: "8px",
pointerEvents: "none",
contain: "layout style paint",
willChange: "transform",
});
(document.documentElement || document.body).appendChild(host);
}
return host;
}

function cleanupEmptyHost() {
const host = document.getElementById(HOST_ID);
if (host && host.children.length === 0) host.remove();
}

// ============================================================
// 3) 배너 생성/제거 (동적 키 방식 — 시트 행 수만큼 자동 생성)
// ============================================================
const banners = {}; // { "rule_0": el, "rule_1": el, ... }
const fadeTimers = {}; // { "rule_0": timerId, ... }

function styleBannerElement(el) {
Object.assign(el.style, {
color: "#ffffffff",
fontSize: "20px",
fontWeight: "700",
background: "rgba(233, 34, 34, 0.91)",
padding: "12px 22px",
borderRadius: "16px",
opacity: "1",
transition: "opacity 0.6s ease-in-out",
boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
pointerEvents: "none",
display: "block",
flex: "0 0 auto",
alignSelf: "center"
});
}

function startFade(key) {
stopFade(key);
let toggles = 0;
const el = banners[key];
if (!el) return;
el.style.opacity = "1";
fadeTimers[key] = setInterval(() => {
const target = banners[key];
if (!target) { stopFade(key); return; }
target.style.opacity = (target.style.opacity === "1" ? "0" : "1");
toggles++;
if (toggles >= FADE_TOGGLES) {
stopFade(key);
if (banners[key]) banners[key].style.opacity = "1";
}
}, FADE_INTERVAL_MS);
}

function stopFade(key) {
try { clearInterval(fadeTimers[key]); } catch { }
fadeTimers[key] = null;
}

// order 파라미터로 배너 쌓이는 순서 결정 (시트 위→아래 순서)
function showBannerWithOrder(key, text, order) {
if (banners[key]) {
banners[key].textContent = text;
return;
}
const el = document.createElement("div");
el.textContent = text;
el.setAttribute("data-ext-banner", `etx-${key}`);
styleBannerElement(el);
el.style.order = String(order || 100);
ensureBannerHost().appendChild(el);
banners[key] = el;
startFade(key);
}

function removeBanner(key) {
if (!banners[key]) return;
stopFade(key);
try { banners[key].remove(); } catch { }
banners[key] = null;
cleanupEmptyHost();
}

// ============================================================
// 4) 시트에서 읽어온 배너 룰 캐시
// ============================================================
let __banner_rules__ = null;

function loadBannerRules(cb) {
chrome.storage.local.get(["etx_banner_rules"], (res) => {
__banner_rules__ = Array.isArray(res.etx_banner_rules) ? res.etx_banner_rules : [];
if (typeof cb === "function") cb();
});
}

// 최초 1회 로드
loadBannerRules();

// 쉼표로 구분된 값 중 하나라도 일치하는지 확인
// 예: "2315,2337,5327" 중에 "2337" 이 있으면 true
function matchesCommaList(cellValue, target) {
if (!cellValue || !target) return false;
return cellValue.split(",").map(s => s.trim()).includes(String(target).trim());
}

// ============================================================
// 5) 핵심 평가 함수 — 시트 행을 순회하며 조건 판단
//
// Condition 컬럼에 넣을 수 있는 값:
// kanid → Kanid 컬럼값 일치
// kan2 → Kan2 컬럼값 일치
// unit → Unit 컬럼값 일치
// kanid+url → Kanid 일치 AND 현재 URL이 Url로 시작
// kan2+url → Kan2 일치 AND 현재 URL이 Url로 시작
// visit → installation_type === "VISIT" (어드민JS에서 오는 특수값)
//
// 시트에 새 행을 추가하면 코드 수정 없이 자동으로 배너가 추가됨
// ============================================================
function evalAllBanners(kan, kan2, unit, installationType) {
const rules = __banner_rules__ || [];
const activeKeys = new Set();

rules.forEach((r, index) => {
const key = "rule_" + index; // rule_0, rule_1, rule_2 ...
activeKeys.add(key);

const condition = String(r.condition || "").trim().toLowerCase();
let hit = false;

if (condition === "kanid") {
hit = !!r.kanid && matchesCommaList(r.kanid, kan);

} else if (condition === "kan2") {
hit = !!r.kan2 && matchesCommaList(r.kan2, kan2);

} else if (condition === "unit") {
hit = !!r.unit && matchesCommaList(r.unit, unit);

} else if (condition === "kanid+url") {
hit = !!r.kanid && matchesCommaList(r.kanid, kan)
&& !!r.url && location.href.startsWith(r.url);

} else if (condition === "kan2+url") {
hit = !!r.kan2 && matchesCommaList(r.kan2, kan2)
&& !!r.url && location.href.startsWith(r.url);

} else if (condition === "visit") {
// 방문설치: 조건은 어드민JS에서 오는 값으로 판단, 문구만 시트에서
hit = (installationType === "VISIT");
}

if (hit && r.banner) {
showBannerWithOrder(key, r.banner, 100 + index + 1);
} else {
removeBanner(key);
}
});

// 시트에서 사라진 룰의 배너는 제거
Object.keys(banners).forEach(k => {
if (banners[k] && !activeKeys.has(k)) removeBanner(k);
});
}

// ============================================================
// 6) 메인 갱신 루틴
// ============================================================
function refresh() {
// 블랙리스트 가드 — 블랙리스트 사이트면 모든 배너 제거 후 종료
if (isBlacklistSite()) {
try { Object.keys(banners).forEach(k => removeBanner(k)); } catch (_) { }
const host = document.getElementById("__ext_banner_host__");
if (host) host.remove();
return;
}

try {
chrome.storage.local.get(
{
"__ext_last_kan": "",
"__ext_last_unit": "",
"__ext_last_kan2": "",
"__ext_installation_type": "NONE"
},
(res) => {
const kan = String(res.__ext_last_kan || "").trim();
const unit = String(res.__ext_last_unit || "").trim();
const kan2 = String(res.__ext_last_kan2 || "").trim();
const installationType = res.__ext_installation_type || "NONE";

// 룰이 아직 안 로드됐으면 로드 후 재실행
if (!__banner_rules__) {
loadBannerRules(() => evalAllBanners(kan, kan2, unit, installationType));
return;
}
evalAllBanners(kan, kan2, unit, installationType);
}
);
} catch {
// ignore
}
}

// ============================================================
// 7) storage 변경 감지
// ============================================================

// 블랙리스트 변경 즉시 반영
chrome.storage.onChanged.addListener((changes, area) => {
if (area !== "local" || !changes.BlacklistSite) return;
__blacklist_site = (changes.BlacklistSite.newValue || []).map(s => String(s || "").trim());
if (isBlacklistSite()) {
try { Object.keys(banners).forEach(k => removeBanner(k)); } catch (_) { }
const host = document.getElementById("__ext_banner_host__");
if (host) host.remove();
}
});

// 배너 룰 또는 어드민 값 변경 시 즉시 재평가
chrome.storage.onChanged.addListener((changes, area) => {
if (area !== "local") return;

// 룰 자체가 바뀌면 캐시 갱신
if (changes.etx_banner_rules) {
__banner_rules__ = Array.isArray(changes.etx_banner_rules.newValue)
? changes.etx_banner_rules.newValue : [];
}

if (
changes.__ext_last_kan ||
changes.__ext_last_kan2 ||
changes.__ext_last_unit ||
changes.__ext_installation_type ||
changes.__ext_installation_seen_at ||
changes.etx_banner_rules
) {
refresh();
}
});

// 리사이즈 시 위치 보정
window.addEventListener("resize", () => {
const host = document.getElementById(HOST_ID);
if (!host) return;
host.style.setProperty("top", "20px", "important");
host.style.setProperty("left", "50vw", "important");
host.style.setProperty("transform", "translateX(-50%)", "important");
});

// ============================================================
// 8) 부트
// ============================================================
function __boot() {
if (isBlacklistSite()) return;
refresh();
}

function __awaitBL(cb) {
if (__bl_loaded__) { cb(); return; }
const t = setInterval(() => {
if (__bl_loaded__) { clearInterval(t); cb(); }
}, 20);
}

if (document.readyState === "loading") {
document.addEventListener("DOMContentLoaded", () => { __awaitBL(__boot); }, { once: true });
} else {
__awaitBL(__boot);
}

})();
